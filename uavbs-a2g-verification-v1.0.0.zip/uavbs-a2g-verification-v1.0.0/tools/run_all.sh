#!/usr/bin/env bash
# One-command reproduction of everything in this archive that runs in Python.
# (The QuaDRiGa campaign itself requires MATLAB + QuaDRiGa 2.8.1; its raw
# outputs are shipped in campaign/ and are consumed, not regenerated, here.)
#
#   bash tools/run_all.sh            # from the archive root
#
# Steps
#   1  SHA-256 manifest check of the archive as downloaded
#   2  the 48 verification checks of the frozen implementation (26 + 10 + 12)
#   3  pack comparator on the raw campaign files -> cell reports; byte-for-byte
#      comparison with the shipped reports (Table 4 inputs)
#   4  pack forensic analysis + mechanism check on both reports (Section V)
#   5  independent comparator (campaign/audit_campaign.py) on both raw files
#   6  article figures (Figs. 3-10 data figures) from the frozen implementation
#   7  graphical abstract
# Outputs go to regen/ (ignored by the manifest). Exit status is non-zero on
# the first failure.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PACK="$ROOT/implementation/ch3_code_complete_v7"
PY="${PYTHON:-python3}"
OUT="$ROOT/regen"; mkdir -p "$OUT"
cd "$ROOT"

echo "== 1. manifest"
"$PY" tools/make_manifest.py --verify

echo "== 2. verification suites (48 checks)"
( cd "$PACK/stage2" && "$PY" -m unittest discover -s tests 2>&1 | tail -3 )
( cd "$PACK/stage3" && "$PY" -m unittest discover -s tests 2>&1 | tail -3 )
( cd "$PACK/stage4" && "$PY" -m unittest discover -s tests 2>&1 | tail -3 )

echo "== 3. pack comparator on the raw campaign files"
"$PY" "$PACK/stage3/quadriga_kit/ingest_quadriga.py" \
      campaign/quadriga_samples_FR1_2026-08.csv  "$OUT/report_FR1.csv"
"$PY" "$PACK/stage3/quadriga_kit/ingest_quadriga.py" \
      campaign/quadriga_samples_28GHz_2026-10.csv "$OUT/report_FR2.csv"
"$PY" - "$OUT/report_FR1.csv" campaign/pack_comparator/report_regen_FR1.csv \
        "$OUT/report_FR2.csv" campaign/pack_comparator/report_executed_2026-10.csv <<'EOF'
import csv, math, sys
def load(p):
    rows = list(csv.DictReader(open(p)))
    return {(r['env'], r['fc_ghz'], r['h_m'], r['d2d_m']): r for r in rows}
for new, ref in ((sys.argv[1], sys.argv[2]), (sys.argv[3], sys.argv[4])):
    A, B = load(new), load(ref)
    assert set(A) == set(B), "cell sets differ"
    worst = 0.0
    for k in A:
        for c in A[k]:
            if c == 'env': continue
            a, b = A[k][c], B[k][c]
            if c == 'plos_ok':
                assert a == b, (k, c); continue
            fa = float(a) if a not in ('', 'nan') else float('nan')
            fb = float(b) if b not in ('', 'nan') else float('nan')
            if math.isnan(fa) and math.isnan(fb): continue
            worst = max(worst, abs(fa - fb))
    print(f"  {new} vs {ref}: {len(A)} cells, max |diff| = {worst:g}")
    assert worst == 0.0, "regenerated report differs from the shipped one"
EOF
"$PY" campaign/pack_comparator/combine_reports.py "$OUT/report_FR1.csv" \
      "$OUT/report_FR2.csv" "$OUT/report_all.csv"

echo "== 4. pack forensic analysis and mechanism check"
"$PY" campaign/pack_comparator/analyze_report_guarded.py "$OUT/report_FR1.csv" > "$OUT/analyze_FR1.txt"
"$PY" campaign/pack_comparator/analyze_report_guarded.py "$OUT/report_FR2.csv" > "$OUT/analyze_FR2.txt"
"$PY" "$PACK/stage3/quadriga_kit/mechanism_check.py" "$OUT/report_FR1.csv" > "$OUT/mechanism_FR1.txt"
"$PY" "$PACK/stage3/quadriga_kit/mechanism_check.py" "$OUT/report_FR2.csv" > "$OUT/mechanism_FR2.txt"
grep -h "median=" "$OUT/analyze_FR1.txt" "$OUT/analyze_FR2.txt" | grep -E "^(UMa|UMi|RMa):" | head -6

echo "== 5. independent comparator (audit_campaign.py)"
( cd "$OUT" && "$PY" "$ROOT/campaign/audit_campaign.py" "$ROOT/campaign/quadriga_samples_FR1_2026-08.csv" FR1 > audit_FR1.txt \
             && "$PY" "$ROOT/campaign/audit_campaign.py" "$ROOT/campaign/quadriga_samples_28GHz_2026-10.csv" 28GHz > audit_28GHz.txt )
for tag in FR1 28GHz; do
  "$PY" - "$OUT/summary_$tag.json" "campaign/summary_$tag.json" <<'EOF'
import json, sys
a, b = json.load(open(sys.argv[1])), json.load(open(sys.argv[2]))
print("  summary", sys.argv[1].split('/')[-1], "identical to shipped:", a == b)
assert a == b
EOF
done

echo "== 6. article figures"
( cd article_figures/figsrc && FIG_OUT="$OUT/figs" "$PY" make_figures_access.py )

echo "== 7. graphical abstract"
( cd article_figures/figsrc && "$PY" make_abstract_access.py && mv -f graphical_abstract_access.png graphical_abstract.pdf "$OUT/" )

echo "== 8. hash-manifested artifacts regenerated in a scratch copy and compared"
rm -rf "$OUT/pack_scratch" && cp -r "$PACK" "$OUT/pack_scratch"
( cd "$OUT/pack_scratch" \
  && "$PY" stage2/scripts/export_lookup.py > /dev/null \
  && "$PY" stage3/scripts/run_stage3.py > /dev/null \
  && "$PY" discussion/lit_comparison.py > /dev/null )
"$PY" - "$PACK" "$OUT/pack_scratch" <<'EOF2'
import hashlib, json, os, sys
pack, scratch = sys.argv[1], sys.argv[2]
files = list(json.load(open(os.path.join(pack, "stage4", "schema.json")))["artifact_sha256"]) + ["discussion/lit_comparison.csv"]
h = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
bad = [f for f in files if h(os.path.join(pack, f)) != h(os.path.join(scratch, f))]
print(f"  {len(files) - len(bad)} of {len(files)} regenerated artifacts byte-identical to the shipped ones")
assert not bad, bad
EOF2

echo "ALL STEPS COMPLETED"
