"""Stage-2 test suite (stdlib unittest; also runs under pytest).

Layers of validation:
  A. Equivalence against the Stage-1 oracle (tests/stage1_oracle.py, the
     scalar implementation that was itself validated against finite
     differences at 11,835 points and against the source documents).
  B. Direct finite-difference re-check of the packaged analytic derivative.
  C. Golden numbers printed in the reviewed Stage-1 run (profiles, walls,
     h*, Doppler, CDL K-factors).
  D. Statistical checks for the shadow-fading generators.
  E. Independent re-typing of Alt-2 table values at spot altitudes.
"""
import math
import os
import sys
import unittest
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import uav_channel as uc                                   # noqa: E402
from uav_channel import params as P                        # noqa: E402

# ---- load Stage-1 oracle (definitions only; strip the self-running checks)
ORACLE = {}
_src = open(os.path.join(os.path.dirname(__file__), "stage1_oracle.py")).read()
exec(_src.split("# =============== 1.")[0], ORACLE)


class TestOracleEquivalence(unittest.TestCase):
    """Package (vectorised) must reproduce the Stage-1 oracle (scalar)."""

    def test_random_points(self):
        rng = np.random.default_rng(3)
        for _ in range(2500):
            env = rng.choice(["UMa", "UMi", "RMa"])
            lo, hi = P.AERIAL_PLOS[env]["band"]
            h = rng.uniform(lo + 0.2, hi - 0.2)
            r = rng.uniform(20, 1500)
            fc = rng.choice([2.6, 3.5, 28.0])
            lm = rng.uniform(95, 140)
            self.assertAlmostEqual(uc.plos_aerial(env, r, h),
                                   ORACLE["PLoS"](env, r, h), places=12)
            self.assertAlmostEqual(uc.pl_los_aerial(env, r, h, fc),
                                   ORACLE["PL_L"](env, r, h, fc), places=10)
            self.assertAlmostEqual(uc.pl_nlos_aerial(env, r, h, fc),
                                   ORACLE["PL_N"](env, r, h, fc), places=10)
            self.assertAlmostEqual(uc.sf_std_aerial(env, h, "LOS"),
                                   ORACLE["sig_L"](env, h), places=12)
            self.assertAlmostEqual(uc.p_cov(env, r, h, fc, lm),
                                   ORACLE["Pcov"](env, r, h, fc, lm),
                                   places=12)

    def test_vectorisation_matches_scalar(self):
        h = np.linspace(23, 299, 57)
        r = 350.0
        vec = uc.p_cov("UMa", r, h, 3.5, 120.0)
        for i, hh in enumerate(h):
            self.assertAlmostEqual(vec[i], uc.p_cov("UMa", r, float(hh),
                                                    3.5, 120.0), places=13)


class TestDerivative(unittest.TestCase):
    KINKS = {"UMa": [36.42, 100.0], "UMi": [34.16, 91.63],
             "RMa": [13.65, 15.83, 40.0, 146.78]}

    def test_finite_difference(self):
        rng = np.random.default_rng(11)
        checked = 0
        while checked < 250:
            env = rng.choice(["UMa", "UMi", "RMa"])
            lo, hi = P.AERIAL_PLOS[env]["band"]
            h = rng.uniform(lo + 0.4, hi - 1.0)
            if any(abs(h - k) < 0.7 for k in self.KINKS[env]):
                continue
            r = rng.uniform(25, 1400)
            fc = rng.choice([2.6, 3.5, 28.0])
            lm = rng.uniform(100, 135)
            d1 = ORACLE["p1d1"](env, h)[1]
            if abs(r - d1) < 2.5:
                continue
            # skip PL max()-branch switch neighbourhoods (non-differentiable)
            d = uc.d3d(r, h)
            if env == "RMa":
                raw = -12 + (35 - 5.3 * np.log10(h)) * np.log10(d) + \
                    20 * np.log10(40 * np.pi * fc / 3)
                if abs(uc.pl_los_aerial(env, r, h, fc) - raw) < 0.03:
                    continue
            if env == "UMi":
                raw = 32.4 + (43.2 - 7.6 * np.log10(h)) * np.log10(d) + \
                    20 * np.log10(fc)
                if abs(uc.pl_los_aerial(env, r, h, fc) - raw) < 0.03:
                    continue
            num = (uc.p_cov(env, r, h + 1e-4, fc, lm)
                   - uc.p_cov(env, r, h - 1e-4, fc, lm)) / 2e-4
            ana = uc.g_dh(env, r, h, fc, lm)
            self.assertLess(abs(num - ana), 1e-6 + 1e-4 * abs(num),
                            msg=f"{env} r={r:.1f} h={h:.2f} fc={fc} lm={lm:.1f}")
            checked += 1


class TestGoldenNumbers(unittest.TestCase):
    """Values from the reviewed Stage-1 run (printed profiles/tables)."""

    def test_uma28_profile(self):
        env, r, fc, lm = "UMa", 500.0, 28.0, 115.0
        self.assertAlmostEqual(uc.plos_aerial(env, r, 23.0), 0.792, delta=8e-4)
        self.assertAlmostEqual(uc.pl_los_aerial(env, r, 23.0, fc), 116.3, delta=0.05)
        self.assertAlmostEqual(uc.pl_nlos_aerial(env, r, 23.0, fc), 142.3, delta=0.05)
        self.assertAlmostEqual(uc.sf_std_aerial(env, 23.0, "LOS"), 3.99, delta=0.005)
        self.assertAlmostEqual(uc.p_cov(env, r, 23.0, fc, lm), 0.2925, delta=6e-4)
        self.assertEqual(uc.plos_aerial(env, r, 100.1), 1.0)
        self.assertAlmostEqual(uc.pl_los_aerial(env, r, 300.0, fc), 117.8, delta=0.05)
        self.assertAlmostEqual(uc.pl_nlos_aerial(env, r, 300.0, fc), 123.1, delta=0.05)
        self.assertLess(uc.p_cov(env, r, 300.0, fc, lm), 1e-3)

    def test_rma_nlos_clip(self):
        # Stage-1: h=35, fc=3.5 -> r=60 clipped to LoS 82.1; r=200 raw 93.2
        self.assertAlmostEqual(uc.pl_nlos_aerial("RMa", 60, 35, 3.5),
                               uc.pl_los_aerial("RMa", 60, 35, 3.5), places=9)
        self.assertAlmostEqual(uc.pl_nlos_aerial("RMa", 60, 35, 3.5), 82.1,
                               delta=0.05)
        self.assertAlmostEqual(uc.pl_nlos_aerial("RMa", 200, 35, 3.5), 93.2,
                               delta=0.05)

    def test_constants(self):
        for fc, c in ((2.6, 40.741), (3.5, 43.323), (28.0, 61.385)):
            self.assertAlmostEqual(
                20 * np.log10(40 * np.pi * fc / 3.0), c, delta=5e-4)

    def test_walls(self):
        for env, r, hw in (("UMa", 100, 54.8), ("UMa", 200, 90.5),
                           ("UMa", 250, 100.0), ("UMi", 250, 210.2),
                           ("RMa", 500, 36.0), ("UMi", 100, 64.9)):
            self.assertAlmostEqual(uc.h_wall(env, r), hw, delta=0.2)

    def test_hstar_outline(self):
        r = uc.h_star_refined("UMa", 200, 3.5, 120.0)
        self.assertAlmostEqual(r["h_star"], 90.5, delta=0.3)
        r = uc.h_star_refined("UMa", 250, 3.5, 120.0)
        self.assertAlmostEqual(r["h_star"], 100.0, delta=0.3)
        r = uc.h_star_refined("UMi", 200, 3.5, 120.0)
        self.assertAlmostEqual(r["h_star"], 142.1, delta=0.5)

    def test_fr2_bimodality(self):
        res = uc.h_star("UMa", 500, 28.0, 115.0)
        self.assertGreater(res["n_modes"], 1)

    def test_doppler(self):
        self.assertAlmostEqual(uc.fd_max(20, 28.0), 1866.7, delta=0.1)
        self.assertAlmostEqual(uc.fd_max(30, 2.6), 260.0, delta=0.1)
        self.assertAlmostEqual(uc.coherence_time(20, 28.0) * 1e3, 0.2266,
                               delta=0.002)

    def test_terrestrial_continuity(self):
        """PL1(d'BP) == PL2(d'BP) for UMa/UMi terrestrial LoS."""
        for env, hb in (("UMa", 25.0), ("UMi", 10.0)):
            fc = 3.5
            h = 2.0
            dbp = 4 * (hb - 1) * (h - 1) * fc * 1e9 / 3e8
            a = uc.pl_terrestrial(env, dbp * (1 - 1e-9), h, fc, "LOS")
            b = uc.pl_terrestrial(env, dbp * (1 + 1e-9), h, fc, "LOS")
            self.assertAlmostEqual(float(a), float(b), delta=1e-6)


class TestSmallScale(unittest.TestCase):
    def test_cdl_normalised_ds(self):
        d, p, _ = uc.small_scale._cdl_arrays(P.CDL_D) \
            if hasattr(uc, "small_scale") else (None, None, None)
        from uav_channel.small_scale import _cdl_arrays
        for cdl, name in ((P.CDL_D, "D"), (P.CDL_E, "E")):
            d, p, _ = _cdl_arrays(cdl)
            ds = uc.rms_ds(d, p)
            self.assertAlmostEqual(ds, 1.0, delta=0.05,
                                   msg=f"CDL-{name} rms DS = {ds:.4f}")

    def test_k_factors(self):
        self.assertAlmostEqual(uc.k_model(P.CDL_D), 8.98, delta=0.02)
        self.assertAlmostEqual(uc.k_model(P.CDL_E), 9.27, delta=0.02)
        self.assertAlmostEqual(uc.k_first_cluster(P.CDL_D), 13.30, delta=0.01)
        self.assertAlmostEqual(uc.k_first_cluster(P.CDL_E), 22.00, delta=0.01)

    def test_k_scaling_closure(self):
        s = uc.scale_k(P.CDL_D, 20.0)
        self.assertAlmostEqual(uc.k_model(s), 20.0, places=9)
        from uav_channel.small_scale import _cdl_arrays
        d, p, _ = _cdl_arrays(s)
        self.assertAlmostEqual(uc.rms_ds(d, p), 1.0, places=9)

    def test_delay_scaling(self):
        s = uc.scale_delays(P.CDL_D, 30e-9)
        from uav_channel.small_scale import _cdl_arrays
        d, p, _ = _cdl_arrays(s)
        self.assertAlmostEqual(uc.rms_ds(d, p), 30e-9, delta=30e-9 * 0.05)

    def test_angle_scaling_closure(self):
        los = dict(aod=45.0, aoa=-135.0, zod=95.0, zoa=85.0)
        s = uc.scale_angles(P.CDL_D, dict(aod=0.5, aoa=0.5, zod=0.1, zoa=0.1),
                            los)
        self.assertAlmostEqual(uc.composite_as(s, "aoa"), 0.5, delta=0.02)
        self.assertAlmostEqual(uc.composite_as(s, "aod"), 0.5, delta=0.02)
        self.assertAlmostEqual(s["specular"]["aoa"], -135.0, places=9)
        self.assertAlmostEqual(s["specular"]["zod"], 95.0, places=9)

    def test_zod_offset(self):
        exp = math.degrees(math.atan(135 / 1000) + math.atan(65 / 1000))
        self.assertAlmostEqual(uc.zod_offset_los_deg("RMa", 1000, 100), exp,
                               places=9)
        exp_uma = math.degrees(math.atan((25 + 100 - 40) / 500)
                               + math.atan((100 - 25) / 500))
        self.assertAlmostEqual(uc.zod_offset_los_deg("UMa", 500, 100), exp_uma,
                               places=9)

    def test_alt2_spot_values(self):
        st = uc.lsp_alt2("UMa", 100.0, "LOS")
        self.assertAlmostEqual(st["K"][0], 14.221, delta=1e-9)
        self.assertAlmostEqual(st["K"][1], 8.158 * math.exp(0.46), delta=1e-9)
        self.assertAlmostEqual(st["lgDS"][0], -7.465, delta=1e-9)
        self.assertAlmostEqual(st["lgDS"][1], 0.7294 * math.exp(0.14), delta=1e-9)
        self.assertAlmostEqual(st["lgASA"][0], -6.599, delta=1e-9)
        st = uc.lsp_alt2("RMa", 30.0, "LOS")
        self.assertAlmostEqual(st["K"][0], 22.55 * math.log10(30) - 4.72,
                               places=9)
        with self.assertRaises(NotImplementedError):
            uc.lsp_alt2("UMi", 100.0, "LOS")   # open flag V1

    def test_alt1_pipeline_and_generator(self):
        los = dict(aod=10.0, aoa=-170.0, zod=100.0, zoa=80.0)
        cdl = uc.alt1_cdl("UMa", 300.0, 100.0, "LOS", los)
        self.assertAlmostEqual(uc.k_model(cdl), 20.0, places=6)
        from uav_channel.small_scale import _cdl_arrays
        d, p, _ = _cdl_arrays(cdl)
        self.assertAlmostEqual(uc.rms_ds(d, p), 10e-9, delta=1e-11)
        t = np.linspace(0, 1.0, 40001)
        H, delays = uc.gen_channel(cdl, 3.5, t,
                                   v_rx=uc.velocity_vec(20.0, 30.0), rng=5)
        self.assertAlmostEqual(float(np.mean(np.abs(H) ** 2)), 1.0, delta=0.2)

    def test_specular_doppler(self):
        """LoS ray Doppler equals (v.r_hat)/lambda exactly."""
        cdl = dict(specular=dict(P.CDL_D["specular"]),
                   clusters=P.CDL_D["clusters"][:1].copy() * 0 - 300.0,
                   c_asd=5.0, c_asa=8.0, c_zsd=3.0, c_zsa=3.0, xpr_db=11.0)
        cdl["clusters"][:, 0] = 0.0   # negligible power cluster
        fs = 8000.0
        t = np.arange(0, 1.0, 1 / fs)
        v = uc.velocity_vec(20.0, 0.0, 90.0)     # horizontal, az=0
        H, _ = uc.gen_channel(cdl, 3.5, t, v_rx=v, rng=1)
        spec = np.abs(np.fft.fft(H))
        f = np.fft.fftfreq(t.size, 1 / fs)
        peak = f[np.argmax(spec)]
        r_hat = uc.small_scale.unit_vec(-180.0, 81.5)
        expect = float(r_hat @ v) / (3e8 / 3.5e9)
        self.assertAlmostEqual(peak, expect, delta=1.5)


class TestShadowing(unittest.TestCase):
    def test_ar1_acf(self):
        x = uc.ar1_trajectory(np.full(120000, 5.0), 25.0, rng=7)
        r1 = float(np.corrcoef(x[:-1], x[1:])[0, 1])
        r5 = float(np.corrcoef(x[:-5], x[5:])[0, 1])
        self.assertAlmostEqual(r1, math.exp(-5 / 25), delta=0.01)
        self.assertAlmostEqual(r5, math.exp(-1.0), delta=0.02)

    def test_map_acf(self):
        m = uc.spectral_map_2d(360, 360, 5.0, 25.0, rng=3)
        self.assertAlmostEqual(float(m.var()), 1.0, delta=0.02)
        lag = 5  # 25 m = d_corr
        r = float(np.mean(m[:, :-lag] * m[:, lag:]))
        self.assertAlmostEqual(r, math.exp(-1.0), delta=0.07)

    def test_cholesky_points(self):
        rng = np.random.default_rng(2)
        pts = rng.uniform(0, 200, size=(50, 3))
        d = np.linalg.norm(pts[:, None] - pts[None, :], axis=-1)
        R = np.exp(-d / 50.0)
        L = np.linalg.cholesky(R + 1e-10 * np.eye(50))
        X = L @ rng.standard_normal((50, 4000))
        emp = np.corrcoef(X)
        self.assertLess(float(np.max(np.abs(emp - R))), 0.08)

    def test_sf_generator(self):
        g = uc.SFGenerator("UMa", extent=(400, 400), dx=5.0, rng=1)
        v = g.sample(100.0, 150.0, 120.0, "LOS")
        self.assertLess(abs(v), 5 * uc.sf_std_aerial("UMa", 120.0, "LOS") + 1e-9)
        self.assertEqual(g.d_corr["LOS"], 37.0)
        self.assertEqual(g.d_corr["NLOS"], 50.0)


class TestLookup(unittest.TestCase):
    def test_core_rows(self):
        rows = uc.build_rows()
        self.assertEqual(len(rows), 3 * 6 * 3 * 5)
        cols = {c: i for i, c in enumerate(uc.lookup.COLUMNS)} \
            if hasattr(uc, "lookup") else None
        from uav_channel.lookup import COLUMNS
        cols = {c: i for i, c in enumerate(COLUMNS)}
        row = [r for r in rows if r[0] == "UMa" and r[1] == 3.5
               and r[2] == 100.0 and r[3] == 200.0][0]
        self.assertEqual(row[cols["plos"]], 1.0)          # r=200 < d1(100)=220
        self.assertAlmostEqual(row[cols["pl_los_db"]], 90.542, delta=5e-3)
        self.assertAlmostEqual(row[cols["k_mu_db"]], 14.221, delta=1e-6)
        umi = [r for r in rows if r[0] == "UMi"][0]
        self.assertTrue(np.isnan(umi[cols["k_mu_db"]]))   # open flag V1

    def test_dense_export(self):
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "dense.npz")
            shapes = uc.export_dense_npz(path)
            z = np.load(path, allow_pickle=False)
            self.assertIn("UMa_plos", z.files)
            self.assertIn("RMa_pl_nlos_28p0", z.files)
            self.assertEqual(z["UMa_plos"].shape,
                             (z["UMa_h"].size, z["UMa_d2d"].size))


if __name__ == "__main__":
    unittest.main(verbosity=2)
