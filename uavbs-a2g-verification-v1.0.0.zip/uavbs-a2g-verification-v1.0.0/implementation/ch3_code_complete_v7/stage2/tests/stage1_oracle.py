"""Stage-1 verification: TR 36.777 aerial channel instantiation + optimal-altitude analysis.

Checks:
 1. Analytic dP_cov/dh vs central finite differences (derivation correctness).
 2. Sign-structure / uniqueness scan of G(h) over the full operating grid.
 3. Optimal altitude h* tables (corner vs interior classification).
 4. CDL-D / CDL-E model K-factor via TR 38.901 eq. (7.7.6-2).
 5. Per-frequency constants, max Doppler, coherence time.
 6. Consistency with outline expectation (UMa 3.5 GHz h* ~ [90,130] m; UMi [40,60] m).
"""
import numpy as np
from math import log10, log, exp, sqrt, pi, erfc

L10 = log(10.0)
H_G = 1.5          # ground-terminal height [m]

Q = lambda x: 0.5 * erfc(x / sqrt(2.0))
phi = lambda x: exp(-0.5 * x * x) / sqrt(2.0 * pi)

def d3(r, h):
    return sqrt(r * r + (h - H_G) ** 2)

# ---------------- TR 36.777 Table B-1: LoS probability (aerial band) -----------
PAR = {  # a_p, b_p, p_floor, a_d, b_d, d_floor, h_sat(P_LoS=1 above), band (aerial)
 'UMa': dict(ap=4300.0, bp=3800.0, pfl=None, ad=460.0,   bd=700.0,   dfl=18.0, hsat=100.0, band=(22.5, 300.0)),
 'UMi': dict(ap=233.98, bp=0.95,   pfl=None, ad=294.05,  bd=432.94,  dfl=18.0, hsat=None,  band=(22.5, 300.0)),
 'RMa': dict(ap=15021.0,bp=16053.0,pfl=1000.0,ad=1350.8, bd=1602.0,  dfl=18.0, hsat=40.0,  band=(10.0, 300.0)),
}

def p1d1(env, h):
    P = PAR[env]; lg = log10(h)
    p1 = P['ap'] * lg - P['bp']
    p1fl = False
    if P['pfl'] is not None and p1 < P['pfl']:
        p1, p1fl = P['pfl'], True
    d1 = P['ad'] * lg - P['bd']
    d1fl = False
    if d1 < P['dfl']:
        d1, d1fl = P['dfl'], True
    return p1, d1, p1fl, d1fl

def PLoS(env, r, h):
    P = PAR[env]
    if P['hsat'] is not None and h > P['hsat']:
        return 1.0
    p1, d1, _, _ = p1d1(env, h)
    if r <= d1:
        return 1.0
    return d1 / r + exp(-r / p1) * (1.0 - d1 / r)

def dPLoS_dh(env, r, h):
    P = PAR[env]
    if P['hsat'] is not None and h > P['hsat']:
        return 0.0
    p1, d1, p1fl, d1fl = p1d1(env, h)
    if r <= d1:
        return 0.0
    E = exp(-r / p1)
    t1 = 0.0 if d1fl else (P['ad'] / (h * L10)) * (1.0 - E) / r
    t2 = 0.0 if p1fl else (P['ap'] / (h * L10)) * E * (r / p1 ** 2) * (1.0 - d1 / r)
    return t1 + t2

# ---------------- TR 36.777 Table B-2: path loss (aerial band), fc in GHz ------
Cf = lambda fc: 20.0 * log10(40.0 * pi * fc / 3.0)      # = 32.444 + 20 log10 fc
FSPL = lambda d, fc: 32.444 + 20.0 * log10(d) + 20.0 * log10(fc)  # c = 3e8 convention

def PL_L(env, r, h, fc):
    d = d3(r, h)
    if env == 'UMa':
        return 28.0 + 22.0 * log10(d) + 20.0 * log10(fc)
    if env == 'UMi':
        return max(FSPL(d, fc), 30.9 + (22.25 - 0.5 * log10(h)) * log10(d) + 20.0 * log10(fc))
    return max(23.9 - 1.8 * log10(h), 20.0) * log10(d) + Cf(fc)

def PL_N(env, r, h, fc):
    d = d3(r, h)
    if env == 'UMa':
        return -17.5 + (46.0 - 7.0 * log10(h)) * log10(d) + Cf(fc)      # no max() in TR
    if env == 'UMi':
        return max(PL_L(env, r, h, fc), 32.4 + (43.2 - 7.6 * log10(h)) * log10(d) + 20.0 * log10(fc))
    return max(PL_L(env, r, h, fc), -12.0 + (35.0 - 5.3 * log10(h)) * log10(d) + Cf(fc))

def dPL_generic(B, Bp, r, h):
    """d/dh [ B(h)*log10(d3) ] with B' = Bp ; plus nothing else h-dependent."""
    d = d3(r, h)
    return Bp * log10(d) + B * (h - H_G) / (L10 * d * d)

def dPL_L_dh(env, r, h, fc):
    d = d3(r, h)
    if env == 'UMa':
        return dPL_generic(22.0, 0.0, r, h)
    if env == 'UMi':
        f_formula = 30.9 + (22.25 - 0.5 * log10(h)) * log10(d) + 20.0 * log10(fc)
        if FSPL(d, fc) > f_formula:
            return dPL_generic(20.0, 0.0, r, h)
        return dPL_generic(22.25 - 0.5 * log10(h), -0.5 / (h * L10), r, h)
    B = 23.9 - 1.8 * log10(h)
    if B < 20.0:
        return dPL_generic(20.0, 0.0, r, h)
    return dPL_generic(B, -1.8 / (h * L10), r, h)

def dPL_N_dh(env, r, h, fc):
    d = d3(r, h)
    if env == 'UMa':
        return dPL_generic(46.0 - 7.0 * log10(h), -7.0 / (h * L10), r, h)
    if env == 'UMi':
        v = 32.4 + (43.2 - 7.6 * log10(h)) * log10(d) + 20.0 * log10(fc)
        if PL_L(env, r, h, fc) >= v:
            return dPL_L_dh(env, r, h, fc)
        return dPL_generic(43.2 - 7.6 * log10(h), -7.6 / (h * L10), r, h)
    v = -12.0 + (35.0 - 5.3 * log10(h)) * log10(d) + Cf(fc)
    if PL_L(env, r, h, fc) >= v:
        return dPL_L_dh(env, r, h, fc)
    return dPL_generic(35.0 - 5.3 * log10(h), -5.3 / (h * L10), r, h)

# ---------------- TR 36.777 Table B-3: shadow fading ---------------------------
def sig_L(env, h):
    if env == 'UMa':
        return 4.64 * exp(-0.0066 * h)
    if env == 'UMi':
        return max(5.0 * exp(-0.01 * h), 2.0)
    return 4.2 * exp(-0.0046 * h)

def dsig_L_dh(env, h):
    if env == 'UMa':
        return -0.0066 * sig_L(env, h)
    if env == 'UMi':
        return 0.0 if 5.0 * exp(-0.01 * h) < 2.0 else -0.01 * sig_L(env, h)
    return -0.0046 * sig_L(env, h)

SIG_N = {'UMa': 6.0, 'UMi': 8.0, 'RMa': 6.0}

# ---------------- coverage probability and its h-derivative --------------------
def Pcov(env, r, h, fc, Lmax):
    pl = PLoS(env, r, h)
    uL = (PL_L(env, r, h, fc) - Lmax) / sig_L(env, h)
    uN = (PL_N(env, r, h, fc) - Lmax) / SIG_N[env]
    return pl * Q(uL) + (1.0 - pl) * Q(uN)

def G(env, r, h, fc, Lmax):
    """analytic dPcov/dh (branch-aware)"""
    pl  = PLoS(env, r, h)
    sL  = sig_L(env, h); sLp = dsig_L_dh(env, h)
    uL  = (PL_L(env, r, h, fc) - Lmax) / sL
    uN  = (PL_N(env, r, h, fc) - Lmax) / SIG_N[env]
    uLp = dPL_L_dh(env, r, h, fc) / sL - uL * sLp / sL
    uNp = dPL_N_dh(env, r, h, fc) / SIG_N[env]
    return dPLoS_dh(env, r, h) * (Q(uL) - Q(uN)) - pl * phi(uL) * uLp - (1.0 - pl) * phi(uN) * uNp

# =============== 1. finite-difference verification =============================
rng = np.random.default_rng(7)
bad = 0; tested = 0
KINKS = {'UMa': [36.42, 100.0], 'UMi': [34.16, 91.63], 'RMa': [13.65, 15.83, 40.0, 146.78]}
for env in PAR:
    lo, hi = PAR[env]['band']
    for _ in range(4000):
        h  = rng.uniform(lo + 0.3, min(hi, 299.0))
        if any(abs(h - k) < 0.6 for k in KINKS[env]):
            continue
        r  = rng.uniform(20.0, 1500.0)
        fc = rng.choice([2.6, 3.5, 28.0])
        Lm = rng.uniform(95.0, 140.0)
        # skip points within eps of a PL max()-branch switch (non-differentiable)
        eps = 1e-3
        def switch(rr, hh):
            d = d3(rr, hh)
            if env == 'UMi':
                return abs(FSPL(d, fc) - (30.9 + (22.25 - 0.5 * log10(hh)) * log10(d) + 20 * log10(fc))) < 0.02 \
                    or abs(PL_L(env, rr, hh, fc) - (32.4 + (43.2 - 7.6 * log10(hh)) * log10(d) + 20 * log10(fc))) < 0.02
            if env == 'RMa':
                return abs(PL_L(env, rr, hh, fc) - (-12.0 + (35.0 - 5.3 * log10(hh)) * log10(d) + Cf(fc))) < 0.02
            return False
        if switch(r, h):
            continue
        # skip near the r = d1(h) LoS wall (Pcov kink in h)
        _, d1, _, _ = p1d1(env, h)
        if abs(r - d1) < 2.0:
            continue
        num = (Pcov(env, r, h + 1e-4, fc, Lm) - Pcov(env, r, h - 1e-4, fc, Lm)) / 2e-4
        ana = G(env, r, h, fc, Lm)
        tested += 1
        if abs(num - ana) > 1e-6 + 1e-4 * abs(num):
            bad += 1
            if bad < 8:
                print("MISMATCH", env, round(r,1), round(h,2), fc, round(Lm,1), num, ana)
print(f"[1] finite-difference check: {tested} points, mismatches = {bad}")

# =============== 2. uniqueness / sign-structure scan ===========================
def h_wall(env, r):
    """h_1(r): lowest altitude of certain LoS at range r (within aerial band top)."""
    P = PAR[env]
    hs = P['hsat'] if P['hsat'] is not None else P['band'][1]
    if r <= P['dfl']:
        return P['band'][0]  # wall below band start
    hw = 10.0 ** ((r + P['bd']) / P['ad'])
    return min(hw, hs)

multi = []
plateau_eps = 1e-4
for env in PAR:
    lo, hi = PAR[env]['band']
    hgrid = np.arange(lo + 0.05, hi, 0.05)
    for fc in [2.6, 3.5, 28.0]:
        for r in [50, 100, 200, 500, 1000]:
            for Lm in [105, 110, 115, 120, 125, 130, 135]:
                pc = np.array([Pcov(env, r, h, fc, Lm) for h in hgrid])
                dpc = np.diff(pc)
                sgn = np.sign(dpc); sgn = sgn[sgn != 0]
                flips = int(np.sum(sgn[1:] != sgn[:-1]))
                spread = pc.max() - pc.min()
                if flips > 1 and spread > 1e-3:      # ignore flat-plateau numerical dust
                    multi.append((env, fc, r, Lm, flips, round(spread, 4)))
print(f"[2] uniqueness scan: {len(multi)} non-unimodal cases (excluding <1e-3 plateaus)")
for m in multi[:10]:
    print("   ", m)

# =============== 3. optimal-altitude tables ====================================
print("\n[3] h* table  (aerial band only; corner = LoS wall h_1(r); plateau = Pcov>0.999 over >50 m)")
hdr = f"{'env':4s} {'fc':>5s} {'r':>5s} | " + "  ".join(f"Lmax={L}" for L in [110, 120, 130])
print(hdr)
for env in PAR:
    lo, hi = PAR[env]['band']
    hgrid = np.arange(lo + 0.05, hi, 0.05)
    for fc in [2.6, 3.5, 28.0]:
        for r in [100, 200, 500, 1000]:
            cells = []
            for Lm in [110, 120, 130]:
                pc = np.array([Pcov(env, r, h, fc, Lm) for h in hgrid])
                i = int(np.argmax(pc)); hstar = hgrid[i]; pmax = pc[i]
                hw = h_wall(env, r)
                near = pc >= pmax - plateau_eps
                span = hgrid[near][-1] - hgrid[near][0]
                if pmax < 1e-3:
                    tag = "none"          # no coverage anywhere
                elif span > 50:
                    tag = f"plat(>{hgrid[near][0]:.0f})"
                elif abs(hstar - hw) < 0.15:
                    tag = f"{hstar:.1f}=wall"
                else:
                    tag = f"{hstar:.1f}"
                cells.append(f"{tag:>12s}(P={pmax:.3f})")
            print(f"{env:4s} {fc:5.1f} {r:5d} | " + " ".join(cells))

# =============== 4. CDL-D / CDL-E model K-factor (TR 38.901 7.7.6-2) ==========
cdl_d = [-13.5, -18.8, -21.0, -22.8, -17.9, -20.1, -21.9, -22.9, -27.8, -23.6, -24.8, -30.0, -27.7]
cdl_e = [-22.03, -15.8, -18.1, -19.8, -22.9, -22.4, -18.6, -20.8, -22.6, -22.3, -25.6, -20.2, -29.8, -29.2]
for name, plos_db, laps in [("CDL-D", -0.2, cdl_d), ("CDL-E", -0.03, cdl_e)]:
    s = sum(10 ** (p / 10.0) for p in laps)
    print(f"[4] {name}: K_model = {plos_db - 10 * log10(s):.2f} dB   (first-cluster K1 = {plos_db - laps[0]:.2f} dB)")

# =============== 5. frequency constants / Doppler ==============================
print("\n[5] constants")
for fc in [2.6, 3.5, 28.0]:
    print(f"  fc={fc:5.1f}: 20log10(fc)={20*log10(fc):7.3f}  20log10(40*pi*fc/3)={Cf(fc):7.3f}")
c = 3e8
for v in [10.0, 20.0, 30.0]:
    row = "  ".join(f"{v*fcg*1e9/c:8.1f} Hz (Tc={0.423/(v*fcg*1e9/c)*1e3:6.2f} ms)" for fcg in [2.6, 3.5, 28.0])
    print(f"  v={v:4.0f} m/s: fD,max = {row}")

# =============== 6. outline consistency check ==================================
print("\n[6] outline check: UMa-AV fc=3.5 — h* vs r for Lmax in 115..125; UMi same")
for env in ['UMa', 'UMi']:
    lo, hi = PAR[env]['band']
    hgrid = np.arange(lo + 0.05, hi, 0.05)
    for Lm in [115, 120, 125]:
        hs = []
        for r in [150, 200, 250, 300]:
            pc = np.array([Pcov(env, r, h, 3.5, Lm) for h in hgrid])
            hs.append(f"r={r}:{hgrid[int(np.argmax(pc))]:6.1f}")
        print(f"  {env} Lmax={Lm}: " + "  ".join(hs))

# =============== 7. wall formula sanity ========================================
print("\n[7] LoS-wall closed form h_1(r):")
for env in PAR:
    for r in [100, 150, 200, 250, 300, 500]:
        print(f"  {env} r={r}: h_1={h_wall(env,r):7.1f}", end="")
    print()
