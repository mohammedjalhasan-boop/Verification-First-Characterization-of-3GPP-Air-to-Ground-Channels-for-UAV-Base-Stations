"""Spatially correlated shadow-fading generation.

Autocorrelation model (Stage-1 Eq. for R): R(D) = exp(-D / d_corr), horizontal
plane, per TR 38.901 Sec. 7.5 Step 4 (WINNER II 3.3.1 procedure) with
d_corr^SF from Table 7.5-6.

Three generators:
  * ar1_trajectory   -- exact along a 1-D trajectory (any step sizes)
  * spectral_map_2d  -- FFT spectral synthesis of a 2-D exponential-ACF field
  * correlated_points -- exact (Cholesky) for arbitrary 3-D point sets
                        (Assumption D2: isotropic 3-D extension for UAV motion)

All generators return unit-variance fields; multiply by sigma_SF(h, state)
(possibly altitude-varying, Assumption D2 multiplicative form).
"""
from __future__ import annotations
import numpy as np
from . import params as P


def ar1_trajectory(step_dists, d_corr, rng=None):
    """Unit-variance Gauss-Markov sequence with R(D)=exp(-D/d_corr).

    step_dists : array of N-1 successive travelled distances [m]
    returns array of N samples (exact for exponential ACF, any step sizes).
    """
    rng = np.random.default_rng(rng)
    step_dists = np.asarray(step_dists, dtype=float)
    n = step_dists.size + 1
    x = np.empty(n)
    x[0] = rng.standard_normal()
    rho = np.exp(-step_dists / float(d_corr))
    w = rng.standard_normal(n - 1)
    for k in range(1, n):
        x[k] = rho[k - 1] * x[k - 1] + np.sqrt(1.0 - rho[k - 1] ** 2) * w[k - 1]
    return x


def spectral_map_2d(nx, ny, dx, d_corr, rng=None, oversample=2):
    """Unit-variance 2-D Gaussian field with isotropic ACF exp(-r/d_corr).

    FFT spectral synthesis: the 2-D spectrum of the exponential ACF is
    S(k) = 2*pi*a^2 / (1 + (a*k)^2)^{3/2}, a = d_corr. Synthesised on an
    oversampled periodic grid and cropped to (ny, nx) to suppress wrap-around.
    Grid spacing dx [m]. Empirical ACF accuracy is tested in tests/.
    """
    rng = np.random.default_rng(rng)
    Nx, Ny = int(nx * oversample), int(ny * oversample)
    # guarantee the periodic domain is >> correlation length
    min_pts = int(np.ceil(8 * d_corr / dx))
    Nx, Ny = max(Nx, min_pts), max(Ny, min_pts)
    kx = 2 * np.pi * np.fft.fftfreq(Nx, d=dx)
    ky = 2 * np.pi * np.fft.fftfreq(Ny, d=dx)
    KX, KY = np.meshgrid(kx, ky)
    a = float(d_corr)
    S = 2 * np.pi * a * a / (1.0 + (a * np.hypot(KX, KY)) ** 2) ** 1.5
    dk2 = (kx[1] - kx[0]) * (ky[1] - ky[0])
    # complex white noise, Hermitian pairing handled by taking real part * sqrt(2)
    W = (rng.standard_normal((Ny, Nx)) + 1j * rng.standard_normal((Ny, Nx)))
    F = np.fft.ifft2(np.sqrt(S) * W) * np.sqrt(dk2) * Nx * Ny / (2 * np.pi)
    field = np.real(F)
    # theoretical normalisation drifts with spectral truncation on a finite
    # grid; renormalise empirically to unit variance (documented behaviour)
    field = (field - field.mean()) / field.std()
    return field[:ny, :nx]


def correlated_points(points, d_corr, rng=None, jitter=1e-10):
    """Unit-variance correlated SF at arbitrary 3-D points (exact, Cholesky).

    points : (N,3) array [m]; R_ij = exp(-||p_i-p_j|| / d_corr)  (Assumption D2)
    Practical for N <= ~4000.
    """
    rng = np.random.default_rng(rng)
    pts = np.asarray(points, dtype=float)
    d = np.linalg.norm(pts[:, None, :] - pts[None, :, :], axis=-1)
    R = np.exp(-d / float(d_corr))
    Lc = np.linalg.cholesky(R + jitter * np.eye(len(pts)))
    return Lc @ rng.standard_normal(len(pts))


class SFGenerator:
    """Per-link shadow fading with state-dependent sigma and d_corr.

    Keeps two independent unit-variance maps (LoS / NLoS) on a common grid,
    per TR 38.901 practice of independent per-state LSP fields; the value used
    on a link is sigma_state(h) * map_state(x, y). Map extent [m] covers the
    service area; UAV altitude enters through sigma only (horizontal-plane
    3GPP definition; see Assumption D2 for vertical handling).
    """

    def __init__(self, env, extent=(1000.0, 1000.0), dx=5.0,
                 d_corr=None, rng=None):
        from .large_scale import sf_std_aerial
        self.env = env
        self._sf_std = sf_std_aerial
        rng = np.random.default_rng(rng)
        self.dx = float(dx)
        nx = int(np.ceil(extent[0] / dx)) + 1
        ny = int(np.ceil(extent[1] / dx)) + 1
        self.d_corr = dict(
            LOS=(d_corr or P.SF_DCORR[(env, "LOS")]),
            NLOS=(d_corr or P.SF_DCORR[(env, "NLOS")]))
        self.maps = {s: spectral_map_2d(nx, ny, dx, self.d_corr[s], rng)
                     for s in ("LOS", "NLOS")}

    def sample(self, x, y, h, state):
        """SF value [dB] at ground position (x,y) for UAV altitude h."""
        m = self.maps[state]
        ny, nx = m.shape
        ix = np.clip(np.round(np.asarray(x, float) / self.dx).astype(int), 0, nx - 1)
        iy = np.clip(np.round(np.asarray(y, float) / self.dx).astype(int), 0, ny - 1)
        return self._sf_std(self.env, h, state) * m[iy, ix]
