"""Small-scale fading: TR 36.777 Alternative 1 (CDL-D pipeline) and
Alternative 2 (altitude-dependent LSPs), plus Doppler utilities and a
simplified single-polarisation CDL coefficient generator.

Simplifications (documented, Stage-2 v0.1):
  * coefficient generator is SISO, vertical polarisation only (the 2x2
    polarisation matrix of Eq. 7.5-22/28 and XPR draws are omitted);
    use the Sionna adapter for full-polarisation MIMO.
  * CDL-A/B/C are not embedded (no independently verifiable source in this
    environment); the Sionna adapter provides them.
"""
from __future__ import annotations
import numpy as np
from . import params as P

LN10 = P.LN10


# --------------------------------------------------------------- Alternative 2
def lsp_alt2(env, h, state):
    """TR 36.777 Tables B.1.2-1/2: (mu, sigma) of each lg-LSP at altitude h.

    Returns dict lsp -> (mu, sigma). K entry (dB) exists for LoS only.
    Raises for UMi (delegated to TR ref. [9]; open flag V1).
    """
    if env not in P.ALT2_LSP:
        raise NotImplementedError(
            "UMi-AV Alternative-2 LSPs are defined in TR 36.777 ref. [9] "
            "(external RAN1 contribution) - open flag V1. Use Alternative 1 "
            "(reverse-UMa) or Alternative 3 for UMi-AV.")
    lo, hi = P.AERIAL_PLOS[env]["band"]
    if not (lo < h <= hi):
        raise ValueError(f"Alt-2 tables apply to the aerial band ({lo},{hi}] m")
    out = {}
    for lsp, ((a, b), (c, d)) in P.ALT2_LSP[env][state].items():
        out[lsp] = (a * np.log10(h) + b, c * np.exp(d * h))
    return out


def draw_lsp_alt2(env, h, state, rng=None):
    """One random LSP realisation: DS [s], ASA/ASD/ZSA/ZSD [deg], K [dB]."""
    rng = np.random.default_rng(rng)
    stats = lsp_alt2(env, h, state)
    out = {}
    for lsp, (mu, sig) in stats.items():
        v = rng.normal(mu, sig)
        out[lsp.replace("lg", "")] = v if lsp == "K" else 10.0 ** v
    return out


# ----------------------------------------------------------------- CDL algebra
def _cdl_arrays(cdl):
    spec = cdl["specular"]
    cl = cdl["clusters"]
    delays = np.concatenate([[spec["delay"]], cl[:, 0]])
    powers = np.concatenate([[spec["power"]], cl[:, 1]])
    ang = {k: np.concatenate([[spec[k]], cl[:, i + 2]])
           for i, k in enumerate(("aod", "aoa", "zod", "zoa"))}
    return delays, powers, ang


def rms_ds(delays, powers_db):
    p = 10.0 ** (np.asarray(powers_db, float) / 10.0)
    t = np.asarray(delays, float)
    m = np.sum(p * t) / np.sum(p)
    return float(np.sqrt(np.sum(p * (t - m) ** 2) / np.sum(p)))


def k_model(cdl):
    """TR 38.901 Eq. (7.7.6-2): P1_LOS - 10 lg sum(10^{Pn/10}) over Laplacians."""
    lap = cdl["clusters"][:, 1]
    return float(cdl["specular"]["power"]
                 - 10.0 * np.log10(np.sum(10.0 ** (lap / 10.0))))


def k_first_cluster(cdl):
    """Within-first-cluster Rice factor (matches the TDL notes: D 13.3, E 22)."""
    return float(cdl["specular"]["power"] - cdl["clusters"][0, 1])


def scale_k(cdl, k_desired_db):
    """TR 38.901 Sec. 7.7.6: Pn_scaled = Pn - K_des + K_model on Laplacian
    clusters, then delay renormalisation to unit RMS DS. Returns new dict."""
    out = dict(specular=dict(cdl["specular"]),
               clusters=cdl["clusters"].copy(),
               **{k: cdl[k] for k in ("c_asd", "c_asa", "c_zsd", "c_zsa",
                                      "xpr_db")})
    km = k_model(cdl)
    out["clusters"][:, 1] = out["clusters"][:, 1] - k_desired_db + km
    d, p, _ = _cdl_arrays(out)
    ds = rms_ds(d, p)
    out["specular"]["delay"] /= ds
    out["clusters"][:, 0] /= ds
    return out


def scale_delays(cdl, ds_desired_s):
    """TR 38.901 Eq. (7.7-1): tau_scaled = tau_model * DS_desired."""
    out = dict(specular=dict(cdl["specular"]), clusters=cdl["clusters"].copy(),
               **{k: cdl[k] for k in ("c_asd", "c_asa", "c_zsd", "c_zsa",
                                      "xpr_db")})
    out["specular"]["delay"] *= ds_desired_s
    out["clusters"][:, 0] *= ds_desired_s
    return out


# ------------------------------------------------------------- angular spread
def ang_spread_deg(angles_deg, powers_db):
    """3GPP circular angular spread (TR 38.901 Annex A):
    AS = sqrt(2 ln(1/|sum P e^{j theta}| / sum P)) [rad] -> deg."""
    p = 10.0 ** (np.asarray(powers_db, float) / 10.0)
    th = np.deg2rad(np.asarray(angles_deg, float))
    r = np.abs(np.sum(p * np.exp(1j * th))) / np.sum(p)
    r = min(r, 1.0 - 1e-15)
    return float(np.rad2deg(np.sqrt(2.0 * np.log(1.0 / r))))


def _ray_angles(cluster_angles, c_spread, offsets=P.RAY_OFFSETS):
    """(N_cl, 20) per-ray angles: cluster angle + c * alpha_m (Eq. 7.7-0a)."""
    return np.asarray(cluster_angles, float)[:, None] + c_spread * offsets[None, :]


def composite_as(cdl, dim):
    """Composite ray-level AS of a CDL, dim in {aod,aoa,zod,zoa}."""
    d, p, ang = _cdl_arrays(cdl)
    c = {"aod": cdl["c_asd"], "aoa": cdl["c_asa"],
         "zod": cdl["c_zsd"], "zoa": cdl["c_zsa"]}[dim]
    rays = _ray_angles(ang[dim], c)
    ray_p = np.repeat(10.0 ** (p / 10.0) / rays.shape[1], rays.shape[1])
    # specular row: single ray at the cluster angle (no spread)
    rays_flat = rays.reshape(-1)
    rays_flat[0:rays.shape[1]] = ang[dim][0]   # specular cluster: no ray spread
    return ang_spread_deg(rays_flat, 10 * np.log10(ray_p))


def _wrap180(x):
    return (np.asarray(x, float) + 180.0) % 360.0 - 180.0


def scale_angles(cdl, desired: dict, los_drop: dict):
    """LoS-preserving angular scaling + translation (TR 38.901 Sec. 7.7.5.1,
    Eq. (7.7-6) variant, composed with translation of the LoS direction to the
    drop geometry as required by TR 36.777 B.1.1 Step 3).

    desired : {'aod':deg, 'aoa':deg, 'zod':deg, 'zoa':deg} target composite AS
    los_drop: {'aod','aoa','zod','zoa'} actual LoS angles of the drop [deg]
    Scale factor s per dimension solved by bisection so that the composite
    ray-level AS equals the desired one.
    """
    out = dict(specular=dict(cdl["specular"]), clusters=cdl["clusters"].copy(),
               **{k: cdl[k] for k in ("c_asd", "c_asa", "c_zsd", "c_zsa",
                                      "xpr_db")})
    _, p, ang = _cdl_arrays(cdl)
    cmap = {"aod": "c_asd", "aoa": "c_asa", "zod": "c_zsd", "zoa": "c_zsa"}
    colmap = {"aod": 2, "aoa": 3, "zod": 4, "zoa": 5}
    for dim, as_des in desired.items():
        base = ang[dim]
        los_model = base[0]
        rel = _wrap180(base - los_model)

        def as_of(s):
            trial = dict(out)
            ang_s = los_model + s * rel
            trial = dict(specular=dict(out["specular"]),
                         clusters=out["clusters"].copy(),
                         **{k: out[k] for k in ("c_asd", "c_asa", "c_zsd",
                                                "c_zsa", "xpr_db")})
            trial["specular"][dim] = ang_s[0]
            trial["clusters"][:, colmap[dim]] = ang_s[1:]
            trial[cmap[dim]] = s * cdl[cmap[dim]]
            return composite_as(trial, dim)

        lo_s, hi_s = 1e-4, 4.0
        if as_of(hi_s) < as_des:
            s = hi_s
        else:
            for _ in range(60):
                mid = 0.5 * (lo_s + hi_s)
                if as_of(mid) < as_des:
                    lo_s = mid
                else:
                    hi_s = mid
            s = 0.5 * (lo_s + hi_s)
        ang_s = los_drop[dim] + s * rel        # translate LoS to drop geometry
        out["specular"][dim] = ang_s[0]
        out["clusters"][:, colmap[dim]] = ang_s[1:]
        out[cmap[dim]] = s * cdl[cmap[dim]]
    return out


# ----------------------------------------------------- TR 36.777 B.1.1 Step 5
def zod_offset_los_deg(env, d2d, h_ut, h_bs=None, h_roof=P.H_ROOF_DEFAULT):
    """LoS ZOD offset added to non-direct clusters (Eqs. B.1.1-1 / B.1.1-2)."""
    if h_bs is None:
        h_bs = {"RMa": 35.0, "UMa": 25.0}[env]
    if env == "RMa":
        t1 = np.arctan((h_bs + h_ut) / d2d)
    elif env == "UMa":
        t1 = np.arctan((h_bs + h_ut - 2.0 * h_roof) / d2d)
    else:
        raise ValueError("ZOD offset defined for RMa-AV and UMa-AV only")
    t2 = np.arctan((h_ut - h_bs) / d2d)
    return float(np.rad2deg(t1 + t2))


def alt1_cdl(env, d2d, h_ut, state, los_angles, h_bs=None,
             h_roof=P.H_ROOF_DEFAULT):
    """Full TR 36.777 B.1.1 pipeline -> scaled CDL-D ready for generation.

    los_angles: dict aod/aoa/zod/zoa of the drop's LoS direction [deg].
    Steps: angle scale+translate (B.1.1 Step 3), K scaling (Step 4),
    DS scaling (Step 4), LoS ZOD offset on non-direct clusters (Step 5;
    NLoS offset = 0 per Step 6).
    """
    des = P.ALT1_DESIRED[(env, state)]
    cdl = scale_angles(P.CDL_D,
                       {"aod": des["ASD"], "aoa": des["ASA"],
                        "zod": des["ZSD"], "zoa": des["ZSA"]}, los_angles)
    cdl = scale_k(cdl, des["K"])
    cdl = scale_delays(cdl, des["DS"] * 1e-9)
    if state == "LOS":
        off = zod_offset_los_deg(env, d2d, h_ut, h_bs, h_roof)
        cdl["clusters"][:, 4] = cdl["clusters"][:, 4] + off
    return cdl


# ------------------------------------------------------------------- Doppler
def unit_vec(az_deg, zen_deg):
    """Spherical unit vector, 3GPP GCS (Eq. 7.5-23)."""
    az, zen = np.deg2rad(az_deg), np.deg2rad(zen_deg)
    return np.stack([np.sin(zen) * np.cos(az),
                     np.sin(zen) * np.sin(az),
                     np.cos(zen)], axis=-1)


def velocity_vec(speed, az_deg, zen_deg=90.0):
    """v * [sin th_v cos ph_v, sin th_v sin ph_v, cos th_v] (Eq. 7.5-25)."""
    return speed * unit_vec(az_deg, zen_deg).reshape(3)


def fd_max(speed, fc_ghz):
    return speed * fc_ghz * 1e9 / P.C_LIGHT


def coherence_time(speed, fc_ghz):
    """Clarke rule-of-thumb Tc ~ 0.423 / fD,max."""
    return 0.423 / fd_max(speed, fc_ghz)


def gen_channel(cdl, fc_ghz, t, v_rx=(0.0, 0.0, 0.0), v_tx=(0.0, 0.0, 0.0),
                rng=None, n_rays=20):
    """Simplified SISO CDL coefficient time series (single polarisation).

    Per TR 38.901 Sec. 7.7.1 Step 4 / Sec. 7.5 Steps 10-11 with the
    polarisation matrix omitted. Doppler includes both link ends
    (dual mobility, Sec. 7.6.3.2): nu = (r_rx . v_rx + r_tx . v_tx)/lambda.
    Returns (H[t] complex array normalised to unit mean power, tau_n delays).
    """
    rng = np.random.default_rng(rng)
    lam = P.C_LIGHT / (fc_ghz * 1e9)
    t = np.asarray(t, float)
    delays, powers_db, ang = _cdl_arrays(cdl)
    p_lin = 10.0 ** (powers_db / 10.0)
    p_lin = p_lin / p_lin.sum()
    H = np.zeros(t.shape, complex)
    for n in range(len(delays)):
        if n == 0:  # specular LoS ray: deterministic angles, no spread
            r_rx = unit_vec(ang["aoa"][0], ang["zoa"][0])
            r_tx = unit_vec(ang["aod"][0], ang["zod"][0])
            nu = (r_rx @ np.asarray(v_rx) + r_tx @ np.asarray(v_tx)) / lam
            H += np.sqrt(p_lin[0]) * np.exp(1j * 2 * np.pi * nu * t)
            continue
        aoa = ang["aoa"][n] + cdl["c_asa"] * P.RAY_OFFSETS[:n_rays]
        aod = ang["aod"][n] + cdl["c_asd"] * P.RAY_OFFSETS[:n_rays]
        zoa = ang["zoa"][n] + cdl["c_zsa"] * P.RAY_OFFSETS[:n_rays]
        zod = ang["zod"][n] + cdl["c_zsd"] * P.RAY_OFFSETS[:n_rays]
        rng.shuffle(aoa)   # random ray coupling (Sec. 7.7.1 Step 2)
        rng.shuffle(zoa)
        phi = rng.uniform(-np.pi, np.pi, n_rays)
        r_rx = unit_vec(aoa, zoa)
        r_tx = unit_vec(aod, zod)
        nu = (r_rx @ np.asarray(v_rx) + r_tx @ np.asarray(v_tx)) / lam
        ray_sum = np.exp(1j * (phi[:, None] + 2 * np.pi * nu[:, None] * t[None, :]))
        H += np.sqrt(p_lin[n] / n_rays) * ray_sum.sum(axis=0)
    return H, delays
