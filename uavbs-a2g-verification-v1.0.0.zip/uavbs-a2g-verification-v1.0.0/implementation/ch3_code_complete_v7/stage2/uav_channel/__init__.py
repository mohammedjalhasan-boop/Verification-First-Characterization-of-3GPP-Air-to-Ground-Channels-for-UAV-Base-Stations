"""uav_channel -- Stage-2 implementation of the Chapter-3 A2G channel.

3GPP TR 36.777 V15.0.0 Annex B (aerial) + TR 38.901 V19.4.0 (terrestrial,
CDL, correlation): LoS probability, path loss, correlated shadow fading,
CDL-D small-scale pipeline, Doppler, coverage-optimal altitude, and DRL
lookup-table export.

Dissertation: "Constraint-Aware DRL Frameworks for Sustainable Multi-UAV
B5G Networks" (M. J. Alhasan), Chapter 3 / Objective 1.
"""
from . import params
from .large_scale import (d3d, fspl, plos, plos_aerial, plos_terrestrial,
                          dplos_dh, path_loss, pl_los_aerial, pl_nlos_aerial,
                          pl_terrestrial, sf_std, sf_std_aerial, p_cov, g_dh,
                          mean_pl_db, mean_gain_lin)
from .shadowing import (ar1_trajectory, spectral_map_2d, correlated_points,
                        SFGenerator)
from .altitude import h_wall, h_star, h_star_refined, hstar_table
from .small_scale import (lsp_alt2, draw_lsp_alt2, rms_ds, k_model,
                          k_first_cluster, scale_k, scale_delays,
                          ang_spread_deg, composite_as, scale_angles,
                          zod_offset_los_deg, alt1_cdl, fd_max,
                          coherence_time, velocity_vec, gen_channel)
from .lookup import build_rows, export_core_csv, export_dense_npz

__version__ = "0.1.0"
