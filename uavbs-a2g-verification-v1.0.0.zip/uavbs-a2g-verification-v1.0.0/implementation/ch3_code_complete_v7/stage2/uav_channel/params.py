"""Single source of truth for every 3GPP constant used by the package.

Provenance (all values transcribed from the source documents in Stage 1 and
cross-checked numerically; see tests/):
  [R1] 3GPP TR 38.901 V19.4.0 (ETSI TR 138 901 V19.4.0, 2026-07)
  [R2] 3GPP TR 36.777 V15.0.0 (2017-12), Annex B
Do not edit values here without re-running the test suite.
"""
from __future__ import annotations
import numpy as np

C_LIGHT = 3.0e8          # 3GPP convention (TR 38.901 Table 7.4.1-1 Notes 1/5)
LN10 = np.log(10.0)
H_G_DEFAULT = 1.5        # ground-terminal height [m] (Assumption A2)

ENVS = ("UMa", "UMi", "RMa")

# ---------------------------------------------------------------- TR 36.777 B-1
# P_LoS aerial band: p1 = ap*lg(h) - bp  (floored at p_floor if given)
#                    d1 = max(ad*lg(h) - bd, d_floor)
AERIAL_PLOS = {
    "UMa": dict(ap=4300.0, bp=3800.0, p_floor=None,   ad=460.0,  bd=700.0,
                d_floor=18.0, h_sat=100.0, band=(22.5, 300.0)),
    "UMi": dict(ap=233.98, bp=0.95,   p_floor=None,   ad=294.05, bd=432.94,
                d_floor=18.0, h_sat=None,  band=(22.5, 300.0)),
    "RMa": dict(ap=15021.0, bp=16053.0, p_floor=1000.0, ad=1350.8, bd=1602.0,
                d_floor=18.0, h_sat=40.0, band=(10.0, 300.0)),
}
# terrestrial/aerial crossover altitude (Table B-1 partition)
BAND_CROSSOVER = {"UMa": 22.5, "UMi": 22.5, "RMa": 10.0}

# ---------------------------------------------------------------- TR 36.777 B-2
# Aerial path loss:  PL = A0 + intercept(fc) + (a - b*lg h)*lg d3D   [+ guards]
# intercept kind: 'fc'    -> 20*lg(fc)
#                 'rma'   -> 20*lg(40*pi*fc/3) = 32.444 + 20*lg(fc)
AERIAL_PL = {
    ("UMa", "LOS"):  dict(A0=28.0,  a=22.0,  b=0.0, icpt="fc",
                          h_rng=(22.5, 300.0), d2d_max=4000.0, guard=None),
    ("UMa", "NLOS"): dict(A0=-17.5, a=46.0,  b=7.0, icpt="rma",
                          h_rng=(10.0, 100.0), d2d_max=4000.0, guard=None),
    ("UMi", "LOS"):  dict(A0=30.9,  a=22.25, b=0.5, icpt="fc",
                          h_rng=(22.5, 300.0), d2d_max=4000.0, guard="fspl"),
    ("UMi", "NLOS"): dict(A0=32.4,  a=43.2,  b=7.6, icpt="fc",
                          h_rng=(22.5, 300.0), d2d_max=4000.0, guard="los"),
    ("RMa", "LOS"):  dict(A0=0.0,   a=23.9,  b=1.8, icpt="rma",
                          h_rng=(10.0, 300.0), d2d_max=10000.0, guard="slope20"),
    ("RMa", "NLOS"): dict(A0=-12.0, a=35.0,  b=5.3, icpt="rma",
                          h_rng=(10.0, 300.0), d2d_max=10000.0, guard="los"),
}

# ---------------------------------------------------------------- TR 36.777 B-3
# Aerial shadow fading:  LoS  sigma = s0*exp(-kappa*h)   (floored if s_floor)
#                        NLoS sigma = const
AERIAL_SF = {
    "UMa": dict(s0=4.64, kappa=0.0066, s_floor=None, sig_nlos=6.0,
                nlos_h_rng=(22.5, 100.0)),
    "UMi": dict(s0=5.0,  kappa=0.01,   s_floor=2.0,  sig_nlos=8.0,
                nlos_h_rng=(22.5, 300.0)),
    "RMa": dict(s0=4.2,  kappa=0.0046, s_floor=None, sig_nlos=6.0,
                nlos_h_rng=(10.0, 40.0)),
}

# --------------------------------------------- TR 38.901 Table 7.5-6 (Parts 1-2)
# SF correlation distances, horizontal plane [m]
SF_DCORR = {("UMa", "LOS"): 37.0, ("UMa", "NLOS"): 50.0,
            ("UMi", "LOS"): 10.0, ("UMi", "NLOS"): 13.0,
            ("RMa", "LOS"): 37.0, ("RMa", "NLOS"): 120.0}
# terrestrial K-factor statistics [dB] (LoS): mu, sigma
K_TERR = {"UMa": (9.0, 3.5), "UMi": (9.0, 5.0), "RMa": (7.0, 4.0)}

# ------------------------------------------ TR 38.901 Table 7.6.3.1-2 (spatial
# consistency correlation distances [m]): cluster/ray RVs (LOS/NLOS/O2I), state
SPATIAL_CONSISTENCY = {
    "UMa": dict(cluster=(40.0, 50.0, 15.0), state=50.0),
    "UMi": dict(cluster=(12.0, 15.0, 15.0), state=50.0),
    "RMa": dict(cluster=(50.0, 60.0, 15.0), state=60.0),
}

# ------------------------------------------------- TR 38.901 terrestrial models
TERR = {
    "UMa": dict(h_bs=25.0, sig_los=4.0, sig_nlos=6.0),
    "UMi": dict(h_bs=10.0, sig_los=4.0, sig_nlos=7.82),
    "RMa": dict(h_bs=35.0, sig_los_pre=4.0, sig_los_post=6.0, sig_nlos=8.0,
                W=20.0, h_bld=5.0),
}

# ------------------------------------------------ TR 36.777 Tables B.1.1-1/2
# Alternative 1 desired values: AS in degrees, K in dB, DS in ns
ALT1_DESIRED = {
    ("RMa", "LOS"):  dict(ASA=0.2, ASD=0.2, ZSA=0.1, ZSD=0.1, K=20.0, DS=10.0),
    ("RMa", "NLOS"): dict(ASA=0.5, ASD=0.5, ZSA=0.2, ZSD=0.2, K=10.0, DS=30.0),
    ("UMa", "LOS"):  dict(ASA=0.5, ASD=0.5, ZSA=0.1, ZSD=0.1, K=20.0, DS=10.0),
    ("UMa", "NLOS"): dict(ASA=1.0, ASD=1.0, ZSA=0.3, ZSD=0.3, K=10.0, DS=30.0),
}
H_ROOF_DEFAULT = 20.0     # Assumption A3 ([VERIFY V2]): rooftop height in (B.1.1-2)

# ------------------------------------------------ TR 36.777 Tables B.1.2-1/2
# Alternative 2 LSPs: mu = a*lg(h) + b ; sigma = c*exp(d*h)
# lg-domain for DS/ASA/ASD/ZSA/ZSD (log10 of s or deg); K directly in dB.
ALT2_LSP = {
    "RMa": {
        "LOS": dict(lgDS=((0.0549, -8.0945), (1.1879, -0.0086)),
                    lgASA=((-2.214, -1.1645), (2.5622, -0.00251)),
                    lgASD=((-1.431, -0.89),   (2.2056,  0.0008)),
                    lgZSA=((-0.2409, -0.1569), (0.7579, -0.0069)),
                    lgZSD=((0.8105, -0.9774), (0.7106, -0.0068)),
                    K=((22.55, -4.72), (6.988, 0.01659))),
        "NLOS": dict(lgDS=((-1.3465, -7.0805), (1.5546, 0.0043)),
                     lgASA=((-1.602, 1.439),   (1.5316, -0.0056)),
                     lgASD=((-1.4633, 0.5212), (1.357,  0.0018)),
                     lgZSA=((-1.097, 0.3287),  (1.631, -0.0087)),
                     lgZSD=((-0.869, -1.2355), (1.5851, -0.0079))),
    },
    "UMa": {
        "LOS": dict(lgDS=((-0.31, -6.845),   (0.7294, 0.0014)),
                    lgASA=((-2.4985, -1.602), (1.0389, 0.0085)),
                    lgASD=((-0.0135, 1.345),  (1.0188, -0.0001)),
                    lgZSA=((-0.2895, 0.225),  (0.9576, -0.0018)),
                    lgZSD=((-0.2975, -0.5798), (1.0757, 0.0059)),
                    K=((4.217, 5.787), (8.158, 0.0046))),
        "NLOS": dict(lgDS=((0.0965, -7.503),  (0.9745, -0.0045)),
                     lgASA=((-2.266, -2.666), (1.022,  0.009944)),
                     lgASD=((1.17, -0.665),   (1.2387, -0.0046)),
                     lgZSA=((-0.0005, -0.4695), (1.6237, -0.0076)),
                     lgZSD=((0.925, -2.725),  (1.6421, -0.0092))),
    },
    # UMi-AV Alternative 2 is delegated by TR 36.777 B.1.2 to its ref. [9]
    # (external RAN1 contribution) -> [VERIFY V1]; not implemented.
}

# ------------------------------------------------ TR 38.901 Table 7.5-3
# Ray offset angles (rms spread normalised to 1), 20 rays
RAY_OFFSETS = np.array([0.0447, -0.0447, 0.1413, -0.1413, 0.2492, -0.2492,
                        0.3715, -0.3715, 0.5129, -0.5129, 0.6797, -0.6797,
                        0.8844, -0.8844, 1.1481, -1.1481, 1.5195, -1.5195,
                        2.1551, -2.1551])

# ------------------------------------------------ TR 38.901 Table 7.7.1-4 CDL-D
# columns: normalized delay, power dB, AOD, AOA, ZOD, ZOA (deg)
# cluster 1 = specular (LOS path) + Laplacian sub-cluster (same angles).
CDL_D = dict(
    specular=dict(delay=0.0, power=-0.2, aod=0.0, aoa=-180.0, zod=98.5, zoa=81.5),
    clusters=np.array([
        # delay    P[dB]   AOD     AOA     ZOD    ZOA
        [0.0,     -13.5,   0.0,  -180.0,  98.5,  81.5],
        [0.035,   -18.8,  89.2,   89.2,  85.5,  86.9],
        [0.612,   -21.0,  89.2,   89.2,  85.5,  86.9],
        [1.363,   -22.8,  89.2,   89.2,  85.5,  86.9],
        [1.405,   -17.9,  13.0,  163.0,  97.5,  79.4],
        [1.804,   -20.1,  13.0,  163.0,  97.5,  79.4],
        [2.596,   -21.9,  13.0,  163.0,  97.5,  79.4],
        [1.775,   -22.9,  34.6, -137.0,  98.5,  78.2],
        [4.042,   -27.8, -64.5,   74.5,  88.4,  73.6],
        [7.937,   -23.6, -32.9,  127.7,  91.3,  78.3],
        [9.424,   -24.8,  52.6, -119.6, 103.8,  87.0],
        [9.708,   -30.0, -132.1,  -9.1,  80.3,  70.6],
        [12.525,  -27.7,  77.2,  -83.8,  86.5,  72.9]]),
    c_asd=5.0, c_asa=8.0, c_zsd=3.0, c_zsa=3.0, xpr_db=11.0)

# ------------------------------------------------ TR 38.901 Table 7.7.1-5 CDL-E
CDL_E = dict(
    specular=dict(delay=0.0, power=-0.03, aod=0.0, aoa=-180.0, zod=99.6, zoa=80.4),
    clusters=np.array([
        [0.0,     -22.03,   0.0, -180.0,  99.6,  80.4],
        [0.5133,  -15.8,   57.5,   18.2, 104.2,  80.4],
        [0.5440,  -18.1,   57.5,   18.2, 104.2,  80.4],
        [0.5630,  -19.8,   57.5,   18.2, 104.2,  80.4],
        [0.5440,  -22.9,  -20.1,  101.8,  99.4,  80.8],
        [0.7112,  -22.4,   16.2,  112.9, 100.8,  86.3],
        [1.9092,  -18.6,    9.3, -155.5,  98.8,  82.7],
        [1.9293,  -20.8,    9.3, -155.5,  98.8,  82.7],
        [1.9589,  -22.6,    9.3, -155.5,  98.8,  82.7],
        [2.6426,  -22.3,   19.0, -143.3, 100.8,  82.9],
        [3.7136,  -25.6,   32.7,  -94.7,  96.4,  88.0],
        [5.4524,  -20.2,    0.5,  147.0,  98.9,  81.0],
        [12.0034, -29.8,   55.9,  -36.2,  95.6,  88.6],
        [20.6419, -29.2,  -26.0,  104.6, 104.6,  78.3]]),
    c_asd=5.0, c_asa=11.0, c_zsd=3.0, c_zsa=7.0, xpr_db=8.0)

# NOTE: CDL-A/B/C (NLoS profiles, 23/23/24 clusters) are deliberately NOT
# hand-embedded: without an independent machine-readable source in this
# environment a transcription cannot be verified. The Sionna adapter loads them
# from the installed sionna package (see sionna_adapter.load_cdl_tables).

FREQS_GHZ = (2.6, 3.5, 28.0)
OUTLINE_GRID = dict(h=(30.0, 50.0, 100.0, 150.0, 200.0, 300.0),
                    d2d=(50.0, 100.0, 200.0, 500.0, 1000.0),
                    fc=FREQS_GHZ, d_corr=(5.0, 25.0, 50.0))
