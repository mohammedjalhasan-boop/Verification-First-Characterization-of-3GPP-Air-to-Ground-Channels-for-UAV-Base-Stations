"""Optimal-altitude machinery (Stage-1 Sec. 7): LoS wall, h* solver, maps."""
from __future__ import annotations
import numpy as np
from . import params as P
from .large_scale import p_cov, g_dh


def h_wall(env, d2d):
    """Closed-form LoS wall h_1(r) = min{10^{(r+c_d)/a_d}, h_cap} (Eq. 32)."""
    cfg = P.AERIAL_PLOS[env]
    r = np.asarray(d2d, dtype=float)
    cap = cfg["h_sat"] if cfg["h_sat"] is not None else cfg["band"][1]
    hw = np.where(r <= cfg["d_floor"], cfg["band"][0],
                  10.0 ** ((r + cfg["bd"]) / cfg["ad"]))
    out = np.minimum(hw, cap)
    return out if out.ndim else float(out)


def h_star(env, d2d, fc, l_max, step=0.05, plateau_eps=1e-4,
           plateau_span=50.0):
    """Coverage-optimal altitude on the aerial band.

    Returns dict: h_star, p_max, regime in {'wall','interior','plateau',
    'ceiling','none'}, h_plateau_lo (lowest altitude within plateau_eps of the
    max -- the energy tie-break altitude), n_modes (sign changes of dP/dh).
    """
    lo, hi = P.AERIAL_PLOS[env]["band"]
    hgrid = np.arange(lo + step, hi, step)
    pc = p_cov(env, float(d2d), hgrid, float(fc), float(l_max))
    i = int(np.argmax(pc))
    hstar, pmax = float(hgrid[i]), float(pc[i])
    near = pc >= pmax - plateau_eps
    h_lo_plateau = float(hgrid[near][0])
    span = float(hgrid[near][-1] - hgrid[near][0])
    d = np.diff(pc)
    sgn = np.sign(d); sgn = sgn[sgn != 0]
    n_modes = int(np.sum(sgn[1:] != sgn[:-1]))
    hw = h_wall(env, d2d)
    if pmax < 1e-3:
        regime = "none"
    elif span > plateau_span:
        regime = "plateau"
    elif abs(hstar - hw) < 2 * step + 1e-9:
        regime = "wall"
    elif abs(hstar - (hi - step)) < 2 * step:
        regime = "ceiling"
    else:
        regime = "interior"
    return dict(h_star=hstar, p_max=pmax, regime=regime,
                h_plateau_lo=h_lo_plateau, plateau_span=span,
                n_modes=n_modes, h_wall=float(hw))


def h_star_refined(env, d2d, fc, l_max, tol=1e-3):
    """Grid solution refined by bisection on the analytic derivative G."""
    res = h_star(env, d2d, fc, l_max)
    if res["regime"] != "interior":
        return res
    a, b = res["h_star"] - 0.1, res["h_star"] + 0.1
    ga = g_dh(env, d2d, a, fc, l_max)
    gb = g_dh(env, d2d, b, fc, l_max)
    if ga * gb < 0:
        while b - a > tol:
            m = 0.5 * (a + b)
            if g_dh(env, d2d, m, fc, l_max) * ga > 0:
                a = m
            else:
                b = m
        res["h_star"] = 0.5 * (a + b)
        res["p_max"] = float(p_cov(env, d2d, res["h_star"], fc, l_max))
    return res


def hstar_table(envs=P.ENVS, d2d_list=(100, 200, 500, 1000),
                fc_list=P.FREQS_GHZ, lmax_list=(110.0, 120.0, 130.0)):
    """Long-format optimal-altitude map (list of dict rows)."""
    rows = []
    for env in envs:
        for fc in fc_list:
            for r in d2d_list:
                for lm in lmax_list:
                    res = h_star_refined(env, r, fc, lm)
                    rows.append(dict(env=env, fc_ghz=fc, d2d_m=r, l_max_db=lm,
                                     **res))
    return rows
