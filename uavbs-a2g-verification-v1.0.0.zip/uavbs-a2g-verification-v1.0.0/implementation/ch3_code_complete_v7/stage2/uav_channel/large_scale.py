"""Large-scale A2G channel: LoS probability, path loss, shadow-fading std,
coverage probability and its altitude derivative.

Implements TR 36.777 Annex B (aerial band) + TR 38.901 Tables 7.4.1-1/7.4.2-1
(terrestrial band). All functions are NumPy-vectorised over (d2d, h) and accept
scalars or broadcastable arrays. States: "LOS" / "NLOS".

Conventions: fc in GHz, distances/heights in m, PL/sigma in dB.
"""
from __future__ import annotations
import numpy as np
from . import params as P

LN10 = P.LN10


# ----------------------------------------------------------------- geometry
def d3d(d2d, h, h_g=P.H_G_DEFAULT):
    d2d = np.asarray(d2d, dtype=float)
    h = np.asarray(h, dtype=float)
    return np.hypot(d2d, h - h_g)


def fspl(d, fc):
    """Free-space PL, 3GPP c=3e8 convention: 32.444 + 20lg d + 20lg fc."""
    return 20.0 * np.log10(40.0 * np.pi / 3.0) + 20.0 * np.log10(d) \
        + 20.0 * np.log10(fc)


def _icpt(kind, fc):
    if kind == "fc":
        return 20.0 * np.log10(fc)
    return 20.0 * np.log10(40.0 * np.pi * np.asarray(fc, float) / 3.0)


# ----------------------------------------------------------- P_LoS (aerial)
def _p1_d1(env, h):
    cfg = P.AERIAL_PLOS[env]
    lg = np.log10(h)
    p1 = cfg["ap"] * lg - cfg["bp"]
    if cfg["p_floor"] is not None:
        p1 = np.maximum(p1, cfg["p_floor"])
    d1 = np.maximum(cfg["ad"] * lg - cfg["bd"], cfg["d_floor"])
    return p1, d1


def plos_aerial(env, d2d, h):
    d2d, h = np.broadcast_arrays(np.asarray(d2d, float), np.asarray(h, float))
    p1, d1 = _p1_d1(env, h)
    with np.errstate(divide="ignore", invalid="ignore"):
        pl = d1 / d2d + np.exp(-d2d / p1) * (1.0 - d1 / d2d)
    pl = np.where(d2d <= d1, 1.0, pl)
    h_sat = P.AERIAL_PLOS[env]["h_sat"]
    if h_sat is not None:
        pl = np.where(h > h_sat, 1.0, pl)
    return pl if pl.ndim else float(pl)


def plos_terrestrial(env, d2d, h):
    """TR 38.901 Table 7.4.2-1 (d = d2D-out)."""
    d, h = np.broadcast_arrays(np.asarray(d2d, float), np.asarray(h, float))
    with np.errstate(divide="ignore", invalid="ignore"):
        if env == "RMa":
            pl = np.where(d <= 10.0, 1.0, np.exp(-(d - 10.0) / 1000.0))
        elif env == "UMi":
            base = 18.0 / d + np.exp(-d / 36.0) * (1.0 - 18.0 / d)
            pl = np.where(d <= 18.0, 1.0, base)
        else:  # UMa
            base = 18.0 / d + np.exp(-d / 63.0) * (1.0 - 18.0 / d)
            cp = np.where(h <= 13.0, 0.0,
                          ((np.clip(h, 13.0, 23.0) - 13.0) / 10.0) ** 1.5)
            fac = 1.0 + cp * 1.25 * (d / 100.0) ** 3 * np.exp(-d / 150.0)
            pl = np.where(d <= 18.0, 1.0, base * fac)
    return np.clip(pl, 0.0, 1.0) if np.ndim(pl) else float(np.clip(pl, 0, 1))


def plos(env, d2d, h):
    """Unified piecewise P_LoS (terrestrial below crossover, aerial above)."""
    d2d, h = np.broadcast_arrays(np.asarray(d2d, float), np.asarray(h, float))
    cross = P.BAND_CROSSOVER[env]
    out = np.where(h <= cross,
                   plos_terrestrial(env, d2d, h),
                   plos_aerial(env, d2d, np.maximum(h, cross + 1e-9)))
    return out if out.ndim else float(out)


def dplos_dh(env, d2d, h):
    """Analytic altitude derivative of aerial-band P_LoS (Lemma 3.1)."""
    d2d, h = np.broadcast_arrays(np.asarray(d2d, float), np.asarray(h, float))
    cfg = P.AERIAL_PLOS[env]
    p1, d1 = _p1_d1(env, h)
    lg = np.log10(h)
    on_p_floor = (cfg["p_floor"] is not None) & \
        (cfg["ap"] * lg - cfg["bp"] < (cfg["p_floor"] or 0.0))
    on_d_floor = cfg["ad"] * lg - cfg["bd"] < cfg["d_floor"]
    E = np.exp(-d2d / p1)
    t1 = np.where(on_d_floor, 0.0,
                  (cfg["ad"] / (h * LN10)) * (1.0 - E) / d2d)
    t2 = np.where(on_p_floor, 0.0,
                  (cfg["ap"] / (h * LN10)) * E * (d2d / p1 ** 2)
                  * (1.0 - d1 / d2d))
    g = t1 + t2
    g = np.where(d2d <= d1, 0.0, g)
    h_sat = cfg["h_sat"]
    if h_sat is not None:
        g = np.where(h > h_sat, 0.0, g)
    return g if g.ndim else float(g)


# ------------------------------------------------------- path loss (aerial)
def _pl_affine(env, state, d2d, h, fc, h_g):
    cfg = P.AERIAL_PL[(env, state)]
    d = d3d(d2d, h, h_g)
    B = cfg["a"] - cfg["b"] * np.log10(h)
    if cfg["guard"] == "slope20":            # RMa LoS slope floor
        B = np.maximum(B, 20.0)
    return cfg["A0"] + _icpt(cfg["icpt"], fc) + B * np.log10(d)


def pl_los_aerial(env, d2d, h, fc, h_g=P.H_G_DEFAULT):
    v = _pl_affine(env, "LOS", d2d, h, fc, h_g)
    if P.AERIAL_PL[(env, "LOS")]["guard"] == "fspl":   # UMi
        v = np.maximum(v, fspl(d3d(d2d, h, h_g), fc))
    return v


def pl_nlos_aerial(env, d2d, h, fc, h_g=P.H_G_DEFAULT):
    v = _pl_affine(env, "NLOS", d2d, h, fc, h_g)
    if P.AERIAL_PL[(env, "NLOS")]["guard"] == "los":   # UMi, RMa
        v = np.maximum(v, pl_los_aerial(env, d2d, h, fc, h_g))
    # UMa-AV NLoS: no guard in TR 36.777 (verbatim) -- returned as-is.
    return v


# --------------------------------------------------- path loss (terrestrial)
def _dbp_eff(h_bs, h_ut, fc, h_e=1.0):
    return 4.0 * np.maximum(h_bs - h_e, 1e-9) * np.maximum(h_ut - h_e, 1e-9) \
        * (np.asarray(fc, float) * 1e9) / P.C_LIGHT


def pl_terrestrial(env, d2d, h_ut, fc, state):
    """TR 38.901 Table 7.4.1-1 (UMa/UMi/RMa), deterministic h_E = 1 m.

    Included for lookup-table completeness only (Assumption A4): for a UAV at
    UE-like heights neither node matches the 38.901 geometry.
    """
    d2, h = np.broadcast_arrays(np.asarray(d2d, float), np.asarray(h_ut, float))
    if env == "RMa":
        t = P.TERR["RMa"]; hb, W, hh = t["h_bs"], t["W"], t["h_bld"]
        d3 = np.hypot(d2, hb - h)
        dbp = 2.0 * np.pi * hb * np.maximum(h, 1.0) * (fc * 1e9) / P.C_LIGHT
        a1 = np.minimum(0.03 * hh ** 1.72, 10.0)
        a2 = np.minimum(0.044 * hh ** 1.72, 14.77)
        pl1 = (20 * np.log10(40 * np.pi * d3 * fc / 3.0) + a1 * np.log10(d3)
               - a2 + 0.002 * np.log10(hh) * d3)
        d3bp = np.hypot(dbp, hb - h)
        pl1bp = (20 * np.log10(40 * np.pi * d3bp * fc / 3.0)
                 + a1 * np.log10(d3bp) - a2 + 0.002 * np.log10(hh) * d3bp)
        pl_los = np.where(d2 <= dbp, pl1, pl1bp + 40 * np.log10(d3 / d3bp))
        if state == "LOS":
            return pl_los
        pln = (161.04 - 7.1 * np.log10(W) + 7.5 * np.log10(hh)
               - (24.37 - 3.7 * (hh / hb) ** 2) * np.log10(hb)
               + (43.42 - 3.1 * np.log10(hb)) * (np.log10(d3) - 3.0)
               + 20 * np.log10(fc)
               - (3.2 * np.log10(11.75 * np.maximum(h, 1.0)) ** 2 - 4.97))
        return np.maximum(pl_los, pln)
    hb = P.TERR[env]["h_bs"]
    d3 = np.hypot(d2, hb - h)
    dbp = _dbp_eff(hb, h, fc)
    if env == "UMa":
        pl1 = 28.0 + 22 * np.log10(d3) + 20 * np.log10(fc)
        pl2 = (28.0 + 40 * np.log10(d3) + 20 * np.log10(fc)
               - 9 * np.log10(dbp ** 2 + (hb - h) ** 2))
        pl_los = np.where(d2 <= dbp, pl1, pl2)
        if state == "LOS":
            return pl_los
        pln = 13.54 + 39.08 * np.log10(d3) + 20 * np.log10(fc) - 0.6 * (h - 1.5)
        return np.maximum(pl_los, pln)
    # UMi
    pl1 = 32.4 + 21 * np.log10(d3) + 20 * np.log10(fc)
    pl2 = (32.4 + 40 * np.log10(d3) + 20 * np.log10(fc)
           - 9.5 * np.log10(dbp ** 2 + (hb - h) ** 2))
    pl_los = np.where(d2 <= dbp, pl1, pl2)
    if state == "LOS":
        return pl_los
    pln = 35.3 * np.log10(d3) + 22.4 + 21.3 * np.log10(fc) - 0.3 * (h - 1.5)
    return np.maximum(pl_los, pln)


def path_loss(env, d2d, h, fc, state, h_g=P.H_G_DEFAULT):
    """Unified piecewise PL (terrestrial below crossover, aerial above)."""
    d2d, h = np.broadcast_arrays(np.asarray(d2d, float), np.asarray(h, float))
    cross = P.BAND_CROSSOVER[env]
    ha = np.maximum(h, cross + 1e-9)
    aerial = (pl_los_aerial(env, d2d, ha, fc, h_g) if state == "LOS"
              else pl_nlos_aerial(env, d2d, ha, fc, h_g))
    out = np.where(h <= cross, pl_terrestrial(env, d2d, h, fc, state), aerial)
    return out if out.ndim else float(out)


# ------------------------------------------------------------ shadow fading
def sf_std_aerial(env, h, state):
    h = np.asarray(h, dtype=float)
    cfg = P.AERIAL_SF[env]
    if state == "LOS":
        s = cfg["s0"] * np.exp(-cfg["kappa"] * h)
        if cfg["s_floor"] is not None:
            s = np.maximum(s, cfg["s_floor"])
        return s if s.ndim else float(s)
    s = np.full_like(h, cfg["sig_nlos"])
    return s if s.ndim else float(s)


def sf_std(env, h, state, d2d=None, fc=None):
    """Unified sigma_SF. Terrestrial: Table 7.4.1-1 values; RMa LoS terrestrial
    needs pre/post-breakpoint (requires d2d, fc; defaults to pre-BP value)."""
    h = np.asarray(h, dtype=float)
    cross = P.BAND_CROSSOVER[env]
    aer = sf_std_aerial(env, np.maximum(h, cross + 1e-9), state)
    if env == "RMa":
        t = P.TERR["RMa"]
        if state == "LOS" and d2d is not None and fc is not None:
            dbp = 2 * np.pi * t["h_bs"] * np.maximum(h, 1.0) * (fc * 1e9) / P.C_LIGHT
            terr = np.where(np.asarray(d2d, float) <= dbp,
                            t["sig_los_pre"], t["sig_los_post"])
        else:
            terr = t["sig_los_pre"] if state == "LOS" else t["sig_nlos"]
    else:
        terr = (P.TERR[env]["sig_los"] if state == "LOS"
                else P.TERR[env]["sig_nlos"])
    out = np.where(h <= cross, terr, aer)
    return out if np.ndim(out) else float(out)


def dsf_dh_aerial(env, h):
    """d sigma_LoS / dh (aerial band); 0 on the UMi floor."""
    h = np.asarray(h, dtype=float)
    cfg = P.AERIAL_SF[env]
    s_raw = cfg["s0"] * np.exp(-cfg["kappa"] * h)
    on_floor = (cfg["s_floor"] is not None) & (s_raw < (cfg["s_floor"] or 0.0))
    out = np.where(on_floor, 0.0, -cfg["kappa"] * s_raw)
    return out if out.ndim else float(out)


# --------------------------------------------------- coverage and derivative
def qfunc(x):
    from scipy.special import erfc
    return 0.5 * erfc(np.asarray(x, dtype=float) / np.sqrt(2.0))


def npdf(x):
    x = np.asarray(x, dtype=float)
    return np.exp(-0.5 * x * x) / np.sqrt(2.0 * np.pi)


def p_cov(env, d2d, h, fc, l_max, h_g=P.H_G_DEFAULT):
    """P_cov = P_L Q(u_L) + (1-P_L) Q(u_N), aerial-band expressions."""
    pl_ = plos_aerial(env, d2d, h)
    u_l = (pl_los_aerial(env, d2d, h, fc, h_g) - l_max) / sf_std_aerial(env, h, "LOS")
    u_n = (pl_nlos_aerial(env, d2d, h, fc, h_g) - l_max) / sf_std_aerial(env, h, "NLOS")
    return pl_ * qfunc(u_l) + (1.0 - pl_) * qfunc(u_n)


def _dpl_dh_aerial(env, state, d2d, h, fc, h_g):
    """Branch-aware analytic d PL_state / dh (aerial band)."""
    cfg = P.AERIAL_PL[(env, state)]
    d = d3d(d2d, h, h_g)
    dh = np.asarray(h, float) - h_g
    B = cfg["a"] - cfg["b"] * np.log10(h)
    Bp = -cfg["b"] / (np.asarray(h, float) * LN10)
    if cfg["guard"] == "slope20":
        on_floor = B < 20.0
        B = np.maximum(B, 20.0)
        Bp = np.where(on_floor, 0.0, Bp)
    deriv = Bp * np.log10(d) + B * dh / (LN10 * d * d)
    if cfg["guard"] == "fspl":  # UMi LoS
        raw = cfg["A0"] + _icpt(cfg["icpt"], fc) + \
            (cfg["a"] - cfg["b"] * np.log10(h)) * np.log10(d)
        fs = fspl(d, fc)
        d_fs = 20.0 * dh / (LN10 * d * d)
        deriv = np.where(fs > raw, d_fs, deriv)
    if cfg["guard"] == "los":   # UMi/RMa NLoS clipped to LoS
        raw = cfg["A0"] + _icpt(cfg["icpt"], fc) + \
            (cfg["a"] - cfg["b"] * np.log10(h)) * np.log10(d)
        clip = pl_los_aerial(env, d2d, h, fc, h_g) >= raw
        deriv = np.where(clip, _dpl_dh_aerial(env, "LOS", d2d, h, fc, h_g), deriv)
    return deriv


def g_dh(env, d2d, h, fc, l_max, h_g=P.H_G_DEFAULT):
    """Analytic dP_cov/dh (master Eq. of Stage 1, branch-aware, aerial band)."""
    d2d, h = np.broadcast_arrays(np.asarray(d2d, float), np.asarray(h, float))
    pl_ = plos_aerial(env, d2d, h)
    s_l = sf_std_aerial(env, h, "LOS")
    s_n = sf_std_aerial(env, h, "NLOS")
    slp = dsf_dh_aerial(env, h)
    u_l = (pl_los_aerial(env, d2d, h, fc, h_g) - l_max) / s_l
    u_n = (pl_nlos_aerial(env, d2d, h, fc, h_g) - l_max) / s_n
    ulp = _dpl_dh_aerial(env, "LOS", d2d, h, fc, h_g) / s_l - u_l * slp / s_l
    unp = _dpl_dh_aerial(env, "NLOS", d2d, h, fc, h_g) / s_n
    g = dplos_dh(env, d2d, h) * (qfunc(u_l) - qfunc(u_n)) \
        - pl_ * npdf(u_l) * ulp - (1.0 - pl_) * npdf(u_n) * unp
    return g if g.ndim else float(g)


# -------------------------------------------------------------- aggregates
BETA = LN10 / 10.0


def mean_pl_db(env, d2d, h, fc, h_g=P.H_G_DEFAULT):
    """State-averaged mean path loss in dB (SF is zero-mean in dB)."""
    p = plos(env, d2d, h)
    return p * path_loss(env, d2d, h, fc, "LOS", h_g) \
        + (1 - p) * path_loss(env, d2d, h, fc, "NLOS", h_g)


def mean_gain_lin(env, d2d, h, fc, h_g=P.H_G_DEFAULT):
    """E[10^{-(PL+X)/10}] with the lognormal correction exp((beta*sigma)^2/2)."""
    p = plos(env, d2d, h)
    gl = 10 ** (-path_loss(env, d2d, h, fc, "LOS", h_g) / 10.0) \
        * np.exp((BETA * sf_std(env, h, "LOS", d2d, fc)) ** 2 / 2.0)
    gn = 10 ** (-path_loss(env, d2d, h, fc, "NLOS", h_g) / 10.0) \
        * np.exp((BETA * sf_std(env, h, "NLOS", d2d, fc)) ** 2 / 2.0)
    return p * gl + (1 - p) * gn
