"""Sionna bridge (DELIVERED UNTESTED IN THE STAGE-2 SANDBOX).

The Stage-2 build environment could not reach PyPI (HTTP 403 on the package
index), so Sionna/TensorFlow could not be installed and none of the functions
below have been executed against a live Sionna. They are written defensively
against Sionna >= 1.0 (sionna.phy.*) with fallbacks for 0.x (sionna.*), and
each raises a clear ImportError message when Sionna is absent.

Run scripts/sionna_demo.py on a machine with `pip install sionna` to execute
the cross-checks; report any assertion output back into the Stage-2 log.

Roles in the dissertation pipeline:
  1. load_cdl_tables()  - pull the official CDL-A..E tables from the installed
     Sionna package (machine-readable source, no hand transcription) and diff
     CDL-D/E against uav_channel.params (transcription audit).
  2. terrestrial_crosscheck() - compare our TR 38.901 terrestrial PL against
     Sionna's tr38901 scenarios on a distance sweep (independent validation).
  3. to_cir_dataset() - wrap our Alternative-1/-2 aerial CIRs into a
     sionna CIRDataset so Sionna's OFDM machinery can consume the 36.777
     aerial model (which Sionna does not implement natively).
"""
from __future__ import annotations
import numpy as np

_IMPORT_MSG = ("Sionna is not installed in this environment. Install with "
               "`pip install sionna` (needs TensorFlow) and re-run. "
               "This adapter ships untested for that reason; see module "
               "docstring.")


def _sionna():
    try:
        import sionna  # noqa
        return sionna
    except Exception as e:  # pragma: no cover
        raise ImportError(_IMPORT_MSG) from e


def _cdl_class():
    sn = _sionna()
    try:
        from sionna.phy.channel.tr38901 import CDL  # sionna >= 1.0
        from sionna.phy.channel.tr38901 import PanelArray
    except Exception:
        from sionna.channel.tr38901 import CDL, PanelArray  # sionna 0.x
    return CDL, PanelArray, sn


def _single_antenna(PanelArray, fc_hz):
    return PanelArray(num_rows_per_panel=1, num_cols_per_panel=1,
                      polarization="single", polarization_type="V",
                      antenna_pattern="omni", carrier_frequency=fc_hz)


def load_cdl_tables(models=("A", "B", "C", "D", "E"), fc_hz=3.5e9,
                    delay_spread=1.0):
    """Extract normalized delays/powers/angles for each CDL model from the
    installed Sionna (introspection of the CDL object's private arrays, which
    Sionna populates from its bundled 38.901 tables)."""
    CDL, PanelArray, _ = _cdl_class()
    ant = _single_antenna(PanelArray, fc_hz)
    out = {}
    for m in models:
        cdl = CDL(model=m, delay_spread=delay_spread, carrier_frequency=fc_hz,
                  ut_array=ant, bs_array=ant, direction="downlink")
        rec = {}
        for name in ("delays", "powers", "aod", "aoa", "zod", "zoa"):
            for attr in (f"_{name}", name):
                if hasattr(cdl, attr):
                    v = getattr(cdl, attr)
                    try:
                        v = v.numpy()
                    except Exception:
                        pass
                    rec[name] = np.squeeze(np.asarray(v))
                    break
        out[m] = rec
    return out


def diff_cdl_d_against_local(atol=1e-6):
    """Audit: compare Sionna's CDL-D/E tables to uav_channel.params hand copy.

    Returns dict of max abs differences; raises AssertionError on mismatch.
    """
    from . import params as P
    tabs = load_cdl_tables(models=("D", "E"))
    report = {}
    for name, local in (("D", P.CDL_D), ("E", P.CDL_E)):
        s = tabs[name]
        delays = np.concatenate([[local["specular"]["delay"]],
                                 local["clusters"][:, 0]])
        powers = np.concatenate([[local["specular"]["power"]],
                                 local["clusters"][:, 1]])
        # Sionna merges/normalises differently across versions; compare sorted
        # delay/power multisets, which are representation-invariant.
        report[name] = dict(
            d_delay=float(np.max(np.abs(np.sort(np.ravel(s["delays"]))[:len(delays)]
                                        - np.sort(delays)))),
            n_sionna=int(np.ravel(s["delays"]).size), n_local=len(delays))
    return report


def terrestrial_crosscheck(env="UMa", fc_hz=3.5e9, h_ut=1.5, n=25):
    """Compare uav_channel terrestrial PL to Sionna's tr38901 scenario PL.

    Returns (d2d, pl_ours, pl_sionna) arrays for LOS-forced links.
    """
    sn = _sionna()
    try:
        from sionna.phy.channel.tr38901 import UMa, UMi, RMa, PanelArray
    except Exception:
        from sionna.channel.tr38901 import UMa, UMi, RMa, PanelArray
    import tensorflow as tf
    from .large_scale import pl_terrestrial
    ant = _single_antenna(PanelArray, fc_hz)
    cls = {"UMa": UMa, "UMi": UMi, "RMa": RMa}[env]
    ch = cls(carrier_frequency=fc_hz, o2i_model="low", ut_array=ant,
             bs_array=ant, direction="downlink", enable_pathloss=True,
             enable_shadow_fading=False)
    h_bs = {"UMa": 25.0, "UMi": 10.0, "RMa": 35.0}[env]
    d2d = np.linspace(30, 2000, n)
    ut_loc = tf.constant([[[float(d), 0.0, h_ut] for d in d2d]], tf.float32)
    bs_loc = tf.constant([[[0.0, 0.0, h_bs]]], tf.float32)
    ut_vel = tf.zeros_like(ut_loc)
    ch.set_topology(ut_loc, bs_loc,
                    tf.constant([[0.0] * n], tf.float32),  # orientations vary
                    ut_vel, in_state=tf.zeros([1, n], tf.bool),
                    los=tf.ones([1, n], tf.bool))
    pl_s = np.squeeze(ch._scenario.basic_pathloss.numpy())
    pl_o = np.array([pl_terrestrial(env, d, h_ut, fc_hz / 1e9, "LOS")
                     for d in d2d])
    return d2d, pl_o, pl_s


def to_cir_dataset(cir_generator, batch_size, num_rx=1, num_rx_ant=1,
                   num_tx=1, num_tx_ant=1, num_paths=14, num_time_steps=1):
    """Wrap a python generator yielding (a, tau) into a sionna CIRDataset so
    the 36.777 aerial CIRs (from uav_channel.small_scale.gen_channel or the
    Alt-2 stochastic model) drive Sionna OFDM channels."""
    try:
        from sionna.phy.channel import CIRDataset
    except Exception:
        try:
            from sionna.channel import CIRDataset
        except Exception as e:
            raise ImportError(_IMPORT_MSG) from e
    return CIRDataset(cir_generator, batch_size, num_rx, num_rx_ant, num_tx,
                      num_tx_ant, num_paths, num_time_steps)
