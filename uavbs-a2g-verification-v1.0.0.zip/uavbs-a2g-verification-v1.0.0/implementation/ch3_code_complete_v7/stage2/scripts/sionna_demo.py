"""Sionna cross-check demo -- RUN ON A MACHINE WITH SIONNA INSTALLED.

The Stage-2 sandbox could not reach PyPI, so this script has NOT been executed
end-to-end. It performs, in order:
  1. CDL table audit: pull CDL-D/E from the installed Sionna and diff against
     the hand-transcribed tables in uav_channel.params.
  2. Terrestrial path-loss cross-check: our TR 38.901 Table 7.4.1-1 code vs
     Sionna's tr38901 scenario (LOS-forced), UMa/UMi/RMa.
  3. Aerial CIR bridge: wrap the Alternative-1 CDL-D generator into a
     sionna CIRDataset and pass one batch through an OFDM channel.

Usage:  pip install sionna && python scripts/sionna_demo.py
Report the printed summary back into the Stage-2 log (flag V4).
"""
import os
import sys
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import uav_channel as uc
from uav_channel import sionna_adapter as sa

print("== 1. CDL table audit ==")
try:
    rep = sa.diff_cdl_d_against_local()
    print(rep)
except ImportError as e:
    print("SKIPPED:", e)

print("== 2. terrestrial PL cross-check ==")
try:
    for env in ("UMa", "UMi", "RMa"):
        d2d, ours, theirs = sa.terrestrial_crosscheck(env=env)
        err = np.max(np.abs(ours - theirs))
        print(f"{env}: max |delta PL| = {err:.3f} dB over d2D in "
              f"[{d2d[0]:.0f},{d2d[-1]:.0f}] m "
              + ("OK" if err < 0.5 else "INVESTIGATE"))
except ImportError as e:
    print("SKIPPED:", e)

print("== 3. aerial CIR -> Sionna OFDM ==")
try:
    import tensorflow as tf  # noqa

    los = dict(aod=0.0, aoa=-180.0, zod=100.0, zoa=80.0)
    cdl = uc.alt1_cdl("UMa", 300.0, 100.0, "LOS", los)
    delays = np.concatenate([[cdl["specular"]["delay"]],
                             cdl["clusters"][:, 0]])
    n_paths = delays.size

    def cir_gen():
        rng = np.random.default_rng(1)
        while True:
            t = np.zeros(1)
            H, tau = uc.gen_channel(cdl, 3.5, t, rng=rng)
            a = np.zeros([1, 1, 1, 1, n_paths, 1], np.complex64)
            # per-path amplitudes: split the SISO sum per cluster
            # (demo only -- full per-path export is Stage-3 work)
            a[..., 0, 0] = H[0]
            yield a, tau.astype(np.float32).reshape(1, 1, 1, n_paths)

    ds = sa.to_cir_dataset(cir_gen, batch_size=1, num_paths=n_paths)
    print("CIRDataset constructed:", ds)
except ImportError as e:
    print("SKIPPED:", e)
print("done")
