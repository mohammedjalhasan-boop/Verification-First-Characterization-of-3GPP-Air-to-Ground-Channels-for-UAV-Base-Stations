"""Stage-2 review figures. Palette/marks per the dataviz reference instance:
first three categorical slots (validated all-pairs, light mode), diverging
blue<->red for the signed SF field, recessive chrome, one axis per chart."""
import os
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import uav_channel as uc
from uav_channel import params as P

OUT = os.path.join(os.path.dirname(__file__), "..", "out", "figures")
os.makedirs(OUT, exist_ok=True)

# ---- reference palette (light mode) ----------------------------------------
S1, S2, S3 = "#2a78d6", "#eb6834", "#1baf7a"      # categorical slots 1-3
SURFACE, INK, INK2, MUTED = "#fcfcfb", "#0b0b0b", "#52514e", "#898781"
GRID, BASE = "#e1e0d9", "#c3c2b7"
DIV = LinearSegmentedColormap.from_list(
    "div_br", ["#104281", "#3987e5", "#cde2fb", "#f0efec", "#f5c6c6",
               "#e34948", "#7a1f1f"])

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE,
    "savefig.facecolor": SURFACE, "font.family": "DejaVu Sans",
    "axes.edgecolor": BASE, "axes.labelcolor": INK2, "axes.linewidth": 1.0,
    "xtick.color": MUTED, "ytick.color": MUTED, "xtick.labelsize": 9,
    "ytick.labelsize": 9, "axes.titlesize": 10.5, "axes.titlecolor": INK,
    "axes.labelsize": 9.5, "grid.color": GRID, "grid.linewidth": 0.8,
    "legend.frameon": False, "legend.fontsize": 9, "lines.linewidth": 2.0})


def style(ax):
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(True, axis="both", alpha=0.9)
    ax.set_axisbelow(True)


# F1 -- P_LoS vs altitude, three ranges, per environment ----------------------
fig, axes = plt.subplots(1, 3, figsize=(11, 3.4), sharey=True)
for ax, env in zip(axes, P.ENVS):
    lo, hi = P.AERIAL_PLOS[env]["band"]
    h = np.linspace(lo + 0.01, 300, 1200)
    for r, c in ((100, S1), (200, S2), (500, S3)):
        ax.plot(h, uc.plos_aerial(env, float(r), h), color=c,
                label=f"$d_{{2D}}$ = {r} m")
    style(ax)
    ax.set_title(f"{env}-AV")
    ax.set_xlabel("UAV altitude $h_{UT}$ [m]")
axes[0].set_ylabel("$P_{LoS}$")
axes[0].legend(loc="lower right")
fig.suptitle("LoS probability vs altitude (TR 36.777 Table B-1)",
             color=INK, fontsize=12, y=1.02)
fig.tight_layout()
fig.savefig(os.path.join(OUT, "f1_plos_vs_h.png"), dpi=150,
            bbox_inches="tight")

# F2 -- path loss vs range at h=100 m, fc=3.5 ---------------------------------
fig, axes = plt.subplots(1, 3, figsize=(11, 3.4), sharey=True)
r = np.linspace(30, 1000, 600)
for ax, env in zip(axes, P.ENVS):
    ax.plot(r, uc.pl_los_aerial(env, r, 100.0, 3.5), color=S1, label="LoS")
    ax.plot(r, uc.pl_nlos_aerial(env, r, 100.0, 3.5), color=S2, label="NLoS")
    style(ax)
    ax.set_title(f"{env}-AV   ($h_{{UT}}$ = 100 m, $f_c$ = 3.5 GHz)")
    ax.set_xlabel("$d_{2D}$ [m]")
axes[0].set_ylabel("Path loss [dB]")
axes[0].legend(loc="lower right")
fig.tight_layout()
fig.savefig(os.path.join(OUT, "f2_pl_vs_r.png"), dpi=150, bbox_inches="tight")

# F3 -- operating-altitude map: LoS wall + solver optima ----------------------
fig, ax = plt.subplots(figsize=(7.2, 4.2))
r = np.linspace(18, 1000, 800)
for env, c in (("UMa", S1), ("UMi", S2), ("RMa", S3)):
    ax.plot(r, uc.h_wall(env, r), color=c, label=f"{env}-AV wall $h_1(r)$")
    rr = np.arange(50, 1001, 50)
    hs = [uc.h_star_refined(env, float(x), 3.5, 120.0)["h_plateau_lo"]
          for x in rr]
    ax.plot(rr, hs, "o", ms=5, mfc="none", mec=c, mew=1.6,
            label=f"{env}-AV solver optimum")
style(ax)
ax.set_xlabel("horizontal range $d_{2D}$ [m]")
ax.set_ylabel("altitude [m]")
ax.set_title("Operating-altitude map, $f_c$=3.5 GHz, $L_{max}$=120 dB "
             "(closed-form wall vs numerical optimum)")
ax.legend(loc="center right", ncols=1, frameon=True, facecolor=SURFACE,
          edgecolor=BASE, framealpha=0.95)   # mid-right void: clear of walls,
                                             # optima rows and the 300-m band
fig.tight_layout()
fig.savefig(os.path.join(OUT, "f3_hstar_map.png"), dpi=150,
            bbox_inches="tight")

# F4 -- FR2 bimodality --------------------------------------------------------
fig, ax = plt.subplots(figsize=(7.2, 4.0))
h = np.arange(22.6, 300, 0.1)
for lm, c in ((115.0, S1), (120.0, S2), (125.0, S3)):
    ax.plot(h, uc.p_cov("UMa", 500.0, h, 28.0, lm), color=c,
            label=f"$L_{{max}}$ = {lm:.0f} dB")
ax.axvline(100.0, color=MUTED, lw=1.0, ls=":")
ax.annotate("$P_{LoS}$ jump at $h_{sat}$=100 m", xy=(100, 0.62),
            xytext=(130, 0.72), color=INK2, fontsize=9,
            arrowprops=dict(arrowstyle="->", color=MUTED, lw=1.0))
style(ax)
ax.set_xlabel("UAV altitude $h_{UT}$ [m]")
ax.set_ylabel("$P_{cov}$")
ax.set_title("Coverage vs altitude, UMa-AV, $f_c$=28 GHz, $d_{2D}$=500 m "
             "(FR2 bimodality; Prop. 7.3 caveat)")
ax.legend(loc="center right", frameon=True, facecolor=SURFACE,
          edgecolor=BASE, framealpha=0.95)   # right-middle void between the
                                             # saturated and collapsing branches
fig.tight_layout()
fig.savefig(os.path.join(OUT, "f4_fr2_bimodal.png"), dpi=150,
            bbox_inches="tight")

# F5 -- correlated SF maps (signed field -> diverging palette) ----------------
fig, axes = plt.subplots(1, 3, figsize=(11.5, 3.7))
for ax, dc in zip(axes, (5, 25, 50)):
    dx = min(5.0, dc / 2.0)
    npts = int(round(500.0 / dx)) + 1
    m = uc.spectral_map_2d(npts, npts, dx, dc, rng=42)
    im = ax.imshow(m, cmap=DIV, vmin=-3, vmax=3, origin="lower",
                   extent=[0, 500, 0, 500], interpolation="nearest")
    ax.set_title(f"$d_{{corr}}$ = {dc} m")
    ax.set_xlabel("x [m]")
    for s in ax.spines.values():
        s.set_color(BASE)
axes[0].set_ylabel("y [m]")
cb = fig.colorbar(im, ax=axes, shrink=0.85, pad=0.015)
cb.set_label("normalised SF [$\\sigma$ units]", color=INK2)
cb.outline.set_color(BASE)
fig.suptitle("Spatially correlated shadow fading, $R(d)=e^{-d/d_{corr}}$ "
             "(outline sweep {5, 25, 50} m; 3GPP: UMa 37/50, UMi 10/13, "
             "RMa 37/120 m)", color=INK, fontsize=11, y=1.04)
fig.savefig(os.path.join(OUT, "f5_sf_maps.png"), dpi=150,
            bbox_inches="tight")

# F6 -- CDL-D Doppler spectrum from the generator -----------------------------
fig, ax = plt.subplots(figsize=(7.2, 3.8))
los = dict(aod=0.0, aoa=-180.0, zod=100.0, zoa=80.0)
cdl = uc.alt1_cdl("UMa", 300.0, 100.0, "LOS", los)
fs = 4096.0
t = np.arange(0, 8.0, 1 / fs)
v = uc.velocity_vec(20.0, 60.0)               # 20 m/s horizontal, az 60 deg
H, _ = uc.gen_channel(cdl, 3.5, t, v_rx=v, rng=9)
f = np.fft.fftshift(np.fft.fftfreq(t.size, 1 / fs))
S = np.fft.fftshift(np.abs(np.fft.fft(H - H.mean())) ** 2)
S = S / S.max()
ax.plot(f, 10 * np.log10(np.maximum(S, 1e-8)), color=S1, lw=1.2)
fdm = uc.fd_max(20.0, 3.5)
for x in (-fdm, fdm):
    ax.axvline(x, color=MUTED, lw=1.0, ls=":")
ax.text(0.955 * fdm, 2, f"$\\pm f_{{D,max}}$ = {fdm:.0f} Hz", color=INK2,
        fontsize=9, ha="right")              # clearance so the label does not
                                             # touch the +f_D,max marker line
style(ax)
ax.set_xlim(-1.6 * fdm, 1.6 * fdm)
ax.set_ylim(-80, 6)
ax.set_xlabel("Doppler frequency [Hz]")
ax.set_ylabel("normalised PSD [dB]")
ax.set_title("CDL-D (Alt-1 scaled, K=20 dB) Doppler spectrum, "
             "$f_c$=3.5 GHz, $v$=20 m/s")
fig.tight_layout()
fig.savefig(os.path.join(OUT, "f6_doppler.png"), dpi=150,
            bbox_inches="tight")

print("figures written to", OUT)
