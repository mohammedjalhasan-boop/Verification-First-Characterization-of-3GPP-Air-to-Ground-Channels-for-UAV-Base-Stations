"""Stage-2 exports: DRL lookup tables, optimal-altitude map, SF fields."""
import json
import os
import sys
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import uav_channel as uc
from uav_channel import params as P

OUT = os.path.join(os.path.dirname(__file__), "..", "out")
os.makedirs(OUT, exist_ok=True)

# 1. core lookup (outline Sec. 3.2 grid, verbatim)
n = uc.export_core_csv(os.path.join(OUT, "lookup_core.csv"))
print(f"lookup_core.csv: {n} rows")

# 2. dense grids for DRL interpolation
shapes = uc.export_dense_npz(os.path.join(OUT, "lookup_dense.npz"))
print(f"lookup_dense.npz: {len(shapes)} arrays")

# 3. optimal-altitude map
rows = uc.hstar_table(d2d_list=tuple(range(50, 1001, 50)),
                      lmax_list=(110.0, 115.0, 120.0, 125.0, 130.0))
cols = ["env", "fc_ghz", "d2d_m", "l_max_db", "h_star", "p_max", "regime",
        "h_plateau_lo", "plateau_span", "n_modes", "h_wall"]
with open(os.path.join(OUT, "hstar_map.csv"), "w") as f:
    f.write(",".join(cols) + "\n")
    for r in rows:
        f.write(",".join(str(r[c]) for c in cols) + "\n")
print(f"hstar_map.csv: {len(rows)} rows")

# 4. correlated shadow-fading sample maps (outline d_corr sweep)
store = {}
for dc in P.OUTLINE_GRID["d_corr"]:
    dx = min(5.0, dc / 2.0)
    npts = int(round(1000.0 / dx)) + 1
    store[f"map_dcorr{int(dc)}"] = uc.spectral_map_2d(npts, npts, dx, dc,
                                                      rng=42).astype(np.float32)
    store[f"dx_dcorr{int(dc)}"] = np.array([dx])
meta = dict(units="unit-variance field; multiply by sigma_SF(h,state) [dB]",
            acf="exp(-d/d_corr)", d_corr_m=list(P.OUTLINE_GRID["d_corr"]),
            extent_m=1000.0, seed=42)
np.savez_compressed(os.path.join(OUT, "sf_maps.npz"), meta=json.dumps(meta),
                    **store)
print("sf_maps.npz:", {k: v.shape for k, v in store.items() if v.ndim == 2})
