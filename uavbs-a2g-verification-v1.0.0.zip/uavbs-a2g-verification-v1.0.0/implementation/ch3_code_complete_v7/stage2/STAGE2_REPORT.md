---
title: "Chapter 3 --- Stage 2 of 4: Python Implementation of the 3GPP A2G Channel"
author: "M. J. Alhasan (Stage-2 build log, July 2026)"
geometry: margin=2.3cm
fontsize: 11pt
---

# What was built

Stage 2 turns the Stage-1 mathematical instantiation into a tested Python
package, `uav_channel` v0.1.0 (NumPy/SciPy only in the core), plus the DRL
lookup-table exports and the optimal-altitude map. Module inventory:

| Module | Contents | Stage-1 section |
|---|---|---|
| `params.py` | every 3GPP constant with provenance (36.777 B-1/B-2/B-3/B.1.1/B.1.2; 38.901 7.4.x, 7.5-3, 7.5-6, 7.6.3.1-2, 7.7.1-4/5) | §2–§6 |
| `large_scale.py` | P_LoS, PL LoS/NLoS (aerial + terrestrial, all guards/floors), sigma_SF(h), P_cov, analytic dP_cov/dh (branch-aware) | §2, §3, §7.1 |
| `shadowing.py` | AR(1) trajectory sampler (exact exponential ACF), FFT spectral 2-D maps, Cholesky 3-D point fields (Assumption D2), `SFGenerator` with per-state maps | §4 |
| `altitude.py` | closed-form LoS wall `h_1(r)`, grid+bisection `h*` solver with regime classification, map export | §7.2 |
| `small_scale.py` | Alt-2 altitude-dependent LSPs (Tables B.1.2-1/2), Alt-1 CDL-D pipeline: angular scale/translate (7.7-5/7.7-6), K scaling (7.7.6-1/2), DS scaling (7.7-1), LoS ZOD ground/roof offset (B.1.1-1/2), Doppler (7.5-25, dual-end), SISO coefficient generator | §5, §6 |
| `lookup.py` | core CSV (outline §3.2 grid verbatim) + dense NPZ | contribution (b) |
| `sionna_adapter.py` | Sionna bridge — **delivered untested** (see below) | §5.4 |

# Validation (26 tests, all passing)

Five independent layers:

1. **Oracle equivalence** — 2,500 random points must match the Stage-1 scalar
   implementation (itself FD-validated at 11,835 points and transcribed from
   the source PDFs) to 1e-10…1e-12. This validates the vectorised branch
   logic (max-guards, floors, saturation) exactly.
2. **Fresh finite-difference check** of the packaged analytic `g_dh` at 250
   random points (tolerance 1e-6).
3. **Golden numbers** from the reviewed Stage-1 run: the UMa-28 GHz profile
   (P_LoS/PL/sigma/P_cov at h = 23/100.1/300), the RMa NLoS clip values, the
   wall table (54.8/90.5/100/210.2/36.0 m), outline-consistency h* values
   (70.5/90.5/100 m UMa; 142.1 m UMi), Doppler numbers, FR2 bimodality
   (n_modes > 1), terrestrial PL1/PL2 breakpoint continuity.
4. **Small-scale closures** — CDL-D/E normalised RMS delay spread = 1 and
   K_model = 8.98/9.27 dB (first-cluster 13.30/22.00 dB, reproducing the TR's
   TDL notes); after `scale_k(·, 20 dB)`: K_model = 20 exactly and DS
   renormalised; after angle scaling to 0.5°: composite AS = 0.5° ± 2% with
   the LoS ray pinned to the drop geometry; ZOD offsets vs independent
   trigonometry; specular Doppler peak at (r̂·v)/λ within FFT resolution.
5. **Statistics** — AR(1) empirical ACF at 1·Δ and d_corr (e^-1) within 1–2%;
   2-D map ACF at d_corr within ±0.07 and unit variance; Cholesky 3-D field
   correlation matrix within 0.08 of exp(-d/d_corr).

Bring-up note for the record: two failures in the *first* test run were
arithmetic slips in the test file's hand-computed expected values (e^0.46
mis-multiplied; breakpoint-continuity probed with 0.2% offsets that
legitimately produce a 0.027 dB spread). The model code needed no changes.

# Deliverables (out/)

* `lookup_core.csv` — 270 rows, outline §3.2 grid exactly; columns: P_LoS,
  PL_LoS/NLoS, sigma both states, state-averaged mean PL [dB], linear mean
  gain with lognormal correction exp((βσ)²/2), Alt-2 K/lgDS LoS statistics
  (NaN for UMi → flag V1), LoS wall h₁(r).
* `lookup_dense.npz` — 33 arrays: per-environment dense grids (h step 2.5 m,
  d2D step 10 m, all three carriers) for DRL interpolation.
* `hstar_map.csv` — 900 solved optima (3 env × 3 f_c × 20 ranges × 5 budgets)
  with regime labels and the plateau's lowest altitude (energy tie-break).
* `sf_maps.npz` — unit-variance correlated SF fields, d_corr ∈ {5,25,50} m.
* `figures/f1…f6` — review figures (palette and mark specs per the validated
  reference dataviz instance; ≤3 categorical series per chart).

Figure notes worth reading before Stage 3:

* **f3 (operating-altitude map).** Sub-6 GHz, L_max = 120 dB: at small–medium
  ranges the plotted optimum sits *below* the wall — that is the plateau
  regime (coverage saturates at ~1 before LoS certainty; the marker shows the
  lowest altitude on the plateau, the energy tie-break of Prop. 7.2). From
  r ≈ 300 m (UMa) the optimum rides the wall/cap exactly, confirming the
  closed form h*(r) = min{10^((r+700)/460), 100}.
* **f4 (FR2 bimodality).** The L_max = 115 dB curve shows the low-altitude
  local maximum and the upward P_LoS jump at h_sat = 100 m — the two-mode
  structure Prop. 7.3 warns DRL exploration about.
* **f6 (Doppler).** The Alt-1 aerial CDL-D spectrum is a near-line spectrum at
  the LoS-ray Doppler (all sub-degree-spread clusters nearly co-directional),
  not a Jakes bathtub — support stays inside ±f_D,max as required. DRL
  consequence: envelope decorrelation is governed by the specular beat, so
  sub-6 GHz aerial links age much more slowly than the terrestrial intuition
  suggests.

# Environment limitation and flag V4 (Sionna)

The build sandbox could not reach PyPI (HTTP 403 on the package index), so
Sionna/TensorFlow could not be installed and **nothing in
`sionna_adapter.py` / `scripts/sionna_demo.py` has been executed**. The
adapter is written defensively for Sionna ≥1.0 (`sionna.phy.*`) with 0.x
fallbacks and raises explanatory ImportErrors when Sionna is absent. Action
for you (5 minutes on any machine with internet):

```
pip install sionna && python scripts/sionna_demo.py
```

It will (1) audit our hand-embedded CDL-D/E tables against Sionna's bundled
official tables, (2) cross-check terrestrial UMa/UMi/RMa path loss against
Sionna's TR 38.901 implementation (expect < 0.5 dB agreement), and (3) build
the CIRDataset bridge that lets Sionna's OFDM stack consume the 36.777 aerial
CIRs (which Sionna does not model natively). Please paste its printed summary
back into the project log; that closes **V4**.

# Design decisions in this stage

* **CDL-A/B/C not hand-embedded.** Stage-1 policy: no coefficient enters the
  codebase without an independent check. CDL-D/E pass DS-normalisation and
  K-factor closures; A/B/C (23–24 clusters each) have no such closure and are
  therefore loaded via Sionna at the adapter boundary instead of being typed
  by hand.
* **`gen_channel` is SISO single-polarisation** (no XPR/2×2 matrix): adequate
  for lookup-table statistics and Doppler studies; full-pol MIMO goes through
  the Sionna bridge. Documented in the module docstring.
* **P_LoS jump kept verbatim** in all exports; smoothing is a loader-side
  option (Remark 2.1 of Stage 1).
* **UMi Alt-2 raises `NotImplementedError`** by design (open flag V1) rather
  than silently substituting terrestrial statistics.

# Flag register after Stage 2

| Flag | Status |
|---|---|
| V1 UMi-AV Alt-2 source (TR ref. [9]) | open — needs RAN1 archive pull |
| V2 rooftop height in (B.1.1-2) | open — default 20 m in `params.py` |
| V3 V14 vs V19 vintage of reused LSPs | documented decision (V19.4.0) |
| V4 Sionna cross-checks | **new** — run `scripts/sionna_demo.py` locally |

# Next

Stage 3 per the outline: Quadriga-based experimental validation and
statistical fitting (P_LoS vs altitude curves, effective-PL CDFs, coherence
metrics, angular spectra), plus the 28-GHz NLoS sensitivity study (flag E1).
Stage 4: freeze the lookup schema against the Chapter-4 MDP state design.
