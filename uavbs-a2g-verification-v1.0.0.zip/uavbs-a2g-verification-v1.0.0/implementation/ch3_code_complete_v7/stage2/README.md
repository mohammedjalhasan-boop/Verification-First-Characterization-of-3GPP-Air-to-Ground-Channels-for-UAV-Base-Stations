# uav_channel — Stage 2 (Chapter 3 / Objective 1)

NumPy implementation of the Chapter-3 air-to-ground channel for UAV base
stations: **3GPP TR 36.777 V15.0.0 Annex B** (aerial band) + **TR 38.901
V19.4.0** (terrestrial band, CDL, correlation machinery), the
coverage-optimal-altitude solver, correlated shadow-fading generators, and the
DRL lookup-table export. Every constant lives in `uav_channel/params.py` with
document/table provenance; the Stage-1 PDF is the companion derivation.

## Layout

```
uav_channel/
  params.py        every 3GPP constant (single source of truth)
  large_scale.py   P_LoS, PL (LoS/NLoS, aerial+terrestrial), sigma_SF,
                   P_cov, analytic dP_cov/dh
  shadowing.py     AR(1) trajectory, FFT 2-D map, Cholesky 3-D points (D2)
  altitude.py      LoS wall h_1(r), h* solver (grid + bisection), maps
  small_scale.py   Alt-2 h-dependent LSPs, Alt-1 CDL-D pipeline (angle/K/DS
                   scaling, ZOD offset), Doppler, SISO channel generator
  lookup.py        core CSV + dense NPZ exports
  sionna_adapter.py  Sionna bridge (UNTESTED here: sandbox had no PyPI)
tests/             stdlib unittest suite (26 tests) + Stage-1 oracle
scripts/           export_lookup.py, make_figures.py, sionna_demo.py
out/               lookup_core.csv, lookup_dense.npz, hstar_map.csv,
                   sf_maps.npz, figures/
```

## Quick start

```python
import uav_channel as uc

uc.plos("UMa", d2d=200, h=100)                    # 1.0  (inside LoS wall)
uc.path_loss("UMa", 200, 100, 3.5, "LOS")         # 90.54 dB
uc.sf_std("UMa", 100, "LOS")                      # 2.40 dB
uc.p_cov("UMa", 200, 100, 3.5, l_max=120)         # coverage probability
uc.g_dh("UMa", 200, 100, 3.5, 120)                # analytic dP_cov/dh
uc.h_wall("UMa", 200)                             # 90.5 m (closed form)
uc.h_star_refined("UMa", 200, 3.5, 120)           # solver dict w/ regime

lsp = uc.lsp_alt2("UMa", 100, "LOS")              # Alt-2 (mu, sigma) per LSP
cdl = uc.alt1_cdl("UMa", 300, 100, "LOS",
                  dict(aod=0, aoa=-180, zod=100, zoa=80))   # Alt-1 pipeline
H, tau = uc.gen_channel(cdl, 3.5, t, v_rx=uc.velocity_vec(20, 30))
```

Run everything:

```
python -m unittest discover -s tests -v   # 26 tests
python scripts/export_lookup.py           # rebuild out/
python scripts/make_figures.py            # rebuild out/figures/
python scripts/sionna_demo.py             # on a machine with sionna installed
```

## Lookup tables (DRL interface)

* `out/lookup_core.csv` — the outline §3.2 grid verbatim (270 rows):
  env × h{30,50,100,150,200,300} × d2D{50,100,200,500,1000} × fc{2.6,3.5,28};
  columns include P_LoS, PL_LoS/NLoS, sigma_LoS/NLoS, state-averaged mean PL,
  linear mean gain (lognormal-corrected), Alt-2 K/DS statistics, LoS wall.
* `out/lookup_dense.npz` — per-environment dense grids (h step 2.5 m, d2D
  step 10 m) for interpolation inside DRL loops.
* `out/hstar_map.csv` — 900 solved optima with regime labels
  (wall/interior/plateau/ceiling/none) and the plateau's lowest altitude
  (energy tie-break) — the Chapter 4–7 initialisation prior.
* `out/sf_maps.npz` — unit-variance correlated SF fields for
  d_corr ∈ {5,25,50} m (multiply by sigma_SF(h, state)).

**Model verbatim-ness:** the P_LoS jump at h_sat (Stage-1 Remark 2.1) is kept
in the tables; smooth it at load time if your policy-gradient variance needs it.

## Known limitations / open flags

* **V1** UMi-AV Alternative-2 LSPs live in TR 36.777's external ref. [9];
  `lsp_alt2("UMi", ...)` raises deliberately.
* **V2** Rooftop height in the UMa-AV ZOD offset defaults to 20 m
  (`params.H_ROOF_DEFAULT`), pending committee confirmation.
* **V4** The Sionna adapter and `scripts/sionna_demo.py` are delivered
  **untested** (the build sandbox could not reach PyPI). Run the demo locally;
  it audits our CDL-D/E tables against Sionna's bundled ones and cross-checks
  terrestrial path loss.
* CDL-A/B/C are intentionally not hand-embedded (no independently verifiable
  source in the sandbox) — load them through the adapter.
* `gen_channel` is SISO single-polarisation (no XPR matrix); full-pol MIMO via
  Sionna `CIRDataset` bridge.
