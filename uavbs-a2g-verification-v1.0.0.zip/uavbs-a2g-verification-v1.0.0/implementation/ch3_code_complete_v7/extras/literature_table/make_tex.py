#!/usr/bin/env python3
"""Booktabs professional LaTeX version of the comparison table."""
from data import ROWS, COLHEADS, FOOTNOTES, THIS_WORK_NOTE

SYM = {"F": r"\CIRCLE", "P": r"\LEFTcircle", "N": r"--", "X": r"n/a"}
# use wasysym-free approach: define filled/half symbols via tikz-free math:
SYM = {"F": r"$\bullet$", "P": r"$\circ$", "N": r"--", "X": r"\footnotesize n/a"}

def esc(s):
    return (s.replace("P_LoS(θ)", r"$P_{\mathrm{LoS}}(\theta)$")
             .replace("&", r"\&").replace("%", r"\%").replace("θ", r"$\theta$")
             .replace("5G-to-6G", r"5G$\to$6G").replace("—", "---"))

def cell(c):
    sym, fn = c
    s = SYM[sym]
    if fn:
        s += rf"$^{{\mathrm{{{fn}}}}}$"
    return s

L = [
 r"% Professional (booktabs) literature-comparison table. Requires: booktabs, pdflscape, colortbl/xcolor.",
 r"\begin{landscape}",
 r"\begin{table}\centering",
 r"\caption{Capability comparison with the classical and current literature (2014--2026); all entries are",
 r"IEEE Transactions-tier or equivalent Q1 venues. $\bullet$: provided; $\circ$: partial or for a different",
 r"object (lettered notes give the object); --: absent; n/a: axis not applicable. The comparison is one of",
 r"kind and coverage: measurement campaigns and surveys are not expected to ship simulators.}",
 r"\label{tab:litcomp}",
 r"\small\setlength{\tabcolsep}{5pt}\renewcommand{\arraystretch}{1.12}",
 r"\begin{tabular}{@{}p{4.1cm}p{3.9cm}cp{3.6cm}cccccc@{}}",
 r"\toprule",
 r" & & & & \multicolumn{6}{c}{\textbf{Contribution axes of this dissertation}}\\",
 r"\cmidrule(l){5-10}",
 r"\textbf{Work} & \textbf{Venue} & \textbf{Year} & \textbf{Channel approach} & "
 r"\rotatebox{0}{\textbf{Annex}} & \textbf{Verif.} & \textbf{Theory} & \textbf{FR2} & \textbf{Decision} & \textbf{Artifact}\\",
 r"\midrule",
]
for gi, (group, rows) in enumerate(ROWS):
    L.append(rf"\multicolumn{{10}}{{@{{}}l}}{{\itshape {esc(group)}}}\\[1pt]")
    for (work, venue, yr, app, *cells) in rows:
        row = [esc(work), esc(venue), yr, esc(app)] + [cell(c) for c in cells]
        if group.startswith("VI"):
            row = [rf"\textbf{{{x}}}" if i < 4 else x for i, x in enumerate(row)]
            L.append(r"\rowcolor{black!8}" + " & ".join(row) + r"\\")
        else:
            L.append(" & ".join(row) + r"\\")
    if gi < len(ROWS) - 1:
        L.append(r"\addlinespace[3pt]")
L += [r"\bottomrule", r"\end{tabular}", "", r"\vspace{4pt}",
      r"\begin{minipage}{0.97\linewidth}\scriptsize\setlength{\parskip}{1pt}"]
for k, txt in FOOTNOTES:
    L.append(rf"$^{{\mathrm{{{k}}}}}$\,{esc(txt)}\\")
note = (THIS_WORK_NOTE.replace("h1(r)", r"$h_1(r)$").replace("[-23, -2]", r"$[-23,-2]$")
        .replace("<=14.4", r"$\le$14.4").replace("~10^4", r"${\sim}10^{4}$")
        .replace("0.21-0.35", "0.21--0.35").replace("~0-0.30", r"${\approx}$0--0.30")
        .replace("%", r"\%"))
L.append(rf"\textit{{This work:}} {note}")
L += [r"\end{minipage}", r"\end{table}", r"\end{landscape}"]
open("table_litcomp_pro.tex", "w").write("\n".join(L) + "\n")
print("wrote table_litcomp_pro.tex")
