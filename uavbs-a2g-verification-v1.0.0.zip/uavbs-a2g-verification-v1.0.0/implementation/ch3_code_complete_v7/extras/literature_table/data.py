# Shared data for the professional table. Cells: (symbol, footnote_letter_or_None)
# Symbols: "F"=full ●, "P"=partial ◐, "N"=absent —, "X"=n/a
ROWS = [
 ("I. Analytical altitude theory", [
  ("Al-Hourani et al.", "IEEE Wireless Commun. Lett.", "2014",
   "Sigmoid P_LoS(θ) + excess losses",
   ("N",None), ("N",None), ("P","a"), ("N",None), ("N",None), ("N",None)),
  ("Bai and Heath", "IEEE Trans. Wireless Commun.", "2015",
   "Stochastic-geometry blockage (terrestrial)",
   ("N",None), ("N",None), ("N",None), ("P","b"), ("N",None), ("N",None)),
  ("Azari et al.", "IEEE Trans. Commun.", "2018",
   "Sigmoid-family reliability analysis",
   ("N",None), ("N",None), ("P","c"), ("N",None), ("N",None), ("N",None)),
 ]),
 ("II. Q1 surveys and tutorials", [
  ("Mozaffari et al.", "IEEE Commun. Surveys Tuts.", "2019",
   "UAV-networks tutorial (sigmoid family)",
   ("N",None), ("N",None), ("P","d"), ("N",None), ("N",None), ("N",None)),
  ("Geraci et al.", "IEEE Commun. Surveys Tuts.", "2022",
   "UAV cellular 5G-to-6G survey",
   ("N",None), ("N",None), ("N",None), ("N",None), ("N",None), ("N",None)),
 ]),
 ("III. Measurement campaigns", [
  ("Amorim et al.", "IEEE Wireless Commun. Lett.", "2017",
   "Rural LTE A2G measurements",
   ("P","e"), ("X",None), ("N",None), ("N",None), ("N",None), ("N",None)),
  ("Lin et al.", "IEEE Commun. Mag.", "2018",
   "Live-network LTE field trials",
   ("P","e"), ("X",None), ("N",None), ("N",None), ("N",None), ("N",None)),
  ("UWB A2G with airframe effects", "IEEE Trans. Intell. Transp. Syst.", "2024",
   "Measurement-based UWB A2G model",
   ("N",None), ("X",None), ("N",None), ("N",None), ("N",None), ("N",None)),
 ]),
 ("IV. Simulators published at Q1", [
  ("QuaDRiGa (Jaeckel et al.)", "IEEE Trans. Antennas Propag.", "2014/23",
   "GBSM simulator, 38.901 family",
   ("N","f"), ("P","g"), ("N",None), ("N",None), ("N",None), ("P","h")),
  ("NYUSIM (Poddar et al.)", "IEEE Commun. Surveys Tuts.", "2024",
   "Measurement-based simulator",
   ("X",None), ("P","i"), ("N",None), ("P","j"), ("N",None), ("P","k")),
 ]),
 ("V. Most recent Q1 modeling and learning consumers", [
  ("DRL ISAC UAV network", "IEEE Trans. Wireless Commun.", "2023",
   "Learning-based optimization",
   ("N",None), ("N",None), ("N",None), ("N",None), ("N","l"), ("N",None)),
  ("Movable-antenna U2U channels", "IEEE Trans. Wireless Commun.", "2026",
   "Analytical U2U wideband model",
   ("N","m"), ("N",None), ("N",None), ("N",None), ("N",None), ("N",None)),
 ]),
 ("VI. This dissertation", [
  ("Chapter 3 (Alhasan)", "—", "2026",
   "Exact TR 36.777 over TR 38.901",
   ("F",None), ("F",None), ("F",None), ("F",None), ("F",None), ("F",None)),
 ]),
]

COLHEADS = ["Work", "Venue", "Year", "Channel approach",
            "36.777 annex", "Verified impl.", "Altitude theory",
            "FR2 regime and risk", "Decision-level eval.", "Reproducible artifact"]

FOOTNOTES = [
 ("a", "Closed-form optimum for its own sigmoid model, not the standardized model."),
 ("b", "LoS/NLoS blockage-mixing analysis for terrestrial cellular."),
 ("c", "Reliability analysis within the sigmoid family."),
 ("d", "Survey coverage of sigmoid-tradition results."),
 ("e", "Supplies or corroborates the empirical basis of the TR 36.777 annex (measurement role)."),
 ("f", "Satellite NTN extension calibrated to TR 38.821; not the TR 36.777 UAV annex."),
 ("g", "Published 3GPP calibration curves (TR 36.873/38.901/38.821)."),
 ("h", "MATLAB/Octave under a non-commercial research licence."),
 ("i", "Validated against NYU measurement statistics; non-3GPP by design."),
 ("j", "Native mmWave/sub-THz scope."),
 ("k", "Free download with citation requirement; MATLAB."),
 ("l", "Channel enters as an environment abstraction; its statistical correctness is not examined."),
 ("m", "Analytical model for a non-standardized link type (UAV-to-UAV, low-altitude economy)."),
]

THIS_WORK_NOTE = ("Entries for this work denote: exact transcription-verified implementation of the "
 "TR 36.777 aerial annex (first with a published verification chain); five-layer verification, "
 "48 automated checks with CI-accounted statistical campaign; closed-form LoS wall h1(r) with "
 "three-mechanism sensitivity and five-regime taxonomy; FR2 bimodality with the [-23, -2] dB "
 "value bracket contracting to a <=14.4 m decision shift; measured policy regret 0.21-0.35 "
 "(free-space) and ~0-0.30 (sigmoid); frozen v1.0.0 interface, bit-reproducible under a "
 "SHA-256 manifest at ~10^4 user-steps/s.")
