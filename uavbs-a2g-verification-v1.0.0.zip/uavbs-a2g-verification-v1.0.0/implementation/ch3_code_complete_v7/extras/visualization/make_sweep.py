"""Altitude-sweep animation (~20 s, 25 fps, 1280x720) for IEEE Access
multimedia + defense. All values from the frozen verified package."""
import math, os, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, FancyBboxPatch

import os as _os
_HERE = _os.path.dirname(_os.path.abspath(__file__))
sys.path.insert(0, _os.path.join(_HERE, '../../stage2'))
import uav_channel as uc

INK, INK2, MUT = '#1a1f26', '#4c5560', '#8a939e'
BLUE, VERM, GREEN = '#0072B2', '#D55E00', '#009E73'
plt.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['DejaVu Sans']})

R0, ENV = 500.0, 'UMa'
HGRID = np.arange(20.0, 300.5, 1.0)
PC26 = np.array([uc.p_cov(ENV, R0, float(h), 2.6, 120.0) for h in HGRID])
PC28 = np.array([uc.p_cov(ENV, R0, float(h), 28.0, 115.0) for h in HGRID])
PLOS = np.array([uc.plos_aerial(ENV, R0, float(h)) for h in HGRID])
SFL  = np.array([uc.sf_std_aerial(ENV, float(h), 'LOS') for h in HGRID])
WALL = uc.h_wall(ENV, R0)                       # 100.0
S26 = uc.h_star_refined(ENV, R0, 2.6, 120.0)
S28 = uc.h_star_refined(ENV, R0, 28.0, 115.0)
H26 = S26['h_plateau_lo'] if S26['regime'] == 'plateau' else S26['h_star']
H28 = S28['h_plateau_lo'] if S28['regime'] == 'plateau' else S28['h_star']

FPS = 25
FRAMES = _os.path.join(_HERE, 'frames')
os.makedirs(FRAMES, exist_ok=True)
frame_no = [0]

def smooth(t):
    return 3*t*t - 2*t*t*t

def card(lines, sub=None, seconds=1.2):
    fig = plt.figure(figsize=(12.8, 7.2), dpi=100)
    fig.patch.set_facecolor('white')
    y = 0.60
    for i, (txt, fs, w) in enumerate(lines):
        fig.text(0.5, y - i*0.105, txt, fontsize=fs, fontweight=w, color=INK, ha='center')
    if sub:
        for j, s in enumerate(sub):
            fig.text(0.5, 0.30 - j*0.055, s, fontsize=15, color=INK2, ha='center')
    fig.savefig(_os.path.join(FRAMES, f'f{frame_no[0]:04d}.png'))
    plt.close(fig)
    fname = _os.path.join(FRAMES, f'f{frame_no[0]:04d}.png')
    for _ in range(int(seconds*FPS) - 1):
        frame_no[0] += 1
        os.link(fname, _os.path.join(FRAMES, f'f{frame_no[0]:04d}.png'))
    frame_no[0] += 1

def sweep_frame(h, pc, col, fc_label, lmax, hstar, regime_label, annos):
    fig = plt.figure(figsize=(12.8, 7.2), dpi=100)
    fig.patch.set_facecolor('white')
    fig.text(0.02, 0.955, 'How high should a UAV base station fly?', fontsize=17,
             fontweight='bold', color=INK)
    fig.text(0.02, 0.905, f'{ENV} · {fc_label} · link budget {lmax} dB · ground range r = {R0:.0f} m',
             fontsize=12.5, color=INK2)

    # ---- left: geometry ----
    ax = fig.add_axes([0.03, 0.30, 0.33, 0.56]); ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis('off')
    ax.add_patch(Rectangle((0, 0.9), 10, 0.16, color='#b9c1c9'))
    for (x, w, hh) in [(0.5,0.9,2.1),(1.7,0.8,3.0),(2.8,1.0,1.8),(4.1,0.85,2.6),(5.3,0.9,2.0),(6.5,0.8,2.8)]:
        ax.add_patch(Rectangle((x, 1.06), w, hh, color='#dbe1e7'))
    ux, uy = 8.6, 1.35
    ax.add_patch(Circle((ux, uy+0.30), 0.15, color=INK2))
    ax.plot([ux, ux], [uy-0.22, uy+0.16], color=INK2, lw=2.2)
    ax.text(ux, uy-0.55, 'user', fontsize=10, color=INK2, ha='center')
    # UAV vertical position mapped: h in [20,300] -> y in [2.0, 9.0]
    vy = 2.0 + (h-20)/280*7.0
    vx = 2.75
    ax.plot([vx-0.45, vx+0.45], [vy, vy], color=INK, lw=2.8)
    ax.plot([vx-0.45, vx-0.45], [vy-0.17, vy+0.17], color=INK, lw=2.1)
    ax.plot([vx+0.45, vx+0.45], [vy-0.17, vy+0.17], color=INK, lw=2.1)
    ax.add_patch(Circle((vx, vy), 0.15, color=col))
    ax.plot([vx, ux], [vy, uy+0.30], color=col, lw=2.0)
    ax.plot([vx, ux], [vy, uy+0.30], color=col, lw=7, alpha=0.10)
    # altitude rail
    ax.plot([0.55, 0.55], [2.0, 9.0], color='#d0d6dc', lw=2)
    ax.plot([0.42, 0.68], [vy, vy], color=col, lw=3)
    ax.text(0.55, 9.45, 'h [m]', fontsize=10, color=MUT, ha='center')
    ax.text(1.00, vy, f'{h:.0f}', fontsize=13, color=INK, va='center', fontweight='bold')
    # readouts
    i = int(round(h - 20))
    plos, sf = PLOS[i], SFL[i]
    theta = math.degrees(math.atan2(h-1.5, R0))
    fig.text(0.045, 0.245, f'elevation θ = {theta:4.1f}°', fontsize=12.5, color=INK2)
    # P_LoS gauge
    figw = 0.145
    fig.text(0.045, 0.196, 'P(line of sight)', fontsize=11, color=MUT)
    figax = fig.add_axes([0.045, 0.152, figw, 0.032]); figax.set_xlim(0,1); figax.set_ylim(0,1)
    figax.axis('off')
    figax.add_patch(Rectangle((0,0), 1, 1, fc='#eceff2', ec='none'))
    figax.add_patch(Rectangle((0,0), plos, 1, fc=GREEN, ec='none'))
    figax.text(1.03, 0.5, f'{plos:.3f}', fontsize=11.5, color=INK, va='center', transform=figax.transAxes)
    # sigma gauge (hardening)
    fig.text(0.045, 0.106, 'shadowing σ_LoS  (hardening →)', fontsize=11, color=MUT)
    sgax = fig.add_axes([0.045, 0.062, figw, 0.032]); sgax.set_xlim(0,1); sgax.set_ylim(0,1)
    sgax.axis('off')
    sgax.add_patch(Rectangle((0,0), 1, 1, fc='#eceff2', ec='none'))
    sgax.add_patch(Rectangle((0,0), sf/5.0, 1, fc=VERM, ec='none'))
    sgax.text(1.03, 0.5, f'{sf:.2f} dB', fontsize=11.5, color=INK, va='center', transform=sgax.transAxes)

    # ---- right: coverage curve ----
    axc = fig.add_axes([0.44, 0.115, 0.53, 0.74])
    axc.set_xlim(20, 300); axc.set_ylim(0, 1.04)
    axc.set_xlabel('UAV altitude h [m]', fontsize=13)
    axc.set_ylabel('coverage probability  P_cov', fontsize=13)
    axc.tick_params(labelsize=11)
    for s in ('top', 'right'):
        axc.spines[s].set_visible(False)
    axc.grid(axis='y', color='#eef1f4', lw=0.8)
    axc.plot(HGRID, pc, color='#ccd3d9', lw=1.6)                 # full curve, faint
    axc.plot(HGRID[:i+1], pc[:i+1], color=col, lw=3.0)           # traced part
    axc.scatter([h], [pc[i]], s=90, color=col, edgecolor='white', linewidth=1.6, zorder=6)
    axc.text(0.985, 1.005, f'P_cov = {pc[i]:.3f}', transform=axc.transAxes, fontsize=13,
             color=INK, ha='right', fontweight='bold')
    if WALL <= 300:
        axc.axvline(WALL, color='#7a838d', ls=(0, (5, 4)), lw=1.4)
        axc.text(WALL+4, 0.06, f'LoS wall h₁ = {WALL:.0f} m', fontsize=11, color='#5a636d')
    for (hx, txt, dy) in annos:
        if h >= hx:
            j = int(round(hx - 20))
            axc.scatter([hx], [pc[j]], s=42, color=INK, zorder=5)
            axc.annotate(txt, xy=(hx, pc[j]), xytext=(hx+10, min(1.0, pc[j]+dy)),
                         fontsize=11.5, color=INK,
                         arrowprops=dict(arrowstyle='-', color=MUT, lw=0.9))
    # regime chip
    fig.text(0.44, 0.028, regime_label, fontsize=12, color=INK2,
             bbox=dict(boxstyle='round,pad=0.4', fc='#f3f6f9', ec='#dde3e9'))
    fig.savefig(_os.path.join(FRAMES, f'f{frame_no[0]:04d}.png'))
    plt.close(fig)
    frame_no[0] += 1

# ---------- S1: title ----------
card([('How high should a UAV base station fly?', 26, 'bold'),
      ('the 3GPP aerial channel answers — if you implement it exactly', 16, 'normal')],
     sub=['3GPP TR 36.777 over TR 38.901 · verified implementation (48 automated checks)',
          'externally cross-validated against QuaDRiGa (9,000 links)'], seconds=2.2)

# ---------- S2: sub-6 sweep ----------
N2 = 250
ann26 = [(WALL, 'clutter escape complete', -0.35),
         (H26, f'h* = {H26:.0f} m — plateau begins\n(energy-preferred edge)', -0.16)]
for k in range(N2):
    t = smooth(k/(N2-1))
    h = 20 + 280*t
    sweep_frame(h, PC26, BLUE, '2.6 GHz', 120, H26,
                f"regime: {S26['regime']}  ·  optimum h* = {H26:.0f} m (energy-preferred)", ann26)

# ---------- S3: transition ----------
card([('Same cell. Same geometry.', 22, 'bold'),
      ('Now at 28 GHz (FR2), link budget 115 dB.', 18, 'normal')], seconds=1.6)

# ---------- S4: FR2 sweep ----------
N4 = 150
ann28 = [(H28, f'h* = {H28:.1f} m — interior optimum', 0.10),
         (150.0, 'multiple modes — small model\nerrors can flip the winner', 0.08)]
for k in range(N4):
    t = smooth(k/(N4-1))
    h = 20 + 280*t
    sweep_frame(h, PC28, VERM, '28 GHz (FR2)', 115, H28,
                f"regime: {S28['regime']}  ·  {S28['n_modes']} coverage modes  ·  h* = {H28:.1f} m", ann28)

# ---------- S5: end card ----------
card([('Altitude buys line of sight — and pays in diversity.', 19, 'bold'),
      ('Sub-6: a forgiving plateau.  FR2: a narrow, bimodal optimum.', 15, 'normal')],
     sub=['Every value from the frozen reference implementation — 48 automated checks',
          'QuaDRiGa 2.8.1 cross-validation: ≤0.01 dB on all shared expressions (9,000 links)',
          'Chapter 3 — Constraint-Aware DRL Frameworks for Sustainable Multi-UAV B5G Networks'],
     seconds=2.6)

print('frames:', frame_no[0])
