"""Precompute the explorer dataset from the frozen, verified package.
No physics re-implemented here: every number is a package call."""
import sys, json, time
import os as _os
_HERE = _os.path.dirname(_os.path.abspath(__file__))
sys.path.insert(0, _os.path.join(_HERE, '../../stage2'))
import uav_channel as uc

ENVS = ['UMa', 'UMi', 'RMa']
FCS = [2.6, 3.5, 28.0]
BUDGETS = [105, 110, 115, 120, 125, 130]
H = [round(20 + 2*i, 1) for i in range(141)]          # 20..300 m, 2 m display grid
R = [50*i for i in range(1, 21)]                      # 50..1000 m

t0 = time.time()
out = {'h': H, 'r': R, 'budgets': BUDGETS, 'fcs': FCS, 'envs': ENVS,
       'wall': {}, 'data': {}}

for env in ENVS:
    out['wall'][env] = [round(uc.h_wall(env, float(r)), 2) for r in R]

for env in ENVS:
    for fc in FCS:
        for L in BUDGETS:
            key = f"{env}|{fc}|{L}"
            pcov = [[round(uc.p_cov(env, float(r), float(h), fc, float(L)), 4)
                     for h in H] for r in R]
            stats = []
            for r in R:
                s = uc.h_star_refined(env, float(r), fc, float(L))
                h_ep = s['h_plateau_lo'] if s['regime'] == 'plateau' else s['h_star']
                stats.append({
                    'hstar': round(h_ep, 1),
                    'hraw': round(s['h_star'], 1),
                    'regime': s['regime'],
                    'pmax': round(s['p_max'], 4),
                    'nmodes': s['n_modes'],
                    'plos': round(uc.plos_aerial(env, float(r), h_ep), 4),
                })
            out['data'][key] = {'pcov': pcov, 'stats': stats}
        print(f"{env} {fc} done  {time.time()-t0:.0f}s", flush=True)

with open(_os.path.join(_HERE, 'data.json'), 'w') as f:
    json.dump(out, f, separators=(',', ':'))
import os
print('bytes:', os.path.getsize(_os.path.join(_HERE, 'data.json')))
