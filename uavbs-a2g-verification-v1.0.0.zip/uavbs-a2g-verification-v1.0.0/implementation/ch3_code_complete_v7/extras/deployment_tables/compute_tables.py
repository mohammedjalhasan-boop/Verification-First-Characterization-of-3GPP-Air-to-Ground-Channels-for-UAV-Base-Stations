#!/usr/bin/env python3
"""Deployment quick-reference dataset, computed from the verified uav_channel
package. Outputs: tableA.csv (coverage radius at 95% target), tableB.csv
(fixed radii). Grid: h step 0.5 m; r capped at the studied 1000-m grid."""
import sys, csv
import os as _os
_HERE = _os.path.dirname(_os.path.abspath(__file__))
sys.path.insert(0, _os.path.join(_HERE, '../../stage2'))
import numpy as np
import uav_channel as uc

ENVS = ["UMa", "UMi", "RMa"]
FCS = [2.6, 3.5, 28.0]
BUDGETS = [105.0, 110.0, 115.0, 120.0, 125.0, 130.0]
RADII = [200.0, 500.0, 1000.0]
RMAX = 1000.0          # studied validity grid
TARGET = 0.95
NLOS_HMAX = {"UMa": 100.0, "UMi": 300.0, "RMa": 40.0}   # NLoS state existence

def hgrid(env):
    lo = 10.5 if env == "RMa" else 23.0
    return np.arange(lo, 300.01, 0.5)

def best(env, r, fc, lm):
    """Energy-preferred optimum: lowest h within 1e-3 of max coverage."""
    H = hgrid(env)
    pc = np.array([uc.p_cov(env, r, h, fc, lm) for h in H])
    m = float(pc.max())
    hstar = float(H[np.argmax(pc >= m - 1e-3)])
    # regime label from the refined solver (chapter's own classifier)
    try:
        reg = uc.h_star_refined(env, r, fc, lm).get("regime", "")
        nm = uc.h_star(env, r, fc, lm).get("n_modes", 0)
        if nm and nm > 1:
            reg = "bimodal"
    except Exception:
        reg = ""
    return hstar, m, reg

def Q(x):
    from math import erf, sqrt
    return 0.5 * (1 - erf(x / sqrt(2)))

def row_metrics(env, r, fc, lm, h):
    plos = float(uc.plos_aerial(env, r, h))
    if h > NLOS_HMAX[env] or plos >= 0.9995:
        pnl = ""          # NLoS state unreachable at h*
    else:
        pl_n = float(uc.pl_nlos_aerial(env, r, h, fc))
        s_n = float(uc.sf_std_aerial(env, h, "NLOS"))
        pnl = round(Q((pl_n - lm) / s_n), 3)
    return plos, pnl

def r95(env, fc, lm):
    """Largest r <= RMAX with max_h Pcov >= TARGET; '' if none, '>{RMAX}' if
    still feasible at the cap."""
    if best(env, RMAX, fc, lm)[1] >= TARGET:
        return f">{int(RMAX)}", RMAX
    lo, hi = 25.0, RMAX
    if best(env, lo, fc, lm)[1] < TARGET:
        return "infeasible", None
    while hi - lo > 2.0:
        mid = 0.5 * (lo + hi)
        if best(env, mid, fc, lm)[1] >= TARGET:
            lo = mid
        else:
            hi = mid
    return f"{lo:.0f}", lo

# ---------------- Table A: coverage radius at the 95% target ----------------
with open('tableA.csv', 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(["budget_dB", "env", "fc_GHz", "r95_m", "h_star_m",
                "P_LoS", "Pcov_at_opt", "Pcov_given_NLoS", "regime"])
    for lm in BUDGETS:
        for env in ENVS:
            for fc in FCS:
                label, rval = r95(env, fc, lm)
                if rval is None:
                    w.writerow([lm, env, fc, "infeasible", "", "", "", "", ""])
                    continue
                h, m, reg = best(env, rval, fc, lm)
                plos, pnl = row_metrics(env, rval, fc, lm, h)
                w.writerow([lm, env, fc, label, round(h, 1), round(plos, 3),
                            round(m, 3), pnl, reg])
        print(f"Table A budget {lm} done")

# ---------------- Table B: fixed radii ----------------
with open('tableB.csv', 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(["budget_dB", "env", "fc_GHz", "r_m", "h_star_m",
                "Pcov", "P_LoS", "Pcov_given_NLoS", "regime"])
    for lm in BUDGETS:
        for env in ENVS:
            for fc in FCS:
                for r in RADII:
                    h, m, reg = best(env, r, fc, lm)
                    plos, pnl = row_metrics(env, r, fc, lm, h)
                    w.writerow([lm, env, fc, int(r), round(h, 1), round(m, 3),
                                round(plos, 3), pnl, reg])
        print(f"Table B budget {lm} done")
print("ALL DONE")
