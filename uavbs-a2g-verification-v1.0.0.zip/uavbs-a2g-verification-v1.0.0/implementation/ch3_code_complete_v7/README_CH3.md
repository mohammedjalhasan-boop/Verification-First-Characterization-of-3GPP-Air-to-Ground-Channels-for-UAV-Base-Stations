# Chapter 3 (Objective 1) -- complete pack

Dissertation: "Constraint-Aware DRL Frameworks for Sustainable Multi-UAV
B5G Networks" (M. J. Alhasan). Contents:

  ch3_stage1_channel_model.pdf/.tex   Stage 1: mathematical instantiation
                                      (TR 36.777 + TR 38.901) + optimal-
                                      altitude theory. verify_ch3.py = the
                                      numerically validated oracle.
  stage2/    uav_channel package (26 tests), lookup exports, Sionna kit (V4)
  stage3/    validation campaign (10 tests), Sec. 3.3 metrics, E1 FR2
             bracket, QuaDRiGa kit (V5)
  stage4/    frozen DRL interface v1.0.0 (12 tests), CHANNEL_API.md,
             schema.json (SHA-256 manifest), benchmark, demo episode

Run all suites:
  (cd stage2 && python3 -m unittest discover -s tests)
  (cd stage3 && python3 -m unittest discover -s tests)
  (cd stage4 && python3 -m unittest discover -s tests)

External follow-ups (do not block Chapter 4):
  V4: pip install sionna && python stage2/scripts/sionna_demo.py
  V5: run stage3/quadriga_kit/quadriga_campaign.m in QuaDRiGa, then
      python stage3/quadriga_kit/ingest_quadriga.py quadriga_samples.csv
