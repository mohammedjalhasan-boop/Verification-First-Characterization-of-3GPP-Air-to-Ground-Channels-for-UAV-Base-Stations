# Chapter 3 — Complete Code Pack (v6, August 2026)

Dissertation: *Constraint-Aware DRL Frameworks for Sustainable Multi-UAV B5G
Networks* — Chapter 3 (Objective 1), M. J. Alhasan, Al-Furat Al-Awsat
Technical University.

**Read the Implementation Guide PDF first** (`Implementation_Guide.pdf`,
shipped beside this pack): it walks through installation, the verification
suites, every figure/table regeneration, the MATLAB side, and a
troubleshooting table of real errors with fixes. This README is the map.

## What is in the pack

```
ch3_code_complete_v6/
├── README_CH3.md               original archive readme (stage structure)
├── requirements.txt            Python deps (numpy, scipy, matplotlib)
├── verify_ch3.py               Stage-1 numerical oracle
├── ch3_stage1_channel_model.*  Stage-1 mathematical instantiation (tex/pdf)
├── stage2/                     THE VERIFIED CORE: uav_channel package
│   ├── uav_channel/            params / large_scale / shadowing / small_scale
│   │                           / altitude / lookup  (frozen; do not edit)
│   ├── tests/                  26 automated checks
│   └── scripts/make_figures.py chapter figures f1–f6 (overlap-fixed v6)
├── stage3/                     validation campaign: 10 checks, metrics,
│   ├── scripts/                FR2 bracket, figures g1–g6
│   └── quadriga_kit/           EXECUTED external cross-validation:
│                               quadriga_campaign.m (API-fixed), comparator,
│                               report_executed_2026-08.csv + analysis scripts
├── stage4/                     frozen DRL interface v1.0.0: 12 checks
├── matlab/                     MATLAB port + parity gate + campaign script
│                               (see matlab/README_MATLAB.md)
├── discussion/                 chapter3_complete.tex/pdf + all figures
│   └── rewritten/              dissertation-register chapter (v3, with the
│                               executed QuaDRiGa section, Table 3.8, Fig 3.13)
└── extras/                     deployment tables, literature table,
                                interactive explorer, graphical abstract/video
```

## Quickstart — Python (5 commands)

```bash
python -m venv venv && source venv/bin/activate     # Windows: venv\Scripts\activate
pip install -r requirements.txt
(cd stage2 && python -m unittest discover -s tests)   # 26 checks -> OK
(cd stage3 && python -m unittest discover -s tests)   # 10 checks -> OK
(cd stage4 && python -m unittest discover -s tests)   # 12 checks -> OK
```

All 48 checks passing = the implementation on *your* machine equals the
standard. Then regenerate everything:

```bash
python stage2/scripts/make_figures.py     # chapter figs f1–f6
python stage3/scripts/run_stage3.py       # metrics CSVs (if re-deriving)
python stage3/scripts/make_figures3.py    # figs g1–g6
python extras/deployment_tables/compute_tables.py   # Tables A/B
```

## Quickstart — MATLAB (2 commands)

```matlab
cd matlab
parity_check      % must print PARITY PASS before any use
demo_deployment   % chapter headline numbers with expected values
```

## The one rule

`stage2/uav_channel/` is frozen and hash-manifested. Every figure, table,
explorer value, and MATLAB result derives from it. If you need different
behaviour, write a wrapper — never edit the frozen package — and re-run the
48 checks after any environment change.
