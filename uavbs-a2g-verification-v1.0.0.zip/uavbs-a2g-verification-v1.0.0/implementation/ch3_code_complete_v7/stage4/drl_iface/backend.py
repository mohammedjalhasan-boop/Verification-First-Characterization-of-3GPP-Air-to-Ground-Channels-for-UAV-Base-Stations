"""UAVChannelBackend -- the frozen channel provider for Chapters 4-7.

Contract v1.0.0 (CHANNEL_API.md). One backend instance = one cell/episode
context. All randomness flows from a single seed: identical (seed, inputs)
=> identical outputs, bit-for-bit.

Per-TTI output (step): dict of arrays over K users
  plos[K]        model P_LoS at current geometry (closed form, exact)
  state[K]       1 = link in LoS (held per episode; redraw after the
                 spatial-consistency state distance is exceeded)
  pl_db[K]       state-conditioned path loss (TR 36.777/38.901 piecewise)
  sf_db[K]       correlated shadow fading (mode 'map' or 'ar', see A6)
  gain_db[K]     -(pl+sf)   large-scale link gain
  gains_prb[K,B] linear |h|^2 per PRB incl. fast fading (unit-mean),
                 i.e. |h_bar_{k,b}|^2 of the Chapter-4 MDP state
  features[K,F]  FEATURE_NAMES aux vector for the agent
"""
from __future__ import annotations
import numpy as np

import uav_channel as uc
from uav_channel import params as P
from .fading import FadingTracker

FEATURE_NAMES = ("plos", "state_los", "pl_db", "sf_db", "sigma_db",
                 "mean_gain_db", "bc_mhz", "tc_ms", "h_wall_m",
                 "elevation_deg")


def prb_bandwidth_hz(mu):
    """5G NR PRB bandwidth: 12 subcarriers x 15*2^mu kHz."""
    return 12 * 15e3 * (2 ** mu)


def _prb_freqs(n_prb, mu):
    bw = prb_bandwidth_hz(mu)
    return (np.arange(n_prb) - (n_prb - 1) / 2.0) * bw


class UAVChannelBackend:
    def __init__(self, env="UMa", fc_ghz=3.5, n_prb=100, mu=1, seed=0,
                 sf_mode="map", d_corr=None, extent=(1000.0, 1000.0),
                 alt1_state_for_fading=True, ue_speed_mps=3.0,
                 table_mode=False):
        assert env in P.ENVS and sf_mode in ("map", "ar")
        self.env, self.fc, self.mu = env, float(fc_ghz), mu
        self.n_prb = int(n_prb)
        self.sf_mode = sf_mode
        self.rng = np.random.default_rng(seed)
        self.prb_f = _prb_freqs(self.n_prb, mu)
        self.ue_speed = float(ue_speed_mps)
        self.table_mode = bool(table_mode)
        self._interp = None
        if sf_mode == "map":
            self.sfgen = uc.SFGenerator(env, extent=extent, dx=5.0,
                                        d_corr=d_corr,
                                        rng=self.rng.integers(2 ** 31))
        self.d_corr = d_corr or P.SF_DCORR[(env, "LOS")]
        self.d_state = P.SPATIAL_CONSISTENCY[env]["state"]
        self.alt1 = alt1_state_for_fading
        self._users = None

    # ------------------------------------------------------------------ table
    def _build_interp(self):
        from scipy.interpolate import RegularGridInterpolator as RGI
        lo, hi = P.AERIAL_PLOS[self.env]["band"]
        h = np.arange(lo + 0.5, hi + 1e-9, 2.5)
        r = np.arange(20.0, 1500.0 + 1e-9, 10.0)
        H, R = np.meshgrid(h, r, indexing="ij")
        self._interp = {
            "LOS": RGI((h, r), uc.path_loss(self.env, R, H, self.fc, "LOS"),
                       bounds_error=False, fill_value=None),
            "NLOS": RGI((h, r), uc.path_loss(self.env, R, H, self.fc, "NLOS"),
                        bounds_error=False, fill_value=None)}

    def _pl(self, r, h, state):
        if not self.table_mode:
            return uc.path_loss(self.env, r, h, self.fc,
                                "LOS" if state else "NLOS")
        if self._interp is None:
            self._build_interp()
        key = "LOS" if state else "NLOS"
        return float(self._interp[key]((h, r)))

    # ------------------------------------------------------------------ reset
    def reset(self, uav_pos, user_pos):
        """uav_pos (3,), user_pos (K,3) [m]. Draws states, SF, trackers."""
        self.uav = np.asarray(uav_pos, float).copy()
        up = np.asarray(user_pos, float).copy()
        K = len(up)
        d2d = np.hypot(up[:, 0] - self.uav[0], up[:, 1] - self.uav[1])
        plos = np.atleast_1d(uc.plos(self.env, d2d, self.uav[2]))
        state = self.rng.random(K) < plos
        self._users = dict(pos=up, state=state,
                           acc_disp=np.zeros(K),        # for state redraw
                           sf_ar=np.zeros(K), K=K)
        if self.sf_mode == "ar":
            self._users["sf_ar"] = self.rng.standard_normal(K)
        self.trackers = []
        for k in range(K):
            self.trackers.append(self._make_tracker(up[k], bool(state[k])))
        return self._observe(0.0)

    def _make_tracker(self, upos, los):
        dx, dy = upos[0] - self.uav[0], upos[1] - self.uav[1]
        d2 = max(np.hypot(dx, dy), 1.0)
        az = np.degrees(np.arctan2(dy, dx))
        zen_down = np.degrees(np.arctan2(d2, self.uav[2] - upos[2]))
        los_ang = dict(aod=az, aoa=(az + 180) % 360 - 180,
                       zod=180 - zen_down, zoa=zen_down)
        st = "LOS" if los else "NLOS"
        if self.env in ("UMa", "RMa") and self.alt1:
            cdl = uc.alt1_cdl(self.env, d2, self.uav[2], st, los_ang)
        else:  # UMi or Alt-3 fallback: CDL-D scaled to K=15 dB, DS 30 ns
            cdl = uc.scale_k(P.CDL_D, 15.0)
            cdl = uc.scale_delays(cdl, 30e-9)
        v_ue = uc.velocity_vec(self.ue_speed,
                               float(self.rng.uniform(-180, 180)))
        return FadingTracker(cdl, self.fc, self.prb_f, v_rx=v_ue,
                             rng=self.rng.integers(2 ** 31))

    # ------------------------------------------------------------------- step
    def step(self, uav_pos, user_pos, dt):
        """Advance one TTI. Positions may have moved; dt in seconds."""
        new_uav = np.asarray(uav_pos, float)
        up_new = np.asarray(user_pos, float)
        u = self._users
        d_uav = float(np.linalg.norm(new_uav - self.uav))
        d_user = np.linalg.norm(up_new - u["pos"], axis=1)
        # ---- LoS/NLoS state hold + spatial-consistency redraw (A.2.3/7.6.3)
        u["acc_disp"] += d_user + d_uav
        d2d = np.hypot(up_new[:, 0] - new_uav[0], up_new[:, 1] - new_uav[1])
        plos = np.atleast_1d(uc.plos(self.env, d2d, new_uav[2]))
        redraw = u["acc_disp"] >= self.d_state
        if np.any(redraw):
            new_state = self.rng.random(u["K"]) < plos
            for k in np.flatnonzero(redraw):
                if new_state[k] != u["state"][k]:
                    u["state"][k] = new_state[k]
                    self.trackers[k] = self._make_tracker(up_new[k],
                                                          bool(new_state[k]))
                u["acc_disp"][k] = 0.0
        # ---- shadow fading (A6) ------------------------------------------
        st_names = np.where(u["state"], "LOS", "NLOS")
        sig = np.array([float(uc.sf_std(self.env, new_uav[2], s, r, self.fc))
                        for s, r in zip(st_names, d2d)])
        if self.sf_mode == "map":
            sf = np.array([float(self.sfgen.sample(x, y, new_uav[2], s))
                           for (x, y), s in zip(up_new[:, :2], st_names)])
        else:
            rho = np.exp(-(d_user + d_uav) / self.d_corr)
            u["sf_ar"] = rho * u["sf_ar"] + np.sqrt(1 - rho ** 2) \
                * self.rng.standard_normal(u["K"])
            sf = sig * u["sf_ar"]
        # ---- large scale + fast fading -----------------------------------
        pl = np.array([self._pl(float(r), float(new_uav[2]), bool(s))
                       for r, s in zip(d2d, u["state"])])
        gains = np.stack([t.gains(dt) for t in self.trackers])
        self.uav = new_uav.copy()
        u["pos"] = up_new.copy()
        return self._pack(d2d, plos, pl, sf, sig, gains, new_uav, up_new)

    def _observe(self, dt):
        u = self._users
        return self.step(self.uav, u["pos"], dt)

    def _pack(self, d2d, plos, pl, sf, sig, gains, uav, up):
        elev = np.degrees(np.arctan2(uav[2] - up[:, 2], np.maximum(d2d, 1.0)))
        r_cell = np.maximum(d2d, 18.0)
        feats = np.stack([
            plos, self._users["state"].astype(float), pl, sf, sig,
            -(pl + sf),
            1.0 / (2 * np.pi * np.where(self._users["state"], 10e-9, 30e-9)) / 1e6,
            np.full_like(pl, uc.coherence_time(max(self.ue_speed, 0.1),
                                               self.fc) * 1e3),
            np.atleast_1d(uc.h_wall(self.env, r_cell)),
            elev], axis=1)
        ls_lin = 10 ** (-(pl + sf) / 10.0)
        return dict(plos=plos, state=self._users["state"].copy(),
                    pl_db=pl, sf_db=sf, gain_db=-(pl + sf),
                    gains_prb=ls_lin[:, None] * gains,
                    fast_prb=gains, features=feats, d2d=d2d)

    # ------------------------------------------------------------- priors
    def altitude_prior(self, r_cell):
        """Initialisation prior of Chapters 4-7: the LoS wall (Stage-1 map)."""
        return float(uc.h_wall(self.env, r_cell))
