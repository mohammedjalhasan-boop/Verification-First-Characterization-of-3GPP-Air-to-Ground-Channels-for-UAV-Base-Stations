"""Stage-4 frozen DRL channel interface (contract v1.0.0, see CHANNEL_API.md).

Bootstraps the Stage-2 package from ../stage2 (or $UAV_CHANNEL_PATH).
"""
import os
import sys

_CAND = [os.environ.get("UAV_CHANNEL_PATH", ""),
         os.path.join(os.path.dirname(__file__), "..", "..", "stage2")]
for _p in _CAND:
    if _p and os.path.isdir(os.path.join(_p, "uav_channel")):
        sys.path.insert(0, os.path.abspath(_p))
        break
import uav_channel  # noqa: E402,F401

from .fading import FadingTracker, rayleigh_reference           # noqa: E402
from .backend import UAVChannelBackend, FEATURE_NAMES, prb_bandwidth_hz  # noqa: E402

API_VERSION = "1.0.0"
