"""Per-TTI, per-PRB fast-fading evolution on a scaled CDL profile.

Model (implementation approximation A5, documented in CHANNEL_API.md):
  * cluster n carries complex gain g_n(t); the specular ray is deterministic
    with phase rotation exp(j 2 pi nu_0 dt); each Laplacian cluster follows a
    Gauss-Markov update with mean Doppler rotation exp(j 2 pi nu_n dt) and
    innovation factor rho_n = J0(2 pi f_spread,n dt), clipped to [0, 1),
    where nu_n = r_hat(AOA_n, ZOA_n)^T v / lambda and
    f_spread,n = f_D,max * min(1, c_ASA [rad]) approximates the intra-cluster
    Doppler spread induced by the per-cluster angular spread.
  * frequency response over PRB b: H_b = sum_n g_n exp(-j 2 pi f_b tau_n),
    f_b the PRB-centre baseband offset -- frequency selectivity follows the
    scaled CDL delays exactly.
Stationarity: E|H_b|^2 = 1 for every b (powers normalised); validated in
tests together with coherence-time and frequency-correlation closures.
"""
from __future__ import annotations
import numpy as np
from scipy.special import j0

import uav_channel as uc
from uav_channel.small_scale import _cdl_arrays, unit_vec


class FadingTracker:
    """Time-frequency fading for ONE link on a scaled CDL.

    Parameters
    ----------
    cdl      : dict from uav_channel.alt1_cdl (or CDL-like dict)
    fc_ghz   : carrier [GHz]
    prb_freqs_hz : array of PRB-centre baseband offsets [Hz]
    v_rx, v_tx   : 3-vectors [m/s] (dual mobility, TR 38.901 7.6.3.2)
    """

    def __init__(self, cdl, fc_ghz, prb_freqs_hz, v_rx=(0, 0, 0),
                 v_tx=(0, 0, 0), rng=None):
        self.rng = np.random.default_rng(rng)
        lam = 3e8 / (fc_ghz * 1e9)
        delays, p_db, ang = _cdl_arrays(cdl)
        p = 10 ** (p_db / 10.0)
        self.p = p / p.sum()
        self.tau = delays
        r_rx = unit_vec(ang["aoa"], ang["zoa"])          # (N,3)
        r_tx = unit_vec(ang["aod"], ang["zod"])
        v_rx = np.asarray(v_rx, float)
        v_tx = np.asarray(v_tx, float)
        self.nu = (r_rx @ v_rx + r_tx @ v_tx) / lam       # per-cluster Doppler
        fdm = (np.linalg.norm(v_rx) + np.linalg.norm(v_tx)) / lam
        ca = np.deg2rad(cdl.get("c_asa", 8.0))
        self.f_spread = np.full_like(self.nu, fdm * min(1.0, ca))
        self.f_spread[0] = 0.0                            # specular: none
        self.fb = np.asarray(prb_freqs_hz, float)
        self.E = np.exp(-2j * np.pi * np.outer(self.tau, self.fb))  # (N,B)
        # initial state: specular at unit amplitude*sqrt(p0), diffuse CN(0,pn)
        n = len(self.p)
        self.g = np.sqrt(self.p) * np.exp(
            2j * np.pi * self.rng.random(n))
        d = (self.rng.standard_normal(n) + 1j * self.rng.standard_normal(n)) \
            / np.sqrt(2.0)
        self.g[1:] = np.sqrt(self.p[1:]) * d[1:]

    def step(self, dt):
        """Advance dt seconds; return complex H over PRBs (shape (B,))."""
        rot = np.exp(2j * np.pi * self.nu * dt)
        self.g[0] *= rot[0]
        rho = np.clip(j0(2 * np.pi * self.f_spread[1:] * dt), 0.0, 1.0 - 1e-12)
        n = len(self.p) - 1
        w = (self.rng.standard_normal(n) + 1j * self.rng.standard_normal(n)) \
            / np.sqrt(2.0)
        self.g[1:] = rho * self.g[1:] * rot[1:] \
            + np.sqrt((1.0 - rho ** 2) * self.p[1:]) * w
        return self.g @ self.E

    def gains(self, dt):
        """|H_b|^2 after advancing dt (convenience for the backend)."""
        h = self.step(dt)
        return np.abs(h) ** 2


def rayleigh_reference(fc_ghz, prb_freqs_hz, speed, ds_s=100e-9, n_cl=12,
                       rng=None):
    """All-diffuse reference tracker (Clarke-like) for closure tests."""
    rng_ = np.random.default_rng(rng)
    delays = np.sort(rng_.exponential(ds_s, n_cl))
    delays[0] = 0.0
    p_db = 10 * np.log10(np.full(n_cl, 1.0 / n_cl))
    az = rng_.uniform(-180, 180, n_cl)
    cl = np.zeros((n_cl - 1, 6))
    cl[:, 0] = delays[1:] / max(ds_s, 1e-12)
    cl[:, 1] = p_db[1:]
    cl[:, 3] = az[1:]                                   # AOA
    cl[:, 5] = 90.0                                     # ZOA horizontal
    cdl = dict(specular=dict(delay=0.0, power=-60.0, aod=0.0, aoa=az[0],
                             zod=90.0, zoa=90.0),
               clusters=cl, c_asd=5.0, c_asa=180.0, c_zsd=3.0, c_zsa=3.0,
               xpr_db=10.0)
    cdl = uc.scale_delays(cdl, ds_s)
    return FadingTracker(cdl, fc_ghz, prb_freqs_hz,
                         v_rx=uc.velocity_vec(speed, 0.0), rng=rng)
