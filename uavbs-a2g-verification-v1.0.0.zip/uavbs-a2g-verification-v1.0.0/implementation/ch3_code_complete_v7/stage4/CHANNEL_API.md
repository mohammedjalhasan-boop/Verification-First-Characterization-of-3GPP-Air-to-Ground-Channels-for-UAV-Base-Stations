# Channel API contract v1.0.0 (frozen) — Chapter 3 → Chapters 4–7

The DRL environments of Chapters 4–7 consume the Chapter-3 channel ONLY
through this interface. Any change after this freeze bumps the version and
must re-run all three test suites (26 + 10 + 12 tests).

## Backend

```python
from drl_iface import UAVChannelBackend

be = UAVChannelBackend(env="UMa",        # UMa | UMi | RMa
                       fc_ghz=3.5,       # 2.6 | 3.5 | 28.0
                       n_prb=100, mu=1,  # 5G NR grid (PRB bw = 12*15e3*2^mu)
                       seed=0,           # SINGLE source of randomness
                       sf_mode="map",    # 'map' | 'ar'   (assumption A6)
                       table_mode=False) # closed-form (exact) | interpolated
obs = be.reset(uav_pos, user_pos)        # (3,), (K,3)  [m]
obs = be.step(uav_pos, user_pos, dt_s)   # one TTI
h0  = be.altitude_prior(r_cell)          # LoS-wall initialisation prior [m]
```

## step() output (dict of numpy arrays)

| key | shape | meaning |
|---|---|---|
| `plos` | (K,) | model P_LoS at current geometry (closed form) |
| `state` | (K,) bool | LoS state; held per link, redrawn only after the spatial-consistency state distance (50/50/60 m) is exceeded |
| `pl_db` | (K,) | state-conditioned path loss, TR 36.777/38.901 piecewise |
| `sf_db` | (K,) | correlated shadow fading (A6 mode) |
| `gain_db` | (K,) | −(pl+sf) |
| `gains_prb` | (K,B) | linear per-PRB gain incl. fast fading — **this is |h̄₍k,b₎|² of the Chapter-4 MDP state** |
| `fast_prb` | (K,B) | unit-mean fast-fading factor alone |
| `features` | (K,10) | `FEATURE_NAMES` = (plos, state_los, pl_db, sf_db, sigma_db, mean_gain_db, bc_mhz, tc_ms, h_wall_m, elevation_deg) |
| `d2d` | (K,) | horizontal ranges |

Reproducibility guarantee: identical `(constructor args, reset/step inputs)`
⇒ bit-identical outputs (tested).

## Fast fading (assumption A5)

Scaled Alt-1 CDL-D per link (UMa/RMa; UMi falls back to K=15 dB Alt-3-style
profile pending flag V1). Specular ray: deterministic Doppler rotation at
ν₀ = r̂ᵀv/λ. Laplacian clusters: Gauss–Markov with per-cluster mean Doppler
rotation and innovation ρ = J0(2π f_spread dt), f_spread = f_D,max·c_ASA[rad].
Frequency selectivity: H_b = Σ g_n e^(−j2π f_b τ_n) over PRB centres — exact
in the scaled CDL delays. Closures tested: unit ensemble mean, measured
coherence time within [0.4, 2.5]× of 0.423/f_D (Rayleigh reference),
frequency decorrelation across B_c, specular rotation rate exact to 2 %.

Physical caveat surfaced by testing (matches the Stage-2 near-line Doppler
spectrum): with sub-degree aerial spreads the diffuse rays decorrelate over
seconds, so *time* averages of |h|² converge slowly; ensemble means are the
correct normalisation check. DRL implication: fading realisations behave as
a per-episode random constant plus slow drift, not per-TTI noise — favour
exploration across episodes over within-episode.

## Shadow fading modes (assumption A6)

* `map` (default): per-state unit fields over the service area
  (R = e^(−d/d_corr)), sampled at user positions, scaled by σ_SF(h, state) —
  inter-user spatial correlation preserved; UAV motion enters through σ(h).
* `ar`: per-link Gauss–Markov on the summed 3-D displacement of both ends
  (D2) — end-to-end temporal decorrelation, no inter-user correlation.
The outline's d_corr ∈ {5,25,50} m sweep is a constructor argument.

## Table mode

`table_mode=True` replaces closed-form PL with a RegularGridInterpolator on
the dense grid (2.5 m × 10 m). Parity tested: max |ΔPL| < 0.05 dB. P_LoS and
σ stay closed-form (exact, and the P_LoS jump at h_sat is never smeared
unless the loader opts to).

## Frozen artifacts (SHA-256 manifest in schema.json)

lookup_core.csv (270 rows, outline §3.2 grid), lookup_dense.npz,
hstar_map.csv (900 solves), sf_maps.npz, fr2_delta_pl.csv,
fr2_hstar_shift.csv, coherence_time.csv, coherence_bandwidth.csv.
