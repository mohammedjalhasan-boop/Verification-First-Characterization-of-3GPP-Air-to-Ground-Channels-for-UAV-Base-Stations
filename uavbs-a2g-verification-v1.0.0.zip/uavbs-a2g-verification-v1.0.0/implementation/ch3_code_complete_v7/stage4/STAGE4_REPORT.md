# Chapter 3 — Stage 4 of 4: Frozen Channel–DRL Interface

M. J. Alhasan — Stage-4 build log, July 2026. **This closes Objective 1.**

## What was frozen

Contract **v1.0.0** (`CHANNEL_API.md` + machine-readable `schema.json` with a
SHA-256 manifest over all eight lookup artifacts). Chapters 4–7 consume the
Chapter-3 channel exclusively through `drl_iface.UAVChannelBackend`:

* `reset(uav_pos, user_pos)` / `step(uav_pos, user_pos, dt)` — one TTI;
  outputs `gains_prb[K,B]` (linear per-PRB gains — literally the
  |h_bar_kb|^2 entry of the Chapter-4 MDP state), large-scale terms, the
  LoS states with spatial-consistency hold/redraw (50/50/60 m), correlated
  shadow fading in two modes (A6: inter-user-correlated `map` /
  per-link `ar` on summed 3-D displacement), and a 10-entry feature vector
  (P_LoS, state, PL, SF, sigma, mean gain, B_c, T_c, h-wall prior,
  elevation).
* `altitude_prior(r)` — the Stage-1 closed-form LoS wall as the DRL
  initialisation prior (the outline's "operating-altitude map").
* Reproducibility: one seed, bit-identical episodes (tested).
* NR grid awareness: PRB bandwidth 12·15·2^mu kHz, mu in {0,1,2} —
  matching the Chapter-4 scenario table (PRB counts {50,100,273}).

## Fast fading per TTI (assumption A5, tested closures)

Per link, the scaled Alt-1 CDL-D drives a per-cluster Gauss–Markov process:
specular ray with exact deterministic Doppler rotation; Laplacian clusters
with per-cluster mean Doppler and J0-innovation; frequency selectivity
H_b = sum_n g_n exp(−j2π f_b tau_n) exact in the scaled delays. Twelve new
unit tests (48 in total across stages) close the physics:

* ensemble-mean |h|^2 = 1 (0.04 tolerance, 400-tracker ensemble);
* measured 50 %-coherence time within [0.4, 2.5]× of 0.423/f_D against the
  Rayleigh reference, main ACF lobe matching |J0| (figure b2);
* PRB correlation decays across B_c = 1/(2π DS) (figure b2);
* specular Doppler rotation rate exact to 2 %;
* K = 20 dB aerial link: |h|^2 variance < 0.05 — near-static, as the
  Stage-2 near-line Doppler spectrum predicted.

A finding worth a paragraph in the dissertation: with sub-degree aerial
angular spreads the diffuse rays decorrelate over **seconds**, so
time-averages of |h|^2 do not converge within an episode — the fading
behaves as a per-episode random constant plus slow drift. The unit-mean test
had to be written over an ensemble; the same fact tells Chapter 4 to favour
across-episode exploration rather than within-episode averaging, and it
makes per-TTI i.i.d.-fading baselines (common in the literature) physically
wrong for aerial LoS links.

## Performance and parity

Pure-NumPy reference backend: ~9.5–10.6 k user-steps/s across
(K,B) ∈ {(10,50), (50,100), (100,273)} — a 1000-TTI, K=50 episode in ≈5 s,
sufficient for the Chapter-4 ablations; the documented optimisation path
(vectorising the per-user tracker loop) is left to the training harness.
`table_mode=True` (interpolated PL) is parity-tested to < 0.05 dB against
the closed form; P_LoS and sigma stay closed-form so the h_sat jump is never
silently smeared (Remark 2.1 handling is a loader decision recorded in the
schema).

## Demo episode

`out4/demo_episode.csv` + figure b1: a climb from 60 m to the h* prior
(100 m at r_cell = 400 m) with 10 drifting users — mean gain improves and
plateaus at the wall, one spatial-consistency state redraw is visible on the
worst user, LoS count stays 9/10. This is the exact loop signature the
Chapter-4 environment will exhibit.

## Final flag register (feeds Chapter 9 limitations)

| Flag | Final Stage-4 status |
|---|---|
| V1 UMi-AV Alt-2 statistics | open (RAN1 archive); backend uses documented K=15 dB fallback for UMi fast fading |
| V2 rooftop height (B.1.1-2) | default 20 m, committee sign-off pending |
| V3 V19.4.0 parameter vintage | closed as documented decision |
| V4 Sionna cross-checks | kit delivered (Stage 2); run locally, ~5 min |
| V5 QuaDRiGa campaign | kit delivered (Stage 3), comparator pipeline tested; run locally |
| E1 28-GHz aerial NLoS | bounded −23…−2 dB; policy-altitude impact ≤ 14.4 m; measurement anchor left to future work |
| D4 sub-physical Alt-2 azimuth spreads | floored at Alt-1 values for simulation (exposed argument) |
| A5/A6 | new Stage-4 implementation assumptions, documented in the API |

## Objective-1 hand-off summary

Stage 1: exact mathematical instantiation + optimal-altitude theory
(closed-form LoS wall, master derivative, FR2 bimodality) — reviewed.
Stage 2: tested implementation (26 tests) + lookup tables + Sionna kit.
Stage 3: statistical validation (10 tests), outline §3.3 metrics, E1
bracket, QuaDRiGa kit. Stage 4: frozen v1.0.0 DRL interface (12 tests),
schema + hashes, benchmark, demo. **Chapter 4 (Objective 2) can start
against `drl_iface` today**; the two external kit runs (V4, V5) and the V1/V2
document pulls are the only outstanding items, none of which block the MDP
work.
