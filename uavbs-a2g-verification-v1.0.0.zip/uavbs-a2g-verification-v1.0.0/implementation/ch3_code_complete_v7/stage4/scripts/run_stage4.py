"""Stage-4: freeze the contract -- schema.json with SHA-256 manifest,
performance benchmark, and a demo episode trace for the figures."""
import csv
import hashlib
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from drl_iface import (UAVChannelBackend, FEATURE_NAMES, API_VERSION,
                       prb_bandwidth_hz)
import uav_channel as uc
from uav_channel import params as P
from uav_channel.lookup import COLUMNS

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
OUT = os.path.join(os.path.dirname(__file__), "..", "out4")
os.makedirs(OUT, exist_ok=True)

# ---- 1. benchmark -----------------------------------------------------------
def bench(K=50, B=100, n_steps=400, mode=False):
    be = UAVChannelBackend(env="UMa", fc_ghz=3.5, n_prb=B, mu=1, seed=1,
                           table_mode=mode)
    rng = np.random.default_rng(0)
    users = np.column_stack([rng.uniform(50, 950, K), rng.uniform(50, 950, K),
                             np.full(K, 1.5)])
    be.reset(np.array([500.0, 500.0, 100.0]), users)
    t0 = time.perf_counter()
    for i in range(n_steps):
        users[:, 0] += 0.003          # 3 m/s * 1 ms
        be.step(np.array([500.0, 500.0 + 0.02 * i, 100.0]), users, 1e-3)
    dt = time.perf_counter() - t0
    return n_steps / dt, n_steps * K / dt

res = {}
for K, B in ((10, 50), (50, 100), (100, 273)):
    sps, ups = bench(K, B)
    res[f"K{K}_B{B}"] = dict(steps_per_s=round(sps, 1),
                             user_steps_per_s=round(ups, 1))
    print(f"benchmark K={K:3d} B={B:3d}: {sps:8.1f} TTI-steps/s "
          f"({ups:9.1f} user-steps/s)")
json.dump(res, open(os.path.join(OUT, "benchmark.json"), "w"), indent=1)

# ---- 2. demo episode --------------------------------------------------------
be = UAVChannelBackend(env="UMa", fc_ghz=3.5, n_prb=50, mu=1, seed=5)
rng = np.random.default_rng(3)
K = 10
users = np.column_stack([rng.uniform(100, 900, K), rng.uniform(100, 900, K),
                         np.full(K, 1.5)])
uav = np.array([500.0, 500.0, 60.0])
be.reset(uav, users)
rows = []
climb = np.linspace(60, be.altitude_prior(400.0), 400)
for i in range(1200):
    uav[2] = climb[i] if i < 400 else climb[-1]
    users[:, 0] += rng.normal(0.003, 0.001, K)
    users[:, 1] += rng.normal(0.0, 0.001, K)
    o = be.step(uav, users, 1e-3)
    rows.append([i, uav[2], float(o["gain_db"].mean()),
                 float(o["gain_db"].min()),
                 float(10 * np.log10(o["gains_prb"][0].mean())),
                 float(o["plos"].mean()), int(o["state"].sum())])
with open(os.path.join(OUT, "demo_episode.csv"), "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["tti", "h_uav", "gain_mean_db", "gain_min_db",
                "user0_prbmean_db", "plos_mean", "n_los"])
    w.writerows(rows)
print(f"demo_episode.csv: {len(rows)} TTIs (climb to "
      f"h*={be.altitude_prior(400.0):.1f} m prior)")

# ---- 3. schema + manifest ---------------------------------------------------
def sha(rel):
    return hashlib.sha256(open(os.path.join(ROOT, rel), "rb").read()
                          ).hexdigest()

artifacts = ["stage2/out/lookup_core.csv", "stage2/out/lookup_dense.npz",
             "stage2/out/hstar_map.csv", "stage2/out/sf_maps.npz",
             "stage3/out3/fr2_delta_pl.csv", "stage3/out3/fr2_hstar_shift.csv",
             "stage3/out3/coherence_time.csv",
             "stage3/out3/coherence_bandwidth.csv"]
schema = dict(
    api_version=API_VERSION,
    frozen="2026-07-31",
    provenance=dict(
        sources=["3GPP TR 36.777 V15.0.0 Annex B",
                 "3GPP TR 38.901 V19.4.0 (ETSI TR 138 901)"],
        stage1_doc="ch3_stage1_channel_model.tex/pdf",
        code=["stage2/uav_channel v0.1.0", "stage4/drl_iface v1.0.0"]),
    grids=dict(outline=P.OUTLINE_GRID,
               dense=dict(h_step_m=2.5, r_step_m=10.0,
                          r_range_m=[20, 1000])),
    lookup_columns=COLUMNS,
    feature_vector=list(FEATURE_NAMES),
    step_output=["plos[K]", "state[K]", "pl_db[K]", "sf_db[K]", "gain_db[K]",
                 "gains_prb[K,B] (linear, = |h_bar_kb|^2 of the Ch.4 MDP)",
                 "fast_prb[K,B] (unit-mean)", "features[K,F]", "d2d[K]"],
    prb_bandwidth_hz={f"mu{m}": prb_bandwidth_hz(m) for m in (0, 1, 2)},
    assumptions=["T1 role swap", "A2 h_G=1.5 m", "A3 rooftop 20 m",
                 "A4 aerial-band operation", "D2 3-D SF extension",
                 "D3 V19.4.0 vintage", "D4 azimuth-spread floor",
                 "A5 GM cluster fading (J0 innovation, per-cluster Doppler)",
                 "A6 SF modes: 'map' (inter-user correlated, sigma(h) only "
                 "for UAV motion) / 'ar' (per-link, summed displacement)"],
    open_flags=dict(V1="UMi Alt-2 source", V2="rooftop default",
                    V4="Sionna cross-check (local run)",
                    V5="QuaDRiGa campaign (local run)",
                    E1="FR2 NLoS bracket -23..-2 dB; h* shift <= 14.4 m"),
    jump_handling=("P_LoS discontinuity at h_sat kept verbatim; DRL loaders "
                   "may smooth over h_sat +/- eps (Remark 2.1)"),
    artifact_sha256={a: sha(a) for a in artifacts},
)
json.dump(schema, open(os.path.join(os.path.dirname(__file__), "..",
                                    "schema.json"), "w"), indent=1)
print("schema.json written (api", API_VERSION + ", "
      + str(len(artifacts)), "artifacts hashed)")
