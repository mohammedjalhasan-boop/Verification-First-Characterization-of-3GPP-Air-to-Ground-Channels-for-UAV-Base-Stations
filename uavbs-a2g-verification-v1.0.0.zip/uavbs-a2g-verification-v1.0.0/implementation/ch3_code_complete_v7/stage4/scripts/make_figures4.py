"""Stage-4 figures: demo episode trace + fading-physics closures."""
import csv
import os
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from drl_iface import rayleigh_reference
import uav_channel as uc
from scipy.special import j0

OUT = os.path.join(os.path.dirname(__file__), "..", "out4", "figures")
os.makedirs(OUT, exist_ok=True)
S1, S2, S3 = "#2a78d6", "#eb6834", "#1baf7a"
SURFACE, INK, INK2, MUTED = "#fcfcfb", "#0b0b0b", "#52514e", "#898781"
GRID, BASE = "#e1e0d9", "#c3c2b7"
plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE,
    "savefig.facecolor": SURFACE, "font.family": "DejaVu Sans",
    "axes.edgecolor": BASE, "axes.labelcolor": INK2, "axes.linewidth": 1.0,
    "xtick.color": MUTED, "ytick.color": MUTED, "xtick.labelsize": 9,
    "ytick.labelsize": 9, "axes.titlesize": 10.5, "axes.titlecolor": INK,
    "axes.labelsize": 9.5, "grid.color": GRID, "grid.linewidth": 0.8,
    "legend.frameon": False, "legend.fontsize": 9, "lines.linewidth": 2.0})


def style(ax):
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(True, alpha=0.9)
    ax.set_axisbelow(True)


rows = list(csv.DictReader(open(os.path.join(OUT, "..",
                                             "demo_episode.csv"))))
t = np.array([float(r["tti"]) for r in rows])
h = np.array([float(r["h_uav"]) for r in rows])
gm = np.array([float(r["gain_mean_db"]) for r in rows])
gmin = np.array([float(r["gain_min_db"]) for r in rows])
nlos = np.array([float(r["n_los"]) for r in rows])

fig, axes = plt.subplots(3, 1, figsize=(8.4, 6.6), sharex=True)
axes[0].plot(t, h, color=S1)
axes[0].set_ylabel("UAV altitude [m]")
axes[0].set_title("Demo episode: climb to the h* prior (UMa-AV, 3.5 GHz, "
                  "K=10, 1 ms TTI)")
axes[1].plot(t, gm, color=S1, label="mean over users")
axes[1].plot(t, gmin, color=S2, label="worst user")
axes[1].set_ylabel("large-scale gain [dB]")
axes[1].legend(loc="lower right")
axes[2].plot(t, nlos, color=S3)
axes[2].set_ylabel("# users in LoS")
axes[2].set_xlabel("TTI")
for ax in axes:
    style(ax)
fig.tight_layout()
fig.savefig(os.path.join(OUT, "b1_episode.png"), dpi=150,
            bbox_inches="tight")

# b2: temporal ACF vs Clarke reference + PRB frequency correlation ------------
fig, axes = plt.subplots(1, 2, figsize=(10.4, 3.7))
fc, v = 3.5, 20.0
fd = uc.fd_max(v, fc)
tr = rayleigh_reference(fc, [0.0], v, rng=2)
dt = 1e-4
n = 60000
hh = np.array([tr.step(dt)[0] for _ in range(n)])
hh -= hh.mean()
ac = np.correlate(hh, hh, "full")[n - 1:]
ac = np.abs(ac / ac[0])
lag = np.arange(800) * dt * 1e3
axes[0].plot(lag, ac[:800], color=S1, label="tracker (measured)")
axes[0].plot(lag, np.abs(j0(2 * np.pi * fd * lag / 1e3)), color=S2, lw=1.4,
             label="Clarke $|J_0(2\\pi f_D\\tau)|$")
axes[0].axhline(0.5, color=MUTED, lw=1.0, ls=":")
style(axes[0])
axes[0].set_xlabel("lag $\\tau$ [ms]")
axes[0].set_ylabel("$|\\rho(\\tau)|$")
axes[0].set_title(f"Temporal ACF, Rayleigh ref., $f_D$={fd:.0f} Hz")
axes[0].legend(loc="upper right")

f = np.arange(0, 20e6, 200e3)
tr = rayleigh_reference(3.5, f, 5.0, ds_s=100e-9, rng=3)
hs = np.stack([tr.step(1e-3) for _ in range(4000)])
h0 = hs[:, 0] - hs[:, 0].mean()
c = [abs(np.vdot(h0, hs[:, b] - hs[:, b].mean()))
     / (np.linalg.norm(h0) * np.linalg.norm(hs[:, b] - hs[:, b].mean()))
     for b in range(hs.shape[1])]
axes[1].plot(f / 1e6, c, color=S1)
bc = 1 / (2 * np.pi * 100e-9) / 1e6
axes[1].axvline(bc, color=MUTED, lw=1.0, ls=":")
axes[1].text(bc + 0.3, 0.92, f"$B_c$ = {bc:.1f} MHz", color=INK2, fontsize=8.5)
style(axes[1])
axes[1].set_xlabel("frequency separation [MHz]")
axes[1].set_ylabel("$|\\rho(\\Delta f)|$")
axes[1].set_title("PRB frequency correlation, DS = 100 ns")
fig.tight_layout()
fig.savefig(os.path.join(OUT, "b2_fading_closures.png"), dpi=150,
            bbox_inches="tight")
print("figures written to", OUT)
