"""Stage-4 tests: contract determinism, physics closures, parity, schema."""
import json
import math
import os
import sys
import unittest
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from drl_iface import (UAVChannelBackend, FadingTracker, rayleigh_reference,
                       FEATURE_NAMES, prb_bandwidth_hz, API_VERSION)  # noqa
import uav_channel as uc                                              # noqa


def make_env(seed=0, **kw):
    be = UAVChannelBackend(env="UMa", fc_ghz=3.5, n_prb=50, mu=1, seed=seed,
                           **kw)
    rng = np.random.default_rng(42)
    users = np.column_stack([rng.uniform(50, 900, 10),
                             rng.uniform(50, 900, 10),
                             np.full(10, 1.5)])
    obs = be.reset(np.array([500.0, 500.0, 100.0]), users)
    return be, users, obs


class TestContract(unittest.TestCase):
    def test_shapes_and_names(self):
        be, users, obs = make_env()
        self.assertEqual(obs["gains_prb"].shape, (10, 50))
        self.assertEqual(obs["features"].shape, (10, len(FEATURE_NAMES)))
        self.assertEqual(prb_bandwidth_hz(1), 360e3)
        self.assertEqual(API_VERSION, "1.0.0")

    def test_determinism(self):
        outs = []
        for _ in range(2):
            be, users, obs = make_env(seed=7)
            o2 = be.step(np.array([505.0, 500.0, 102.0]), users, 1e-3)
            outs.append((obs["gains_prb"], o2["gains_prb"], o2["sf_db"]))
        for a, b in zip(outs[0], outs[1]):
            np.testing.assert_array_equal(a, b)

    def test_large_scale_matches_package(self):
        be, users, obs = make_env(seed=3)
        d2d = np.hypot(users[:, 0] - 500.0, users[:, 1] - 500.0)
        for k in range(10):
            st = "LOS" if obs["state"][k] else "NLOS"
            self.assertAlmostEqual(
                obs["pl_db"][k],
                float(uc.path_loss("UMa", d2d[k], 100.0, 3.5, st)), places=9)
        np.testing.assert_allclose(obs["plos"],
                                   uc.plos("UMa", d2d, 100.0), rtol=1e-12)

    def test_unit_mean_fast_fading(self):
        be, users, obs = make_env(seed=1)
        acc = np.zeros((10, 50))
        n = 3000
        for _ in range(n):
            o = be.step(np.array([500.0, 500.0, 100.0]), users, 1e-3)
            acc += o["fast_prb"]
        m = acc / n
        # LoS-dominant Ricean links fluctuate little; overall mean ~ 1
        self.assertLess(abs(float(m.mean()) - 1.0), 0.1)

    def test_altitude_prior(self):
        be, _, _ = make_env()
        self.assertAlmostEqual(be.altitude_prior(200.0), 90.5, delta=0.2)


class TestFadingPhysics(unittest.TestCase):
    def test_coherence_time_closure(self):
        fc, v = 3.5, 20.0
        fd = uc.fd_max(v, fc)
        tr = rayleigh_reference(fc, [0.0], v, rng=2)
        dt = 1e-4
        n = 60000
        h = np.empty(n, complex)
        for i in range(n):
            h[i] = tr.step(dt)[0]
        h -= h.mean()
        ac = np.correlate(h, h, "full")[n - 1:]
        ac = np.abs(ac / ac[0])
        k50 = int(np.argmax(ac < 0.5))
        tc_meas = k50 * dt
        tc_ref = 0.423 / fd
        self.assertTrue(0.4 * tc_ref < tc_meas < 2.5 * tc_ref,
                        msg=f"tc_meas={tc_meas*1e3:.3f} ms vs "
                            f"ref {tc_ref*1e3:.3f} ms")

    def test_frequency_selectivity(self):
        # DS=100 ns reference: correlation must decay across ~Bc=1.6 MHz
        f = np.arange(0, 20e6, 200e3)
        tr = rayleigh_reference(3.5, f, 5.0, ds_s=100e-9, rng=3)
        hs = np.stack([tr.step(1e-3) for _ in range(4000)])
        h0 = hs[:, 0] - hs[:, 0].mean()
        c = []
        for b in range(hs.shape[1]):
            hb = hs[:, b] - hs[:, b].mean()
            c.append(abs(np.vdot(h0, hb)) /
                     (np.linalg.norm(h0) * np.linalg.norm(hb)))
        c = np.asarray(c)
        self.assertGreater(c[1], 0.9)          # 200 kHz apart: coherent
        self.assertLess(min(c[40:]), 0.5)      # >=8 MHz apart: decorrelated
        self.assertLess(c[40:].mean(), c[:10].mean())

    def test_ricean_k20_low_variance(self):
        cdl = uc.alt1_cdl("UMa", 300.0, 100.0, "LOS",
                          dict(aod=0, aoa=-180, zod=100, zoa=80))
        tr = FadingTracker(cdl, 3.5, [0.0], v_rx=uc.velocity_vec(3.0, 45.0),
                           rng=4)
        g = np.array([tr.gains(1e-3)[0] for _ in range(8000)])
        self.assertLess(float(g.var()), 0.05)   # K=20 dB: nearly static amp
        # aerial diffuse rays decorrelate over seconds (sub-degree spreads),
        # so unit-mean must be checked over an ENSEMBLE, not one trajectory:
        ens = [FadingTracker(cdl, 3.5, [0.0],
                             v_rx=uc.velocity_vec(3.0, 45.0),
                             rng=1000 + i).gains(1e-3)[0] for i in range(400)]
        self.assertAlmostEqual(float(np.mean(ens)), 1.0, delta=0.04)

    def test_specular_rotation_rate(self):
        cdl = uc.scale_k(uc.params.CDL_D, 40.0)     # essentially pure LoS
        v = uc.velocity_vec(20.0, 0.0)
        tr = FadingTracker(cdl, 3.5, [0.0], v_rx=v, rng=5)
        lam = 3e8 / 3.5e9
        from uav_channel.small_scale import unit_vec
        nu_exp = float(unit_vec(-180.0, 81.5) @ v) / lam
        dt = 1e-4
        h = np.array([tr.step(dt)[0] for _ in range(2000)])
        ph = np.unwrap(np.angle(h))
        nu_meas = (ph[-1] - ph[0]) / (2 * np.pi * dt * (len(h) - 1))
        self.assertAlmostEqual(nu_meas, nu_exp, delta=abs(nu_exp) * 0.02 + 1.0)


class TestParityAndModes(unittest.TestCase):
    def test_table_parity(self):
        be_d, users, _ = make_env(seed=9, table_mode=False)
        be_t, _, _ = make_env(seed=9, table_mode=True)
        rng = np.random.default_rng(0)
        errs = []
        for _ in range(200):
            r = float(rng.uniform(25, 1400))
            h = float(rng.uniform(24, 299))
            for st in (True, False):
                errs.append(abs(be_d._pl(r, h, st) - be_t._pl(r, h, st)))
        self.assertLess(max(errs), 0.05)

    def test_ar_mode_runs_and_scales(self):
        be, users, obs = make_env(seed=11, sf_mode="ar")
        o = be.step(np.array([500.0, 500.0, 100.0]), users, 1e-3)
        sig = o["features"][:, FEATURE_NAMES.index("sigma_db")]
        self.assertTrue(np.all(np.abs(o["sf_db"]) < 6 * sig + 1e-9))


class TestSchema(unittest.TestCase):
    def test_schema_manifest(self):
        p = os.path.join(os.path.dirname(__file__), "..", "schema.json")
        if not os.path.exists(p):
            self.skipTest("schema.json not yet generated (run_stage4.py)")
        s = json.load(open(p))
        self.assertEqual(s["api_version"], API_VERSION)
        import hashlib
        for rel, want in s["artifact_sha256"].items():
            path = os.path.join(os.path.dirname(__file__), "..", "..", rel)
            self.assertTrue(os.path.exists(path), rel)
            got = hashlib.sha256(open(path, "rb").read()).hexdigest()
            self.assertEqual(got, want, rel)


if __name__ == "__main__":
    unittest.main(verbosity=2)
