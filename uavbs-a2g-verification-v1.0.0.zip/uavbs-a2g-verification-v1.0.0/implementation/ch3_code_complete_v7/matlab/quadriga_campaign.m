% QuaDRiGa external-validation campaign for Chapter 3 (flag V5).
% =========================================================================
% STATUS: API-ADJUSTED FOR QuaDRiGa v2.8.1-0 (MATLAB R2026a), 2026-08-08.
% Changes vs. the delivered-unexecuted version (record in project log):
%   * LOS state read from the builder's assigned scenario NAME
%     (contains '_LOS'), since qd_builder has no 'los' property.
%   * Ricean K read from builder property 'kf' (lowercase), not 'KF'.
%   * Channels generated from the SAME builder that drew the LSPs
%     (bl.get_channels), so exported SF/DS/KF/angles correspond to the
%     realization, instead of l.get_channels re-initializing internally.
%   * Progress bars disabled inside the loop (9000-iteration runtime).
%
% Requires: QuaDRiGa >= 2.8 (MATLAB), https://quadriga-channel-model.de
%
% What it does
%   For each environment config, carrier, altitude and range cell, it drops
%   N_SEED independent links between a ground node (1.5 m) and an aerial
%   node, generates large-scale + small-scale parameters, and appends one
%   CSV row per link:
%     env,fc_ghz,h_m,d2d_m,seed,los,pl_db,sf_db,ds_ns,asd_deg,asa_deg,
%     zsd_deg,zsa_deg,kf_db
%   The Python comparator (ingest_quadriga.py) then tests the Stage-2 model
%   against these samples (P_LoS, PL bias, sigma_SF, DS/AS vs Alt-2).
% =========================================================================

clear all; close all;

OUT_CSV   = 'quadriga_samples.csv';
N_SEED    = 50;                          % links per (env,fc,h,r) cell
FC_LIST   = [2.6e9, 3.5e9];              % 28e9 optional (runtime!)
H_LIST    = [30 50 100 150 200 300];     % UAV altitudes [m]
R_LIST    = [50 100 200 500 1000];       % ground ranges [m]
H_GROUND  = 1.5;

% ---- scenario configs ---------------------------------------------------
% Confirmed present in QuaDRiGa 2.8.1 config folder (2026-08-08 inspection):
%   3GPP_38.901_{UMa,UMi,RMa}_{LOS,NLOS}.conf  -- terrestrial anchors.
% No aerial (TR 36.777 / *_AV) configs ship with 2.8.1, so this campaign
% validates the TERRESTRIAL anchors and the geometry pipeline, while the
% aerial-band comparison relies on the LOS/NLOS split exported here plus
% the comparator's TR 36.777 references (see kit README / Section 3.10).
SCEN = struct('UMa','3GPP_38.901_UMa', ...
              'UMi','3GPP_38.901_UMi', ...
              'RMa','3GPP_38.901_RMa');

fid = fopen(OUT_CSV,'w');
fprintf(fid, ['env,fc_ghz,h_m,d2d_m,seed,los,pl_db,sf_db,ds_ns,' ...
              'asd_deg,asa_deg,zsd_deg,zsa_deg,kf_db\n']);

envs = fieldnames(SCEN);
for ie = 1:numel(envs)
  env = envs{ie};
  for fc = FC_LIST
    for h = H_LIST
      for r = R_LIST
        for seed = 1:N_SEED
          s = qd_simulation_parameters;
          s.center_frequency = fc;
          s.use_random_initial_phase = true;
          s.show_progress_bars = 0;                % quiet inside the loop
          rng(seed);                               % reproducibility

          l = qd_layout(s);
          l.no_tx = 1;
          % Role swap (Stage-1 Assumption T1): aerial node is the "UT" side
          % of the 3GPP model. Place BS anchor per scenario ground node:
          l.tx_position = [0; 0; H_GROUND];   % ground UE side (see report)
          l.no_rx = 1;
          l.rx_position = [r; 0; h];          % UAV
          l.set_scenario(SCEN.(env));         % draws LOS/NLOS per 38.901

          b  = l.init_builder;                % builder array (1 scenario here)
          bl = b(1,1);
          bl.gen_parameters;                  % draw LSPs: SF, DS, KF, angles
          c  = bl.get_channels;               %#ok<NASGU> coeffs, same builder

          % ---- extract quantities (QuaDRiGa 2.8.1 API) ------------------
          los    = contains(bl.scenario, '_LOS');   % from assigned scenario
          pl_db  = bl.get_pl;                 % path loss w/o SF [dB]
          sf_db  = 10*log10(bl.sf);           % shadow fading [dB]
          ds_ns  = bl.ds * 1e9;               % rms delay spread [ns]
          asd    = bl.asD; asa = bl.asA;      % azimuth spreads [deg]
          zsd    = bl.esD; zsa = bl.esA;      % elevation spreads [deg]
          kf_db  = 10*log10(bl.kf);           % Ricean K [dB]

          fprintf(fid, '%s,%.3g,%g,%g,%d,%d,%.3f,%.3f,%.3f,%.4g,%.4g,%.4g,%.4g,%.3f\n', ...
                  env, fc/1e9, h, r, seed, los, pl_db, sf_db, ds_ns, ...
                  asd, asa, zsd, zsa, kf_db);
        end
      end
    end
    fprintf('done %s @ %.1f GHz\n', env, fc/1e9);
  end
end
fclose(fid);
fprintf('wrote %s\n', OUT_CSV);
