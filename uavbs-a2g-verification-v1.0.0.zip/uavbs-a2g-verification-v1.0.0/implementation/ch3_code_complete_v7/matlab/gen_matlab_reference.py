"""Export reference vectors from the frozen Python package for MATLAB parity.

Every value in matlab_reference.csv / matlab_reference_hstar.csv is produced
by the verified uav_channel package; parity_check.m recomputes them with the
MATLAB port (uav_channel_core.m) and must agree to the stated tolerances
before the port is used for any analysis.

Run from this folder:   python gen_matlab_reference.py
(The Python package is found automatically at ../stage2.)
"""
import csv, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'stage2'))
import uav_channel as uc                                  # noqa: E402
from uav_channel.altitude import h_star                   # noqa: E402

ENVS = ('UMa', 'UMi', 'RMa')
FCS = (2.6, 3.5, 28.0)
HS = (23.0, 30.0, 50.0, 75.0, 100.0, 150.0, 200.0, 250.0, 300.0)
RS = (15.0, 50.0, 100.0, 200.0, 500.0, 800.0, 1000.0)   # 15 m hits the d1 branch

p1 = os.path.join(HERE, 'matlab_reference.csv')
with open(p1, 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['env', 'fc_ghz', 'h_m', 'd2d_m', 'plos', 'pl_los_db',
                'pl_nlos_db', 'sf_los_db', 'sf_nlos_db',
                'pcov_110', 'pcov_120', 'hwall_m'])
    n = 0
    for env in ENVS:
        for fc in FCS:
            for h in HS:
                for r in RS:
                    w.writerow([env, fc, h, r,
                                f"{uc.plos_aerial(env, r, h):.12g}",
                                f"{uc.pl_los_aerial(env, r, h, fc):.12g}",
                                f"{uc.pl_nlos_aerial(env, r, h, fc):.12g}",
                                f"{uc.sf_std_aerial(env, h, 'LOS'):.12g}",
                                f"{uc.sf_std_aerial(env, h, 'NLOS'):.12g}",
                                f"{uc.p_cov(env, r, h, fc, 110.0):.12g}",
                                f"{uc.p_cov(env, r, h, fc, 120.0):.12g}",
                                f"{uc.h_wall(env, r):.12g}"])
                    n += 1
print(f"wrote {p1}  ({n} rows)")

p2 = os.path.join(HERE, 'matlab_reference_hstar.csv')
with open(p2, 'w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['env', 'fc_ghz', 'd2d_m', 'lmax_db', 'h_star', 'p_max',
                'regime', 'h_plateau_lo', 'n_modes'])
    n = 0
    for env in ENVS:
        for fc in FCS:
            for r in (100.0, 500.0, 1000.0):
                for lm in (110.0, 115.0, 120.0):
                    s = h_star(env, r, fc, lm)      # grid solver (as ported)
                    w.writerow([env, fc, r, lm, f"{s['h_star']:.6f}",
                                f"{s['p_max']:.10g}", s['regime'],
                                f"{s['h_plateau_lo']:.6f}", s['n_modes']])
                    n += 1
print(f"wrote {p2}  ({n} rows)")
