%DEMO_DEPLOYMENT  Reproduce the chapter's headline numbers in MATLAB.
%
%   Run AFTER parity_check reports PASS:
%       >> demo_deployment
%
%   Each printed line states the expected value from the dissertation so a
%   committee member (or you, on a new machine) can confirm at a glance.

C = uav_channel_core();

fprintf('=== Chapter 3 headline numbers, recomputed in MATLAB ===\n\n');

% 1. LoS walls at r = 500 m (closed form, Eq. 32 family)
fprintf('LoS wall h1(500 m):  UMa %6.1f m   (expected 100.0 -- cap)\n', ...
        C.h_wall('UMa', 500));
fprintf('                     UMi %6.1f m   (expected 300.0 -- cap)\n', ...
        C.h_wall('UMi', 500));
fprintf('                     RMa %6.1f m   (expected   36.0)\n', ...
        C.h_wall('RMa', 500));
fprintf('LoS wall h1(200 m):  UMi %6.1f m   (expected  142.1 -- analytic branch)\n\n', ...
        C.h_wall('UMi', 200));

% 2. Sub-6 plateau cell: UMa, 2.6 GHz, 120 dB, r = 500 m
S = C.h_star('UMa', 500, 2.6, 120);
fprintf(['UMa 2.6 GHz 120 dB r=500: regime %-8s  energy-preferred h* = ', ...
         '%5.1f m  (expected: plateau, 100.0 m)\n'], S.regime, S.h_plateau_lo);

% 3. FR2 bimodal cell: UMa, 28 GHz, 115 dB, r = 500 m
S = C.h_star('UMa', 500, 28, 115);
fprintf(['UMa 28 GHz 115 dB r=500:  regime %-8s  h* = %5.1f m, ', ...
         'P_cov = %.3f, modes = %d  (expected: interior, 43.9 m, 0.304, 5)\n'], ...
        S.regime, S.h_star, S.p_max, S.n_modes);

% 4. Shadowing hardening: sigma_LoS collapse with altitude (UMa)
fprintf(['\nsigma_LoS UMa:  30 m -> %.2f dB,  300 m -> %.2f dB   ', ...
         '(expected 3.81 -> 0.64: exponential hardening)\n'], ...
        C.sf_std_aerial('UMa', 30, 'LOS'), C.sf_std_aerial('UMa', 300, 'LOS'));

% 5. Coverage mixture at one auditable point
fprintf(['P_cov(UMa, r=500, h=100, 3.5 GHz, 120 dB) = %.4f   ', ...
         '(expected 0.9942)\n'], ...
        C.p_cov('UMa', 500, 100, 3.5, 120));
