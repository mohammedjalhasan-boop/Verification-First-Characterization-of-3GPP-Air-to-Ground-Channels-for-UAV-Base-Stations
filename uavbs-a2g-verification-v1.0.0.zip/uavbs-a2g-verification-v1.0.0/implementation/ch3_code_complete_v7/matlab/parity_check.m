%PARITY_CHECK  Gate for the MATLAB port: compare against the Python package.
%
%   Run this ONCE, before using uav_channel_core in any analysis:
%
%       >> parity_check
%
%   It loads the reference vectors exported by the verified Python package
%   (gen_matlab_reference.py) and recomputes every quantity with the MATLAB
%   port. Expected result: every block prints PASS, elementwise errors at
%   the 1e-12..1e-9 level (pure floating-point noise). Any FAIL means the
%   port must not be used until the discrepancy is resolved.
%
%   Tolerances (and why):
%     plos, PL, sigma, P_cov, h_wall : 1e-9   (same closed forms, both IEEE
%                                              doubles; only rounding noise)
%     h_star (non-plateau)           : 0.06 m (one 0.05-m grid step: the two
%                                              languages build the grid with
%                                              different float accumulation)
%     h_plateau_lo, p_max            : 0.06 m / 2e-4 (plateau threshold form)
%     regime                         : exact string match
%     n_modes                        : reported, not enforced (sign counting
%                                      on flat plateaus is float-noise bound)

C = uav_channel_core();
here = fileparts(mfilename('fullpath'));

% ---------------- block 1: elementwise functions --------------------------
T = readtable(fullfile(here, 'matlab_reference.csv'));
n = height(T);
e = struct('plos',0,'pll',0,'pln',0,'sfl',0,'sfn',0,'p110',0,'p120',0,'hw',0);
for i = 1:n
    env = T.env{i}; fc = T.fc_ghz(i); h = T.h_m(i); r = T.d2d_m(i);
    e.plos = max(e.plos, abs(C.plos_aerial(env,r,h)        - T.plos(i)));
    e.pll  = max(e.pll,  abs(C.pl_los_aerial(env,r,h,fc)   - T.pl_los_db(i)));
    e.pln  = max(e.pln,  abs(C.pl_nlos_aerial(env,r,h,fc)  - T.pl_nlos_db(i)));
    e.sfl  = max(e.sfl,  abs(C.sf_std_aerial(env,h,'LOS')  - T.sf_los_db(i)));
    e.sfn  = max(e.sfn,  abs(C.sf_std_aerial(env,h,'NLOS') - T.sf_nlos_db(i)));
    e.p110 = max(e.p110, abs(C.p_cov(env,r,h,fc,110)       - T.pcov_110(i)));
    e.p120 = max(e.p120, abs(C.p_cov(env,r,h,fc,120)       - T.pcov_120(i)));
    e.hw   = max(e.hw,   abs(C.h_wall(env,r)               - T.hwall_m(i)));
end
tol = 1e-9;
fn = fieldnames(e); ok1 = true;
fprintf('Block 1 -- elementwise parity over %d reference rows:\n', n);
lbl = struct('plos','P_LoS','pll','PL_LoS','pln','PL_NLoS','sfl','sigma_LoS', ...
             'sfn','sigma_NLoS','p110','P_cov(110)','p120','P_cov(120)','hw','h_wall');
for k = 1:numel(fn)
    v = e.(fn{k}); s = 'PASS'; if v > tol, s = 'FAIL'; ok1 = false; end
    fprintf('  %-12s max|err| = %.3e   [%s]\n', lbl.(fn{k}), v, s);
end

% ---------------- block 2: optimum solver ---------------------------------
S = readtable(fullfile(here, 'matlab_reference_hstar.csv'));
m = height(S); ok2 = true; bad = 0;
ehs = 0; epl = 0; epm = 0;
for i = 1:m
    res = C.h_star(S.env{i}, S.d2d_m(i), S.fc_ghz(i), S.lmax_db(i));
    reg_ok = strcmp(res.regime, S.regime{i});
    if strcmp(S.regime{i}, 'plateau')
        hs_ok = abs(res.h_plateau_lo - S.h_plateau_lo(i)) <= 0.06;
        epl = max(epl, abs(res.h_plateau_lo - S.h_plateau_lo(i)));
    else
        hs_ok = abs(res.h_star - S.h_star(i)) <= 0.06;
        ehs = max(ehs, abs(res.h_star - S.h_star(i)));
    end
    pm_ok = abs(res.p_max - S.p_max(i)) <= 2e-4;
    epm = max(epm, abs(res.p_max - S.p_max(i)));
    if ~(reg_ok && hs_ok && pm_ok)
        bad = bad + 1; ok2 = false;
        fprintf(['  MISMATCH %s fc=%.1f r=%.0f L=%.0f: regime %s/%s, ', ...
                 'h*=%.2f/%.2f, pmax=%.4f/%.4f\n'], S.env{i}, S.fc_ghz(i), ...
                S.d2d_m(i), S.lmax_db(i), res.regime, S.regime{i}, ...
                res.h_star, S.h_star(i), res.p_max, S.p_max(i));
    end
end
fprintf(['Block 2 -- h_star parity over %d cells: %d mismatches; ', ...
         'max|dh*|=%.3f m, max|dh_plateau|=%.3f m, max|dp|=%.2e  [%s]\n'], ...
        m, bad, ehs, epl, epm, ternary(ok2, 'PASS', 'FAIL'));

% ---------------- verdict --------------------------------------------------
if ok1 && ok2
    fprintf(['\nPARITY PASS -- the MATLAB port agrees with the verified ', ...
             'Python package.\nYou may now use uav_channel_core for ', ...
             'analysis on this machine.\n']);
else
    fprintf(['\nPARITY FAIL -- do NOT use the port. Re-export the ', ...
             'reference CSVs and re-run; if it still fails, report the ', ...
             'lines above.\n']);
end

function s = ternary(c, a, b)
if c, s = a; else, s = b; end
end
