# MATLAB side of the Chapter-3 code pack

Two independent things live here. **Neither requires the other.**

## A. The MATLAB port of the verified channel core

| file | role |
|---|---|
| `uav_channel_core.m` | line-by-line MATLAB transcription of the frozen Python package (P_LoS, path loss, shadowing, coverage mixture, LoS wall, h* solver) |
| `gen_matlab_reference.py` | exports reference vectors **from the Python package** (already run; CSVs included) |
| `matlab_reference.csv` | 567 elementwise reference rows |
| `matlab_reference_hstar.csv` | 81 optimum-solver reference cells |
| `parity_check.m` | **the gate**: recomputes everything with the port and compares |
| `demo_deployment.m` | reproduces the chapter's headline numbers with expected values printed |

Order of operations (MATLAB R2020b or newer; no toolboxes needed):

```matlab
cd <this folder>
parity_check        % must print PARITY PASS (elementwise errors ~1e-12..1e-9)
demo_deployment     % headline numbers with expected values
C = uav_channel_core();          % then use it
C.p_cov('UMa', 500, 100, 3.5, 120)
```

Trust model: the port is **not** trusted until `parity_check` passes on your
machine. The transcription was additionally audited in the build environment
by re-executing the .m formulas against the package on all 567 rows
(max error 5e-10, i.e. CSV rounding only) — but MATLAB itself must confirm.

## B. The QuaDRiGa external cross-validation campaign (executed Aug 2026)

`quadriga_campaign.m` is the **API-fixed, executed** version (QuaDRiGa
v2.8.1-0, MATLAB R2026a). It writes `quadriga_samples.csv` (9,000 links);
the comparator `../stage3/quadriga_kit/ingest_quadriga.py` then produces the
cell report. The executed run's report ships as
`../stage3/quadriga_kit/report_executed_2026-08.csv`.

Requirements: QuaDRiGa >= 2.8 on the MATLAB path. Persistent path setup on
Windows (avoids the `savepath`/`pathdef.m` permission trap):

```matlab
up = userpath; fid = fopen(fullfile(up,'startup.m'),'a');
fprintf(fid, 'addpath(''C:\\QuaDRiGa\\quadriga_src'');\n'); fclose(fid);
```

Full instructions, expected output, and the troubleshooting table (every
error actually encountered during the executed run, with its fix) are in the
Implementation Guide PDF at the pack root.
