function C = uav_channel_core()
%UAV_CHANNEL_CORE  MATLAB port of the dissertation's verified Stage-2 core.
%
%   C = uav_channel_core() returns a struct of function handles implementing
%   the large-scale aerial channel of Chapter 3 (3GPP TR 36.777 Annex B over
%   TR 38.901) and the optimal-altitude machinery:
%
%     C.plos_aerial(env, d2d, h)                 LoS probability (Table B-1)
%     C.pl_los_aerial(env, d2d, h, fc)           LoS path loss  [dB] (B-2)
%     C.pl_nlos_aerial(env, d2d, h, fc)          NLoS path loss [dB] (B-2)
%     C.sf_std_aerial(env, h, state)             shadowing sigma [dB] (B-3)
%     C.p_cov(env, d2d, h, fc, l_max)            coverage mixture probability
%     C.h_wall(env, d2d)                         closed-form LoS wall h1(r)
%     C.h_star(env, d2d, fc, l_max)              grid optimum + regime struct
%
%   env in {'UMa','UMi','RMa'}; state in {'LOS','NLOS'}; fc in GHz;
%   distances/heights in m; h may be a vector (elementwise, like the Python
%   package). Ground terminal height fixed at 1.5 m (Assumption A2).
%
%   PROVENANCE / TRUST MODEL. This file is a line-by-line transcription of
%   the frozen, 48-check-verified Python package uav_channel (params.py,
%   large_scale.py, altitude.py). It is NOT trusted until parity_check.m
%   passes on your machine: that script compares every function against
%   reference vectors exported from the Python package itself
%   (matlab_reference*.csv) and must report PASS on all blocks.
%
%   Usage:
%     C = uav_channel_core();
%     C.p_cov('UMa', 500, 100, 3.5, 120)       % -> 0.9999... (plateau cell)
%     S = C.h_star('UMa', 500, 28, 115)        % -> h_star 43.9 m, 'interior'

C.plos_aerial    = @plos_aerial;
C.pl_los_aerial  = @pl_los_aerial;
C.pl_nlos_aerial = @pl_nlos_aerial;
C.sf_std_aerial  = @sf_std_aerial;
C.p_cov          = @p_cov;
C.h_wall         = @h_wall;
C.h_star         = @h_star;
end

% ===================== constants (params.py, verbatim) =====================
function cfg = plos_cfg(env)
switch env
  case 'UMa', cfg = struct('ap',4300,  'bp',3800, 'p_floor',NaN, ...
                           'ad',460,   'bd',700,  'd_floor',18, ...
                           'h_sat',100, 'band',[22.5 300]);
  case 'UMi', cfg = struct('ap',233.98,'bp',0.95, 'p_floor',NaN, ...
                           'ad',294.05,'bd',432.94,'d_floor',18, ...
                           'h_sat',NaN, 'band',[22.5 300]);
  case 'RMa', cfg = struct('ap',15021, 'bp',16053,'p_floor',1000, ...
                           'ad',1350.8,'bd',1602, 'd_floor',18, ...
                           'h_sat',40,  'band',[10 300]);
  otherwise, error('unknown env %s', env);
end
end

function cfg = pl_cfg(env, state)
% A0, a, b, intercept kind ('fc'|'rma'), guard ('none'|'fspl'|'los'|'slope20')
key = [env '_' state];
switch key
  case 'UMa_LOS',  cfg = struct('A0',28.0, 'a',22.0, 'b',0.0, 'icpt','fc',  'guard','none');
  case 'UMa_NLOS', cfg = struct('A0',-17.5,'a',46.0, 'b',7.0, 'icpt','rma', 'guard','none');
  case 'UMi_LOS',  cfg = struct('A0',30.9, 'a',22.25,'b',0.5, 'icpt','fc',  'guard','fspl');
  case 'UMi_NLOS', cfg = struct('A0',32.4, 'a',43.2, 'b',7.6, 'icpt','fc',  'guard','los');
  case 'RMa_LOS',  cfg = struct('A0',0.0,  'a',23.9, 'b',1.8, 'icpt','rma', 'guard','slope20');
  case 'RMa_NLOS', cfg = struct('A0',-12.0,'a',35.0, 'b',5.3, 'icpt','rma', 'guard','los');
  otherwise, error('unknown env/state %s', key);
end
end

function cfg = sf_cfg(env)
switch env
  case 'UMa', cfg = struct('s0',4.64,'kappa',0.0066,'s_floor',NaN,'sig_nlos',6.0);
  case 'UMi', cfg = struct('s0',5.0, 'kappa',0.01,  's_floor',2.0,'sig_nlos',8.0);
  case 'RMa', cfg = struct('s0',4.2, 'kappa',0.0046,'s_floor',NaN,'sig_nlos',6.0);
  otherwise, error('unknown env %s', env);
end
end

% ===================== large_scale.py transcription ========================
function d = d3d(d2d, h)
d = hypot(d2d, h - 1.5);                         % H_G_DEFAULT = 1.5 m
end

function v = fspl(d, fc)
v = 20*log10(40*pi/3) + 20*log10(d) + 20*log10(fc);
end

function v = icpt(kind, fc)
if strcmp(kind, 'fc'), v = 20*log10(fc);
else,                  v = 20*log10(40*pi*fc/3);  % 'rma'
end
end

function p = plos_aerial(env, d2d, h)
cfg = plos_cfg(env);
lg = log10(h);
p1 = cfg.ap .* lg - cfg.bp;
if ~isnan(cfg.p_floor), p1 = max(p1, cfg.p_floor); end
d1 = max(cfg.ad .* lg - cfg.bd, cfg.d_floor);
p  = d1 ./ d2d + exp(-d2d ./ p1) .* (1 - d1 ./ d2d);
p(d2d <= d1) = 1;                                % inside d1: certain LoS
if ~isnan(cfg.h_sat), p(h > cfg.h_sat) = 1; end  % saturation altitude
end

function v = pl_affine(env, state, d2d, h, fc)
cfg = pl_cfg(env, state);
B = cfg.a - cfg.b .* log10(h);
if strcmp(cfg.guard, 'slope20'), B = max(B, 20); end   % RMa LoS slope floor
v = cfg.A0 + icpt(cfg.icpt, fc) + B .* log10(d3d(d2d, h));
end

function v = pl_los_aerial(env, d2d, h, fc)
v = pl_affine(env, 'LOS', d2d, h, fc);
if strcmp(pl_cfg(env,'LOS').guard, 'fspl')             % UMi: FSPL floor
  v = max(v, fspl(d3d(d2d, h), fc));
end
end

function v = pl_nlos_aerial(env, d2d, h, fc)
v = pl_affine(env, 'NLOS', d2d, h, fc);
if strcmp(pl_cfg(env,'NLOS').guard, 'los')             % UMi/RMa: LoS floor
  v = max(v, pl_los_aerial(env, d2d, h, fc));
end
% UMa-AV NLoS: no guard in TR 36.777 (verbatim) -- returned as-is.
end

function s = sf_std_aerial(env, h, state)
cfg = sf_cfg(env);
if strcmp(state, 'LOS')
  s = cfg.s0 .* exp(-cfg.kappa .* h);
  if ~isnan(cfg.s_floor), s = max(s, cfg.s_floor); end
else
  s = cfg.sig_nlos .* ones(size(h));
end
end

function q = qfunc(x)
q = 0.5 * erfc(x ./ sqrt(2));
end

function p = p_cov(env, d2d, h, fc, l_max)
pl  = plos_aerial(env, d2d, h);
u_l = (pl_los_aerial(env, d2d, h, fc)  - l_max) ./ sf_std_aerial(env, h, 'LOS');
u_n = (pl_nlos_aerial(env, d2d, h, fc) - l_max) ./ sf_std_aerial(env, h, 'NLOS');
p = pl .* qfunc(u_l) + (1 - pl) .* qfunc(u_n);
end

% ===================== altitude.py transcription ===========================
function hw = h_wall(env, d2d)
cfg = plos_cfg(env);
if isnan(cfg.h_sat), cap = cfg.band(2); else, cap = cfg.h_sat; end
hw = 10 .^ ((d2d + cfg.bd) ./ cfg.ad);
hw(d2d <= cfg.d_floor) = cfg.band(1);
hw = min(hw, cap);
end

function res = h_star(env, d2d, fc, l_max)
% Grid solver, step 0.05 m, identical thresholds to altitude.h_star.
step = 0.05; plateau_eps = 1e-4; plateau_span = 50.0;
cfg = plos_cfg(env); lo = cfg.band(1); hi = cfg.band(2);
hgrid = (lo + step):step:(hi - step/2);          % mirrors np.arange(lo+step, hi)
pc = p_cov(env, d2d, hgrid, fc, l_max);
[pmax, i] = max(pc);
hstar = hgrid(i);
near = pc >= pmax - plateau_eps;
hn = hgrid(near);
h_plateau_lo = hn(1);
span = hn(end) - hn(1);
d = diff(pc); s = sign(d); s(s == 0) = [];
n_modes = sum(s(2:end) ~= s(1:end-1));
hw = h_wall(env, d2d);
if pmax < 1e-3
  regime = 'none';
elseif span > plateau_span
  regime = 'plateau';
elseif abs(hstar - hw) < 2*step + 1e-9
  regime = 'wall';
elseif abs(hstar - (hi - step)) < 2*step
  regime = 'ceiling';
else
  regime = 'interior';
end
res = struct('h_star',hstar, 'p_max',pmax, 'regime',regime, ...
             'h_plateau_lo',h_plateau_lo, 'plateau_span',span, ...
             'n_modes',n_modes, 'h_wall',hw);
end
