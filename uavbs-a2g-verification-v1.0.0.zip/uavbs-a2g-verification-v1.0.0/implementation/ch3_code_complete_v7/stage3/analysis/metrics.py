"""Outline Sec. 3.3 performance metrics: coherence time / bandwidth and
angular power spectra, computed from the instantiated model.

Definitions (stated explicitly, cited in the report):
  * coherence time  T_c ~= 0.423 / f_D,max      (Clarke 50%-correlation rule)
  * coherence bandwidth B_c ~= 1 / (2*pi*DS_rms) (50%-correlation rule)
  * DS from Alt-1 desired values (10/30 ns) or Alt-2 median 10^mu_lgDS(h)
  * angular spread: 3GPP circular definition (uav_channel.ang_spread_deg)
"""
from __future__ import annotations
import numpy as np

from . import uav_channel as _pkg  # noqa: F401
import uav_channel as uc
from uav_channel import params as P


def coherence_time_s(speed_mps, fc_ghz):
    return 0.423 / uc.fd_max(speed_mps, fc_ghz)


def coherence_bw_hz(ds_s):
    return 1.0 / (2.0 * np.pi * np.asarray(ds_s, float))


def alt2_median_ds_s(env, state, h):
    mu, _ = uc.lsp_alt2(env, float(h), state)["lgDS"]
    return 10.0 ** mu


def coherence_table(speeds=(3.0, 10.0, 20.0, 30.0), fcs=P.FREQS_GHZ):
    rows = []
    for v in speeds:
        for fc in fcs:
            rows.append(dict(speed_mps=v, fc_ghz=fc,
                             fd_max_hz=uc.fd_max(v, fc),
                             tc_ms=coherence_time_s(v, fc) * 1e3))
    return rows


def bc_table(h_list=(30.0, 50.0, 100.0, 200.0, 300.0)):
    """Coherence bandwidth per env/state: Alt-1 desired DS and Alt-2 median."""
    rows = []
    for env in ("UMa", "RMa"):
        for state in ("LOS", "NLOS"):
            des = P.ALT1_DESIRED[(env, state)]["DS"] * 1e-9
            for h in h_list:
                lo, hi = P.AERIAL_PLOS[env]["band"]
                if not (lo < h <= hi):
                    continue
                ds2 = alt2_median_ds_s(env, state, h)
                rows.append(dict(env=env, state=state, h_m=h,
                                 ds_alt1_ns=des * 1e9,
                                 bc_alt1_mhz=coherence_bw_hz(des) / 1e6,
                                 ds_alt2_med_ns=ds2 * 1e9,
                                 bc_alt2_med_mhz=coherence_bw_hz(ds2) / 1e6))
    return rows


def alt1_pas(env, state, h, d2d, los_angles, dim="aoa"):
    """Discrete PAS (ray angles [deg], ray powers, linear) of the scaled Alt-1
    CDL-D at a drop, for angular-spectrum plots. LoS state only for CDL-D."""
    cdl = uc.alt1_cdl(env, d2d, h, state, los_angles)
    from uav_channel.small_scale import _cdl_arrays, _ray_angles
    _, p_db, ang = _cdl_arrays(cdl)
    c = {"aoa": cdl["c_asa"], "aod": cdl["c_asd"],
         "zoa": cdl["c_zsa"], "zod": cdl["c_zsd"]}[dim]
    rays = _ray_angles(ang[dim], c)
    p_lin = 10.0 ** (p_db / 10.0)
    ray_p = np.repeat(p_lin / rays.shape[1], rays.shape[1])
    rays = rays.reshape(-1)
    # specular cluster: single ray at exact angle
    ray_p[0:20] = 0.0
    rays_out = np.concatenate([[ang[dim][0]], rays])
    p_out = np.concatenate([[p_lin[0]], ray_p])
    return rays_out, p_out / p_out.sum()


def alt2_as_curves(env, state, h_grid, floor_deg=None):
    """Median angular spreads vs altitude from Tables B.1.2-1/2.

    floor_deg: optional physical-plausibility floor (decision D4 in the
    Stage-3 report); None = TR-verbatim.
    """
    out = {k: [] for k in ("ASA", "ASD", "ZSA", "ZSD")}
    for h in h_grid:
        st = uc.lsp_alt2(env, float(h), state)
        for k in out:
            v = 10.0 ** st["lg" + k][0]
            if floor_deg is not None:
                v = max(v, floor_deg)
            out[k].append(v)
    return {k: np.asarray(v) for k, v in out.items()}
