"""Statistical self-consistency validation (implementation-level).

Scope note (honest labelling): these checks validate that the *stochastic
machinery* of the Stage-2 package reproduces the *analytic* Stage-1 targets
(mixture CDFs, coverage probability, SF marginals). They are NOT external
validation of the 3GPP model against reality; that is the QuaDRiGa kit
(flag V5) plus, ultimately, measurements.
"""
from __future__ import annotations
import numpy as np
from scipy import stats

from . import uav_channel as _pkg  # noqa: F401  (path bootstrap)
import uav_channel as uc
from uav_channel import params as P


def mixture_cdf(env, r, h, fc, x):
    """F(x) of effective path loss PL_state + X_sigma (state-mixed)."""
    p = uc.plos_aerial(env, r, h)
    ul = (np.asarray(x, float) - uc.pl_los_aerial(env, r, h, fc)) \
        / uc.sf_std_aerial(env, h, "LOS")
    un = (np.asarray(x, float) - uc.pl_nlos_aerial(env, r, h, fc)) \
        / uc.sf_std_aerial(env, h, "NLOS")
    return p * stats.norm.cdf(ul) + (1 - p) * stats.norm.cdf(un)


def sample_effective_pl(env, r, h, fc, n, rng=None):
    """IID draws of effective PL (state Bernoulli + per-state lognormal SF)."""
    rng = np.random.default_rng(rng)
    p = uc.plos_aerial(env, r, h)
    los = rng.random(n) < p
    pl = np.where(los, uc.pl_los_aerial(env, r, h, fc),
                  uc.pl_nlos_aerial(env, r, h, fc))
    sig = np.where(los, uc.sf_std_aerial(env, h, "LOS"),
                   uc.sf_std_aerial(env, h, "NLOS"))
    return pl + sig * rng.standard_normal(n)


def ks_effective_pl(env, r, h, fc, n=200_000, rng=None):
    """KS test of MC effective-PL samples against the analytic mixture CDF."""
    x = sample_effective_pl(env, r, h, fc, n, rng)
    res = stats.kstest(x, lambda v: mixture_cdf(env, r, h, fc, v))
    return dict(env=env, fc_ghz=fc, h_m=h, d2d_m=r, n=n,
                ks_D=float(res.statistic), ks_p=float(res.pvalue))


def mc_pcov(env, r, h, fc, l_max, n=200_000, rng=None):
    x = sample_effective_pl(env, r, h, fc, n, rng)
    return float(np.mean(x <= l_max))


def pcov_validation_grid(n=200_000, seed=17):
    """Empirical vs analytic P_cov over a broad grid; binomial CI bookkeeping."""
    rng = np.random.default_rng(seed)
    rows = []
    for env in P.ENVS:
        lo, hi = P.AERIAL_PLOS[env]["band"]
        for h in (30.0, 60.0, 100.0, 150.0, 300.0):
            if not (lo < h <= hi):
                continue
            for r in (100.0, 300.0, 700.0):
                for fc in P.FREQS_GHZ:
                    for lm in (110.0, 120.0, 130.0):
                        ana = float(uc.p_cov(env, r, h, fc, lm))
                        emp = mc_pcov(env, r, h, fc, lm, n, rng)
                        ci = 1.96 * np.sqrt(max(ana * (1 - ana), 1e-12) / n)
                        rows.append(dict(env=env, fc_ghz=fc, h_m=h, d2d_m=r,
                                         l_max_db=lm, analytic=ana,
                                         empirical=emp,
                                         delta=emp - ana, ci95=ci,
                                         within=abs(emp - ana) <= max(ci, 3e-3)))
    return rows


def sf_map_marginal_ks(d_corr=25.0, n_grid=240, rng=5):
    """Marginal normality of the spectral map generator (KS vs N(0,1))."""
    m = uc.spectral_map_2d(n_grid, n_grid, 5.0, d_corr, rng=rng)
    sub = m[::6, ::6].ravel()          # decimate to weaken correlation
    res = stats.kstest(sub, "norm")
    return dict(d_corr=d_corr, n=sub.size, ks_D=float(res.statistic),
                ks_p=float(res.pvalue))
