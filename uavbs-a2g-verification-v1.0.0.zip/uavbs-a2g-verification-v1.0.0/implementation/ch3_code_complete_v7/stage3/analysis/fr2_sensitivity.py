"""E1 sensitivity study: 28-GHz aerial NLoS bracket.

Problem (Stage-1 Assumption E1): the TR 36.777 aerial NLoS regressions are a
sub-6 GHz product; at 28 GHz they are an extrapolation. This module brackets
them with FR2-valid references from TR 38.901 Table 7.4.1-1:

  M0  36.777 aerial NLoS (extrapolated to 28 GHz)      [uav_channel]
  REF frequency-valid NLoS references:
      UMa: optional PL = 32.4 + 20 lg fc + 30.0 lg d3D   (sigma 7.8, <=100 GHz)
      UMi: optional PL = 32.4 + 20 lg fc + 31.9 lg d3D   (sigma 8.2, <=100 GHz)
      RMa: terrestrial NLoS formula, h_UT clamped to its 10 m ceiling
           (RMa valid to 30 GHz per Note 2, single 24-GHz campaign)
  FSPL lower anchor.

Caveats stated verbatim in the report: the UMa/UMi optional models are
height-free (exponent-neutral in altitude) and formally defined for
h_UT <= 22.5 m; they are references for BRACKETING, not replacements.
"""
from __future__ import annotations
import numpy as np

from . import uav_channel as _pkg  # noqa: F401
import uav_channel as uc
from uav_channel.large_scale import qfunc
from uav_channel import params as P

REF_SIGMA = {"UMa": 7.8, "UMi": 8.2, "RMa": 8.0}


def ref_nlos(env, d2d, h, fc):
    d3 = uc.d3d(d2d, h)
    if env == "UMa":
        return 32.4 + 20 * np.log10(fc) + 30.0 * np.log10(d3)
    if env == "UMi":
        return 32.4 + 20 * np.log10(fc) + 31.9 * np.log10(d3)
    # RMa: terrestrial NLoS with h_UT clamped to validity ceiling (10 m);
    # geometry (d3D) keeps the true UAV altitude.
    t = P.TERR["RMa"]; hb, W, hh = t["h_bs"], t["W"], t["h_bld"]
    pln = (161.04 - 7.1 * np.log10(W) + 7.5 * np.log10(hh)
           - (24.37 - 3.7 * (hh / hb) ** 2) * np.log10(hb)
           + (43.42 - 3.1 * np.log10(hb)) * (np.log10(d3) - 3.0)
           + 20 * np.log10(fc)
           - (3.2 * np.log10(11.75 * 10.0) ** 2 - 4.97))
    return np.maximum(pln, uc.fspl(d3, fc))


def delta_pl_grid(env, fc=28.0, h_list=(30, 50, 100, 150, 200, 300),
                  r_list=(100, 200, 500, 1000)):
    """Delta = M0 (36.777 extrapolated) - REF (FR2-valid). Negative =>
    36.777 predicts LESS loss (optimistic clutter escape)."""
    rows = []
    lo, hi = P.AERIAL_PLOS[env]["band"]
    for h in h_list:
        if not (lo < h <= hi):
            continue
        # 36.777 NLoS validity ceilings: UMa 100 m; state saturates anyway
        for r in r_list:
            m0 = float(uc.pl_nlos_aerial(env, r, h, fc))
            rf = float(ref_nlos(env, r, h, fc))
            rows.append(dict(env=env, fc_ghz=fc, h_m=h, d2d_m=r, m0_db=m0,
                             ref_db=rf, delta_db=m0 - rf,
                             fspl_db=float(uc.fspl(uc.d3d(r, h), fc))))
    return rows


def p_cov_ref(env, d2d, h, fc, l_max):
    """Coverage probability with the NLoS branch swapped to REF."""
    p = uc.plos_aerial(env, d2d, h)
    ul = (uc.pl_los_aerial(env, d2d, h, fc) - l_max) \
        / uc.sf_std_aerial(env, h, "LOS")
    un = (ref_nlos(env, d2d, h, fc) - l_max) / REF_SIGMA[env]
    return p * qfunc(ul) + (1 - p) * qfunc(un)


def h_star_ref(env, d2d, fc, l_max, step=0.05, plateau_eps=1e-4):
    lo, hi = P.AERIAL_PLOS[env]["band"]
    hg = np.arange(lo + step, hi, step)
    pc = p_cov_ref(env, float(d2d), hg, float(fc), float(l_max))
    i = int(np.argmax(pc))
    near = pc >= pc[i] - plateau_eps
    return float(hg[i]), float(pc[i]), float(hg[near][0])


def hstar_shift_table(fc=28.0, r_list=(100, 200, 500, 1000),
                      lmax_list=(110.0, 115.0, 120.0, 125.0, 130.0)):
    """h* under M0 vs REF NLoS at FR2 -- robustness of the altitude policy."""
    rows = []
    for env in P.ENVS:
        for r in r_list:
            for lm in lmax_list:
                a = uc.h_star(env, r, fc, lm)
                hb, pb, hb_lo = h_star_ref(env, r, fc, lm)
                meaningful = (a["p_max"] >= 0.1) and (pb >= 0.1)
                rows.append(dict(env=env, fc_ghz=fc, d2d_m=r, l_max_db=lm,
                                 h_star_m0=a["h_star"], p_max_m0=a["p_max"],
                                 regime_m0=a["regime"],
                                 h_lo_m0=a["h_plateau_lo"], h_star_ref=hb,
                                 p_max_ref=pb, h_lo_ref=hb_lo,
                                 shift_argmax_m=hb - a["h_star"],
                                 shift_policy_m=hb_lo - a["h_plateau_lo"],
                                 meaningful=meaningful))
    return rows
