"""Stage-3 analysis layer (validation, metrics, FR2 sensitivity).

Imports the Stage-2 package from ../stage2 (or $UAV_CHANNEL_PATH).
"""
import os
import sys

_CAND = [os.environ.get("UAV_CHANNEL_PATH", ""),
         os.path.join(os.path.dirname(__file__), "..", "..", "stage2")]
for _p in _CAND:
    if _p and os.path.isdir(os.path.join(_p, "uav_channel")):
        sys.path.insert(0, os.path.abspath(_p))
        break
import uav_channel  # noqa: E402,F401  (fails loudly if stage2 not found)
