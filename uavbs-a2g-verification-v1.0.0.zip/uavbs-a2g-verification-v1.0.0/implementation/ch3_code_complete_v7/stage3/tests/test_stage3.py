"""Stage-3 unit tests (stdlib unittest)."""
import math
import os
import sys
import tempfile
import unittest
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..",
                                "quadriga_kit"))
from analysis import validation as V          # noqa: E402
from analysis import metrics as M             # noqa: E402
from analysis import fr2_sensitivity as F     # noqa: E402
import uav_channel as uc                      # noqa: E402
import ingest_quadriga as IQ                  # noqa: E402


class TestValidation(unittest.TestCase):
    def test_mixture_cdf_limits_and_value(self):
        env, r, h, fc = "UMa", 300.0, 100.0, 3.5
        self.assertLess(V.mixture_cdf(env, r, h, fc, 0.0), 1e-12)
        self.assertGreater(V.mixture_cdf(env, r, h, fc, 300.0), 1 - 1e-12)
        # independent hand assembly at x = PL_LoS
        from scipy import stats
        x = uc.pl_los_aerial(env, r, h, fc)
        p = uc.plos_aerial(env, r, h)
        expect = p * 0.5 + (1 - p) * stats.norm.cdf(
            (x - uc.pl_nlos_aerial(env, r, h, fc))
            / uc.sf_std_aerial(env, h, "NLOS"))
        self.assertAlmostEqual(V.mixture_cdf(env, r, h, fc, x), expect,
                               places=12)

    def test_mc_pcov_within_ci(self):
        rng_cases = [("UMa", 300, 100, 3.5, 120), ("UMi", 100, 40, 2.6, 110),
                     ("RMa", 500, 30, 28.0, 125), ("UMa", 700, 60, 28.0, 115)]
        for env, r, h, fc, lm in rng_cases:
            ana = float(uc.p_cov(env, r, h, fc, lm))
            emp = V.mc_pcov(env, r, h, fc, lm, n=50_000, rng=7)
            ci = 4 * math.sqrt(max(ana * (1 - ana), 1e-9) / 50_000)
            self.assertLess(abs(emp - ana), max(ci, 4e-3),
                            msg=f"{env} {r} {h} {fc} {lm}")

    def test_ks_sane(self):
        res = V.ks_effective_pl("UMa", 300, 100, 3.5, n=50_000, rng=3)
        self.assertGreater(res["ks_p"], 1e-4)


class TestMetrics(unittest.TestCase):
    def test_coherence(self):
        self.assertAlmostEqual(M.coherence_time_s(20, 28.0) * 1e3, 0.2266,
                               delta=0.002)
        self.assertAlmostEqual(M.coherence_bw_hz(10e-9) / 1e6, 15.915,
                               delta=0.01)

    def test_alt2_ds_median(self):
        # UMa LOS h=100: mu_lgDS = -0.31*2 - 6.845 = -7.465 -> 34.3 ns
        self.assertAlmostEqual(M.alt2_median_ds_s("UMa", "LOS", 100.0) * 1e9,
                               10 ** (-7.465) * 1e9, places=6)

    def test_pas_normalised(self):
        ang, p = M.alt1_pas("UMa", "LOS", 100.0, 300.0,
                            dict(aod=0, aoa=-170, zod=100, zoa=80))
        self.assertAlmostEqual(float(p.sum()), 1.0, places=9)
        # specular ray dominates a K=20 dB channel
        self.assertGreater(p[0], 0.9)
        self.assertAlmostEqual(ang[0], -170.0, delta=1e-9)


class TestFR2(unittest.TestCase):
    def test_ref_spot_values(self):
        d3 = math.hypot(500.0, 98.5)
        exp = 32.4 + 20 * math.log10(28.0) + 30.0 * math.log10(d3)
        self.assertAlmostEqual(float(F.ref_nlos("UMa", 500, 100, 28.0)), exp,
                               places=9)
        m0 = float(uc.pl_nlos_aerial("UMa", 500, 100, 28.0))
        delta = m0 - exp
        self.assertTrue(-12.6 < delta < -11.5, msg=f"delta={delta:.2f}")
        self.assertTrue(np.isfinite(F.ref_nlos("RMa", 500, 100, 28.0)))

    def test_delta_grows_with_altitude(self):
        d30 = float(uc.pl_nlos_aerial("UMa", 500, 30, 28.0)
                    - F.ref_nlos("UMa", 500, 30, 28.0))
        d100 = float(uc.pl_nlos_aerial("UMa", 500, 100, 28.0)
                     - F.ref_nlos("UMa", 500, 100, 28.0))
        self.assertLess(d100, d30)          # more optimistic at altitude
        self.assertLess(abs(d30), 4.0)      # near-agreement low in the band

    def test_hstar_ceiling_invariance(self):
        # deep-coverage FR2 regime is LoS-dominated -> NLoS swap barely moves h*
        a = uc.h_star("UMa", 500, 28.0, 130.0)
        hb, pb, _ = F.h_star_ref("UMa", 500, 28.0, 130.0)
        self.assertLess(abs(hb - a["h_star"]), 5.0)
        self.assertGreater(pb, 0.99)


class TestIngestPipeline(unittest.TestCase):
    def test_synthetic_roundtrip(self):
        with tempfile.TemporaryDirectory() as td:
            src = os.path.join(td, "synthetic.csv")
            rep = os.path.join(td, "report.csv")
            IQ.synth_campaign(src, n_seed=400, envs=("UMa",), fcs=(3.5,),
                              h_list=(100.0,), r_list=(300.0,), seed=4)
            out = IQ.compare(src, rep)
            self.assertEqual(len(out), 1)
            rec = out[0]
            self.assertTrue(rec["plos_ok"])
            self.assertLess(abs(rec["plbias_LOS"]), 0.3)
            if not math.isnan(rec["plbias_NLOS"]):
                self.assertLess(abs(rec["plbias_NLOS"]), 0.5)
            self.assertTrue(0.85 < rec["sfratio_LOS"] < 1.15)
            self.assertLess(abs(rec["dsbias_dex_LOS"]), 0.15)
            self.assertTrue(os.path.exists(rep))


if __name__ == "__main__":
    unittest.main(verbosity=2)
