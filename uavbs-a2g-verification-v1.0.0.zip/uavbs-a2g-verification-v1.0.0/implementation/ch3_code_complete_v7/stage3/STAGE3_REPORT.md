# Chapter 3 — Stage 3 of 4: Validation Campaign and FR2 Sensitivity Study

M. J. Alhasan — Stage-3 build log, July 2026.

## Scope and environment constraint

Stage 3 covers the outline's §3.3 metrics and the model-risk items flagged in
Stages 1–2. The sandbox has no MATLAB/Octave and no network route to the
QuaDRiGa site (apt/GitHub/PyPI all blocked), so the Quadriga leg of the
validation runs **externally**: a complete campaign kit is delivered
(`quadriga_kit/`), whose Python half **is** tested here end-to-end on
synthetic data. Flag **V5** tracks the external run. Everything else in this
stage executed in-sandbox: 10 new unit tests, all passing, on top of the 26
Stage-2 tests.

Honest labelling, repeated from the module docstrings: the Monte-Carlo checks
below validate the **implementation** against the **analytic** Stage-1
targets. They are not external validation of the 3GPP model against physical
reality — that is what the QuaDRiGa kit (V5) and, ultimately, measurement
campaigns are for.

## 1. Statistical self-consistency (implementation validation)

* **Coverage chain.** 405 grid cells (3 env × altitudes × ranges × 3 carriers
  × 3 budgets), 200 000 Monte-Carlo state+shadowing draws per cell against
  analytic Eq. (29): **max deviation 0.0033**, exactly one cell marginally
  outside its 95 % binomial CI (expected count at this criterion: a few) —
  `out3/validation_pcov.csv`, figure `g1`.
* **Effective-path-loss distributions.** KS tests of the sampled
  PL + X_sigma against the analytic two-component mixture CDF at 12
  (env, h, r, f_c) points, n = 200 000: **min p-value 0.38** — no test
  rejects; the UMi panel of `g2` shows the mixture shoulder (LoS bulk, NLoS
  tail) reproduced exactly. Marginal normality of the spectral SF map
  generator also passes KS (`validation_ks.csv`).

## 2. Outline §3.3 metrics (from the instantiated model)

* **Coherence time** (`coherence_time.csv`, `g3a`): T_c crosses the NR
  mu=0 slot (1 ms) at ~9 m/s for 3.5 GHz, and sits at 0.15–0.45 ms for
  28 GHz at 10–30 m/s — the per-slot fading-redraw requirement of the DRL
  simulator is now a quantified statement, not a heuristic.
* **Coherence bandwidth** (`coherence_bandwidth.csv`, `g3b`): from Alt-2
  median DS, B_c rises from ~4.5 MHz (UMa-AV LoS, 22.5 m) to ~15 MHz at
  300 m; RMa-AV LoS reaches ~15 MHz already at 100 m. Against 5G NR PRB
  granularity this puts *tens of PRBs inside one coherence bandwidth* at
  altitude — directly shaping the Chapter-4 PRB-allocation state (frequency
  diversity largely disappears for aerial LoS links).
* **Angular spectra** (`g4a`, `g4b`): the Alt-1 scaled CDL-D azimuth PAS at
  h = 100 m is a specular line at the LoS azimuth with all Laplacian rays
  within ±3°, 0 dB total power dominated >90 % by the direct ray. The Alt-2
  regressions, plotted verbatim, push median ASA to 1e-5…1e-9 degrees —
  **sub-physical values** (shaded region of `g4b`), while ZSA stays at a
  plausible 0.3–0.6°. New decision **D4**: floor azimuth spreads at the
  Alt-1 desired values (0.2–1°) before simulation use; the package keeps the
  TR-verbatim values and exposes the floor as an explicit argument
  (`alt2_as_curves(..., floor_deg=...)`).

## 3. E1 closure: the 28-GHz NLoS bracket

Design: bracket the extrapolated TR 36.777 aerial NLoS (M0) with
frequency-valid TR 38.901 references — the optional UMa/UMi NLoS models
(32.4 + 20 lg f_c + {30.0, 31.9} lg d_3D; valid to 100 GHz, height-free) and
the RMa terrestrial NLoS (valid to 30 GHz) with h_UT clamped to its 10-m
ceiling; free space as the lower anchor. Results
(`fr2_delta_pl.csv`, `g5`):

* At the **bottom of the aerial band** (h = 30 m) the models nearly agree:
  |Delta| < 4 dB (UMa, r = 500 m: −2.2 dB).
* The divergence **grows with altitude** — the un-validated clutter-escape
  term: at h >= 100 m, Delta(M0 − REF) spans **−1.8 to −22.7 dB** across
  environments/ranges (UMa, h = 100 m, r = 500 m: −12.0 dB). TR 36.777 is
  systematically the *optimistic* side of the bracket at FR2.
* **Yet the altitude policy is robust** (`fr2_hstar_shift.csv`, `g6`):
  swapping the NLoS branch for the pessimistic reference moves the
  policy altitude (lowest altitude attaining the coverage plateau, the
  energy tie-break of Prop. 7.2) by **at most 14.4 m** over the 49
  meaningful cells (11 cells have no coverage under one of the models at
  tight FR2 budgets — there the optimisation question is moot). Reason,
  now verified numerically: h* is governed by the P_LoS geometry (the LoS
  wall), which both models share; the NLoS branch controls *how bad* the
  shadowed state is, not *where* the optimum sits.

E1 status: **bounded and characterised**; final closure still requires the
external Quadriga run (V5) and, for publication-grade FR2 claims, a
measurement-anchored reference. For Chapters 4–7 the practical consequence
is favourable: DRL altitude policies trained on M0 transfer to the
pessimistic model with metre-level altitude error; only *coverage-value*
estimates (not argmax) carry the up-to-23 dB uncertainty.

## 4. QuaDRiGa external kit (flag V5)

`quadriga_kit/quadriga_campaign.m` — commented campaign over
(env × f_c × h × r × 50 seeds) exporting one CSV row per link (schema in the
header; TODO markers where QuaDRiGa-version field names must be checked
against your install). `quadriga_kit/ingest_quadriga.py` — the comparator:
per-cell empirical P_LoS vs Table B-1 with binomial CI, per-state PL bias,
sigma_SF ratio, DS/AS log-median bias vs Alt-2. **The comparator is
validated in-sandbox**: a synthetic campaign drawn from the Stage-2 model
itself round-trips through it (P_LoS within CI, PL bias < 0.3 dB, sigma
ratio 0.85–1.15, DS bias < 0.15 dex) — `tests/test_stage3.py`.

Run on your machine: QuaDRiGa >= 2.6 (MATLAB or Octave), execute the .m,
then `python quadriga_kit/ingest_quadriga.py quadriga_samples.csv report.csv`
and return both CSVs to the project log.

## 5. Flag register after Stage 3

| Flag | Status |
|---|---|
| V1 UMi-AV Alt-2 source (TR 36.777 ref. [9]) | open — RAN1 archive pull |
| V2 rooftop height in (B.1.1-2), default 20 m | open — committee decision |
| V3 V19.4.0 vintage for reused LSPs | documented decision |
| V4 Sionna cross-checks (Stage-2 kit) | open — run locally |
| V5 QuaDRiGa external campaign | **new** — kit delivered, comparator tested |
| E1 28-GHz aerial NLoS validity | **bounded** (−23…−2 dB bracket); h* robust to it (<=14.4 m) |
| D4 sub-physical Alt-2 azimuth spreads | **new decision** — floor at Alt-1 values for simulation |

## 6. Inventory

`analysis/` (validation, metrics, fr2_sensitivity) · `scripts/run_stage3.py`,
`scripts/make_figures3.py` · `tests/test_stage3.py` (10 tests, all pass) ·
`out3/`: validation_pcov.csv, validation_ks.csv, coherence_time.csv,
coherence_bandwidth.csv, fr2_delta_pl.csv, fr2_hstar_shift.csv,
figures g1–g6 · `quadriga_kit/` (campaign.m, ingest_quadriga.py).

## Next (Stage 4)

Freeze the lookup schema against the Chapter-4 MDP state design; export the
final channel API contract for the DRL environments (state features:
P_LoS, mean gain, sigma, B_c, T_c, h*-prior); regenerate all tables after
V4/V5 results arrive.
