"""Stage-3 campaign runner: validation stats, coherence metrics, E1 study."""
import csv
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from analysis import validation as V
from analysis import metrics as M
from analysis import fr2_sensitivity as F

OUT = os.path.join(os.path.dirname(__file__), "..", "out3")
os.makedirs(OUT, exist_ok=True)


def dump(rows, name):
    path = os.path.join(OUT, name)
    keys = list(rows[0].keys())
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)
    print(f"{name}: {len(rows)} rows")
    return path


# 1. MC coverage validation ---------------------------------------------------
rows = V.pcov_validation_grid(n=200_000, seed=17)
dump(rows, "validation_pcov.csv")
worst = max(rows, key=lambda r: abs(r["delta"]))
n_out = sum(1 for r in rows if not r["within"])
print(f"   max |emp-ana| = {abs(worst['delta']):.4f} "
      f"({worst['env']} fc={worst['fc_ghz']} h={worst['h_m']} "
      f"r={worst['d2d_m']} Lmax={worst['l_max_db']}); outside CI: {n_out}")

# 2. KS tests of effective-PL mixture ----------------------------------------
ks = []
for env, h, r in (("UMa", 100, 300), ("UMa", 60, 700), ("UMi", 150, 300),
                  ("UMi", 40, 100), ("RMa", 30, 500), ("RMa", 100, 1000)):
    for fc in (3.5, 28.0):
        ks.append(V.ks_effective_pl(env, r, h, fc, n=200_000, rng=23))
ks.append(dict(env="map_marginal", fc_ghz=0, h_m=0, d2d_m=0,
               **{k: v for k, v in V.sf_map_marginal_ks().items()
                  if k in ("n", "ks_D", "ks_p")}))
dump(ks, "validation_ks.csv")
print("   min KS p-value:", min(r["ks_p"] for r in ks))

# 3. coherence metrics --------------------------------------------------------
dump(M.coherence_table(), "coherence_time.csv")
dump(M.bc_table(), "coherence_bandwidth.csv")

# 4. E1 FR2 sensitivity -------------------------------------------------------
d_all = []
for env in ("UMa", "UMi", "RMa"):
    d_all += F.delta_pl_grid(env)
dump(d_all, "fr2_delta_pl.csv")
neg = [r for r in d_all if r["h_m"] >= 100]
print(f"   Delta(M0-REF) at h>=100 m: "
      f"min {min(r['delta_db'] for r in neg):.1f} dB, "
      f"max {max(r['delta_db'] for r in neg):.1f} dB")

shift = F.hstar_shift_table()
dump(shift, "fr2_hstar_shift.csv")
mrows = [r for r in shift if r["meaningful"]]
wall_rows = [r for r in mrows if r["regime_m0"] in ("wall", "plateau",
                                                    "ceiling")]
if wall_rows:
    mx = max(abs(r["shift_policy_m"]) for r in wall_rows)
    print(f"   max |policy-altitude shift| over meaningful wall/plateau/"
          f"ceiling rows: {mx:.1f} m ({len(wall_rows)} rows)")
if mrows:
    mx_all = max(mrows, key=lambda r: abs(r["shift_policy_m"]))
    print(f"   max |policy shift| over meaningful rows: "
          f"{mx_all['shift_policy_m']:+.1f} m at ({mx_all['env']}, "
          f"r={mx_all['d2d_m']}, Lmax={mx_all['l_max_db']}, "
          f"regime={mx_all['regime_m0']})")
print(f"   meaningful rows: {len(mrows)}/{len(shift)}")
print("done")
