"""Stage-3 figures (dataviz reference palette, <=3 categorical series/axis)."""
import csv
import os
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from analysis import validation as V
from analysis import metrics as M
from analysis import fr2_sensitivity as F
import uav_channel as uc
from uav_channel import params as P

OUT = os.path.join(os.path.dirname(__file__), "..", "out3", "figures")
CSV = os.path.join(os.path.dirname(__file__), "..", "out3")
os.makedirs(OUT, exist_ok=True)

S1, S2, S3 = "#2a78d6", "#eb6834", "#1baf7a"
SURFACE, INK, INK2, MUTED = "#fcfcfb", "#0b0b0b", "#52514e", "#898781"
GRID, BASE = "#e1e0d9", "#c3c2b7"
plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE,
    "savefig.facecolor": SURFACE, "font.family": "DejaVu Sans",
    "axes.edgecolor": BASE, "axes.labelcolor": INK2, "axes.linewidth": 1.0,
    "xtick.color": MUTED, "ytick.color": MUTED, "xtick.labelsize": 9,
    "ytick.labelsize": 9, "axes.titlesize": 10.5, "axes.titlecolor": INK,
    "axes.labelsize": 9.5, "grid.color": GRID, "grid.linewidth": 0.8,
    "legend.frameon": False, "legend.fontsize": 9, "lines.linewidth": 2.0})


def style(ax):
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(True, alpha=0.9)
    ax.set_axisbelow(True)


# g1 -- MC coverage validation scatter ---------------------------------------
rows = list(csv.DictReader(open(os.path.join(CSV, "validation_pcov.csv"))))
ana = np.array([float(r["analytic"]) for r in rows])
emp = np.array([float(r["empirical"]) for r in rows])
fig, ax = plt.subplots(figsize=(5.6, 5.2))
ax.plot([0, 1], [0, 1], color=BASE, lw=1.2)
ax.plot(ana, emp, "o", ms=4.5, mfc="none", mec=S1, mew=1.3)
style(ax)
ax.set_xlabel("analytic $P_{cov}$ (Stage-1 Eq. 29)")
ax.set_ylabel("Monte-Carlo $P_{cov}$ ($n$=200k/cell)")
mx = float(np.max(np.abs(emp - ana)))
ax.set_title(f"Coverage-chain self-consistency: 405 cells, "
             f"max deviation {mx:.4f}")
fig.tight_layout()
fig.savefig(os.path.join(OUT, "g1_pcov_validation.png"), dpi=150,
            bbox_inches="tight")

# g2 -- effective-PL CDFs vs mixture theory ----------------------------------
cases = (("UMa", 100.0, 300.0), ("UMi", 150.0, 300.0), ("RMa", 30.0, 500.0))
fig, axes = plt.subplots(1, 3, figsize=(11, 3.5), sharey=True)
for ax, (env, h, r) in zip(axes, cases):
    x = V.sample_effective_pl(env, r, h, 3.5, 120_000, rng=23)
    xs = np.sort(x)
    ax.plot(xs, np.arange(1, xs.size + 1) / xs.size, color=S2, lw=2.6,
            label="Monte-Carlo")
    xg = np.linspace(xs[0] - 2, xs[-1] + 2, 500)
    ax.plot(xg, V.mixture_cdf(env, r, h, 3.5, xg), color=S1, lw=1.4,
            label="analytic mixture")
    ks = V.ks_effective_pl(env, r, h, 3.5, n=120_000, rng=23)
    ax.text(0.03, 0.9, f"KS $D$={ks['ks_D']:.4f}\n$p$={ks['ks_p']:.2f}",
            transform=ax.transAxes, color=INK2, fontsize=8.5)
    style(ax)
    ax.set_title(f"{env}-AV  (h={h:.0f} m, $d_{{2D}}$={r:.0f} m, 3.5 GHz)")
    ax.set_xlabel("effective PL = PL + $X_\\sigma$ [dB]")
axes[0].set_ylabel("CDF")
axes[0].legend(loc="lower right")
fig.tight_layout()
fig.savefig(os.path.join(OUT, "g2_effpl_cdf.png"), dpi=150,
            bbox_inches="tight")

# g3 -- coherence time and bandwidth -----------------------------------------
fig, ax = plt.subplots(figsize=(6.4, 3.8))
v = np.linspace(1, 35, 200)
for fc, c in ((2.6, S1), (3.5, S2), (28.0, S3)):
    ax.plot(v, 0.423 / uc.fd_max(v, fc) * 1e3, color=c,
            label=f"$f_c$ = {fc} GHz")
for slot, lab in ((1.0, "$\\mu$=0 slot"), (0.25, "$\\mu$=2 slot")):
    ax.axhline(slot, color=MUTED, lw=1.0, ls=":")
    ax.text(34.5, slot * 1.07, lab, color=MUTED, fontsize=8, ha="right")
style(ax)
ax.set_yscale("log")
ax.set_xlabel("UAV/UE speed [m/s]")
ax.set_ylabel("coherence time $T_c$ [ms]")
ax.set_title("Coherence time vs speed (Clarke $0.423/f_{D,max}$) "
             "vs NR slot lengths")
ax.legend(loc="upper right")
fig.tight_layout()
fig.savefig(os.path.join(OUT, "g3a_coherence_time.png"), dpi=150,
            bbox_inches="tight")

fig, axes = plt.subplots(1, 2, figsize=(9.6, 3.6), sharey=True)
h = np.linspace(23, 300, 250)
hr = np.linspace(10.5, 300, 250)
for ax, state in zip(axes, ("LOS", "NLOS")):
    for env, hh, c in (("UMa", h, S1), ("RMa", hr, S2)):
        ds = np.array([M.alt2_median_ds_s(env, state, x) for x in hh])
        ax.plot(hh, M.coherence_bw_hz(ds) / 1e6, color=c,
                label=f"{env}-AV (Alt-2 median DS)")
    des = P.ALT1_DESIRED[("UMa", state)]["DS"] * 1e-9
    ax.axhline(M.coherence_bw_hz(des) / 1e6, color=MUTED, lw=1.0, ls=":")
    ax.text(295, M.coherence_bw_hz(des) / 1e6 * 1.1,
            f"Alt-1 desired DS ({des*1e9:.0f} ns)", color=MUTED, fontsize=8,
            ha="right")
    style(ax)
    ax.set_yscale("log")
    ax.set_title(f"{state}")
    ax.set_xlabel("UAV altitude $h_{UT}$ [m]")
axes[0].set_ylabel("coherence bandwidth $B_c$ [MHz]")
axes[0].legend(loc="lower right")
fig.suptitle("Coherence bandwidth $1/(2\\pi\\,DS)$ vs altitude "
             "(UMi excluded: open flag V1)", color=INK, fontsize=11, y=1.03)
fig.tight_layout()
fig.savefig(os.path.join(OUT, "g3b_coherence_bw.png"), dpi=150,
            bbox_inches="tight")

# g4 -- angular structure -----------------------------------------------------
fig, ax = plt.subplots(figsize=(6.6, 3.8))
ang, p = M.alt1_pas("UMa", "LOS", 100.0, 300.0,
                    dict(aod=0.0, aoa=-170.0, zod=100.0, zoa=80.0))
ml, sl, bl = ax.stem(ang, 10 * np.log10(np.maximum(p, 1e-9)))
plt.setp(sl, color=S1, lw=1.2)
plt.setp(ml, mec=S1, mfc=S1, ms=3.5)
plt.setp(bl, visible=False)
style(ax)
ax.set_xlim(-176, -164)
ax.set_ylim(-65, 3)
ax.set_xlabel("azimuth of arrival [deg]")
ax.set_ylabel("ray power [dB, total=0 dB]")
ax.set_title("Alt-1 azimuth PAS, UMa-AV LoS, h=100 m "
             "(ASA scaled to 0.5$^\\circ$, K=20 dB; specular at "
             "$-170^\\circ$)")
fig.tight_layout()
fig.savefig(os.path.join(OUT, "g4a_pas.png"), dpi=150, bbox_inches="tight")

fig, axes = plt.subplots(1, 2, figsize=(9.6, 3.6), sharey=True)
hu = np.linspace(23, 300, 200)
for ax, key in zip(axes, ("ASA", "ZSA")):
    for state, c in (("LOS", S1), ("NLOS", S2)):
        vals = M.alt2_as_curves("UMa", state, hu)[key]
        ax.plot(hu, np.maximum(vals, 1e-12), color=c, label=state)
    ax.axhspan(1e-12, 1e-3, color=GRID, alpha=0.5, lw=0)
    ax.text(290, 2e-3, "sub-millidegree region\n(decision D4: floor before "
            "simulation)", color=INK2, fontsize=7.5, ha="right")
    style(ax)
    ax.set_yscale("log")
    ax.set_title(f"Alt-2 median {key}, UMa-AV")
    ax.set_xlabel("UAV altitude $h_{UT}$ [m]")
axes[0].set_ylabel("angular spread [deg]")
axes[0].legend(loc="upper right")
fig.tight_layout()
fig.savefig(os.path.join(OUT, "g4b_alt2_as.png"), dpi=150,
            bbox_inches="tight")

# g5 -- FR2 NLoS bracket ------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(10.4, 3.8), sharey=True)
r = np.linspace(50, 1000, 400)
for ax, hh in zip(axes, (30.0, 100.0)):
    m0 = uc.pl_nlos_aerial("UMa", r, hh, 28.0)
    rf = F.ref_nlos("UMa", r, hh, 28.0)
    ax.fill_between(r, m0, rf, color=S1, alpha=0.12, lw=0)
    ax.plot(r, m0, color=S1, label="M0: TR 36.777 aerial NLoS (extrapolated)")
    ax.plot(r, rf, color=S2, label="REF: TR 38.901 FR2-valid NLoS (opt.)")
    ax.plot(r, uc.fspl(uc.d3d(r, hh), 28.0), color=MUTED, lw=1.2, ls=":",
            label="free space")
    style(ax)
    ax.set_title(f"UMa-AV NLoS bracket at 28 GHz, h = {hh:.0f} m")
    ax.set_xlabel("$d_{2D}$ [m]")
axes[0].set_ylabel("path loss [dB]")
axes[0].legend(loc="lower right", fontsize=8)
fig.tight_layout()
fig.savefig(os.path.join(OUT, "g5_fr2_bracket.png"), dpi=150,
            bbox_inches="tight")

# g6 -- policy-altitude robustness --------------------------------------------
rows = [r for r in csv.DictReader(open(os.path.join(CSV,
                                                    "fr2_hstar_shift.csv")))
        if r["meaningful"] == "True"]
fig, ax = plt.subplots(figsize=(6.8, 3.8))
rng = np.random.default_rng(1)
for env, c in (("UMa", S1), ("UMi", S2), ("RMa", S3)):
    xs = [float(r["l_max_db"]) + rng.uniform(-0.9, 0.9) for r in rows
          if r["env"] == env]
    ys = [float(r["shift_policy_m"]) for r in rows if r["env"] == env]
    ax.plot(xs, ys, "o", ms=5, mfc="none", mec=c, mew=1.5, label=env + "-AV")
ax.axhline(0, color=BASE, lw=1.0)
style(ax)
ax.set_xlabel("link budget $L_{max}$ [dB]")
ax.set_ylabel("policy-altitude shift [m]  (REF $-$ M0)")
ax.set_title("h* robustness to the FR2 NLoS model swap "
             f"({len(rows)} meaningful cells; max |shift| = "
             f"{max(abs(float(r['shift_policy_m'])) for r in rows):.1f} m)")
ax.legend(loc="upper left")
fig.tight_layout()
fig.savefig(os.path.join(OUT, "g6_hstar_robustness.png"), dpi=150,
            bbox_inches="tight")
print("figures written to", OUT)
