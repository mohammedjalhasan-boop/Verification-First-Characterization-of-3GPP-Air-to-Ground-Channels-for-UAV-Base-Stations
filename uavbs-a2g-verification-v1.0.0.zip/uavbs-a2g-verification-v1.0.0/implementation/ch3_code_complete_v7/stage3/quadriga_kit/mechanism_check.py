"""Test the hypothesized mechanism behind the NLoS PL gaps.

Hypothesis (UMa/UMi): 38.901 terrestrial NLoS PL' contains a height-gain term
-0.6(h_UT-1.5) [UMa] / -0.3(h_UT-1.5) [UMi]; extrapolated to UAV altitude it
sinks below PL_LoS, so QuaDRiGa's max(PL_LoS, PL') floor makes "NLoS" links
carry LoS-grade path loss. Gap = floored_terrestrial - aerial_NLoS_model.

Compare predicted gap vs the campaign's plbias_NLOS for every cell.
"""
import csv, math, sys
import numpy as np
import os as _os
_HERE = _os.path.dirname(_os.path.abspath(__file__))
sys.path.insert(0, _os.path.join(_HERE, '../../stage2'))
import uav_channel as uc

rows = []
_report = sys.argv[1] if len(sys.argv) > 1 else _os.path.join(_HERE, 'report_executed_2026-08.csv')
with open(_report) as f:
    for r in csv.DictReader(f):
        rows.append(r)

def d3d(r, h):
    return math.sqrt(r*r + (h-1.5)**2)

def terr_uma(r, h, fc):
    d = d3d(r, h)
    pl1 = 28.0 + 22*math.log10(d) + 20*math.log10(fc)
    plp = 13.54 + 39.08*math.log10(d) + 20*math.log10(fc) - 0.6*(h-1.5)
    return max(pl1, plp), plp < pl1

def terr_umi(r, h, fc):
    d = d3d(r, h)
    pl1 = 32.4 + 21*math.log10(d) + 20*math.log10(fc)
    plp = 22.4 + 35.3*math.log10(d) + 21.3*math.log10(fc) - 0.3*(h-1.5)
    return max(pl1, plp), plp < pl1

print("=== UMa: predicted (floored terrestrial - aerial model) vs observed plbias_NLOS ===")
errs, floored_n, tot = [], 0, 0
for r in rows:
    if r['env'] != 'UMa' or r['plbias_NLOS'] in ('', 'nan'):
        continue
    h, rr, fc = float(r['h_m']), float(r['d2d_m']), float(r['fc_ghz'])
    obs = float(r['plbias_NLOS'])
    terr, was_floored = terr_uma(rr, h, fc)
    model = uc.pl_nlos_aerial('UMa', rr, h, fc)
    pred = terr - model
    errs.append(pred - obs); tot += 1; floored_n += was_floored
    if abs(pred - obs) > 0.35:
        print(f"  MISMATCH h={h:.0f} r={rr:.0f} fc={fc}: pred {pred:+.2f} obs {obs:+.2f}")
print(f"UMa: {tot} cells, floor active in {floored_n}, max|pred-obs|={max(abs(e) for e in errs):.3f} dB, "
      f"median={np.median(np.abs(errs)):.3f} dB")

print("\n=== UMi: same test ===")
errs, floored_n, tot = [], 0, 0
for r in rows:
    if r['env'] != 'UMi' or r['plbias_NLOS'] in ('', 'nan'):
        continue
    h, rr, fc = float(r['h_m']), float(r['d2d_m']), float(r['fc_ghz'])
    obs = float(r['plbias_NLOS'])
    terr, was_floored = terr_umi(rr, h, fc)
    model = uc.pl_nlos_aerial('UMi', rr, h, fc)
    pred = terr - model
    errs.append(pred - obs); tot += 1; floored_n += was_floored
    if abs(pred - obs) > 0.35:
        print(f"  MISMATCH h={h:.0f} r={rr:.0f} fc={fc}: pred {pred:+.2f} obs {obs:+.2f}")
print(f"UMi: {tot} cells, floor active in {floored_n}, max|pred-obs|={max(abs(e) for e in errs):.3f} dB, "
      f"median={np.median(np.abs(errs)):.3f} dB")

print("\n=== RMa: hypothesis scan (which h_BS/h_UT does QuaDRiGa use in the Hata-like NLoS?) ===")
def rma_pl1(d, fc, hb=5.0):
    a = min(0.03*hb**1.72, 10.0); b = min(0.044*hb**1.72, 14.77)
    return 20*math.log10(40*math.pi*d*fc/3) + a*math.log10(d) - b + 0.002*math.log10(hb)*d

def rma_nlos(d, fc, hbs, hut, W=20.0, hh=5.0):
    return (161.04 - 7.1*math.log10(W) + 7.5*math.log10(hh)
            - (24.37 - 3.7*(hh/hbs)**2)*math.log10(hbs)
            + (43.42 - 3.1*math.log10(hbs))*(math.log10(d) - 3)
            + 20*math.log10(fc)
            - (3.2*(math.log10(11.75*hut))**2 - 4.97))

for name, hbs_f, hut_f in [("hBS=1.5, hUT=h", lambda h: 1.5, lambda h: h),
                           ("hBS=h, hUT=1.5", lambda h: h, lambda h: 1.5),
                           ("hBS=35, hUT=1.5", lambda h: 35.0, lambda h: 1.5),
                           ("hBS=1.5, hUT=min(h,10)", lambda h: 1.5, lambda h: min(h,10.0))]:
    errs = []
    for r in rows:
        if r['env'] != 'RMa' or r['plbias_NLOS'] in ('', 'nan'):
            continue
        h, rr, fc = float(r['h_m']), float(r['d2d_m']), float(r['fc_ghz'])
        obs = float(r['plbias_NLOS'])
        d = d3d(rr, h)
        terr = max(rma_pl1(d, fc), rma_nlos(d, fc, hbs_f(h), hut_f(h)))
        model = uc.pl_nlos_aerial('RMa', rr, h, fc)
        errs.append((terr - model) - obs)
    print(f"  {name:26}: max|err|={max(abs(e) for e in errs):6.2f}  median|err|={np.median(np.abs(errs)):6.2f} dB")
