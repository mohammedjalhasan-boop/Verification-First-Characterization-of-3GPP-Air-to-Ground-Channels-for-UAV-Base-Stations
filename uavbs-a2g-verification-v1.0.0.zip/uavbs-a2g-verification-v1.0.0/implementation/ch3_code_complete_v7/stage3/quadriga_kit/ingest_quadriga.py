"""Comparator for the QuaDRiGa campaign CSV (flag V5).

Reads quadriga_samples.csv (schema in quadriga_campaign.m) and tests the
Stage-2 model cell by cell:
  * empirical P_LoS vs TR 36.777 Table B-1 (binomial 95% CI)
  * per-state PL bias: median(sampled pl_db) - model PL        [target |.|<1 dB]
  * sigma_SF ratio: std(sf_db) / model sigma                   [target 0.8-1.2]
  * DS / AS medians vs Alt-2 log-normal medians (UMa/RMa)      [ratio in dB]

This module IS tested in the sandbox: tests/test_stage3.py builds a synthetic
campaign CSV from the Stage-2 model itself and checks that the comparator
recovers it (pipeline validation). Only the .m data producer is external.

Usage: python ingest_quadriga.py quadriga_samples.csv report.csv
"""
from __future__ import annotations
import csv
import math
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from analysis import uav_channel as _pkg  # noqa: F401,E402
import numpy as np                         # noqa: E402
import uav_channel as uc                   # noqa: E402


def load(path):
    rows = []
    with open(path) as f:
        for r in csv.DictReader(f):
            rows.append({k: (v if k == "env" else float(v))
                         for k, v in r.items()})
    return rows


def synth_campaign(path, n_seed=60, envs=("UMa", "RMa"), fcs=(3.5,),
                   h_list=(30.0, 100.0, 300.0), r_list=(100.0, 500.0),
                   seed=99):
    """Synthetic stand-in for the QuaDRiGa output, drawn from the Stage-2
    model itself (used to validate this pipeline; NOT external validation)."""
    rng = np.random.default_rng(seed)
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["env", "fc_ghz", "h_m", "d2d_m", "seed", "los", "pl_db",
                    "sf_db", "ds_ns", "asd_deg", "asa_deg", "zsd_deg",
                    "zsa_deg", "kf_db"])
        for env in envs:
            for fc in fcs:
                for h in h_list:
                    for r in r_list:
                        p = uc.plos_aerial(env, r, h)
                        for s in range(n_seed):
                            los = int(rng.random() < p)
                            st = "LOS" if los else "NLOS"
                            pl = (uc.pl_los_aerial(env, r, h, fc) if los
                                  else uc.pl_nlos_aerial(env, r, h, fc))
                            sig = uc.sf_std_aerial(env, h, st)
                            sf = sig * rng.standard_normal()
                            lsp = uc.lsp_alt2(env, h, st)
                            ds = 10 ** rng.normal(*lsp["lgDS"]) * 1e9
                            asd = 10 ** rng.normal(*lsp["lgASD"])
                            asa = 10 ** rng.normal(*lsp["lgASA"])
                            zsd = 10 ** rng.normal(*lsp["lgZSD"])
                            zsa = 10 ** rng.normal(*lsp["lgZSA"])
                            kf = (rng.normal(*lsp["K"]) if los and "K" in lsp
                                  else float("nan"))
                            w.writerow([env, fc, h, r, s, los,
                                        round(pl, 3), round(sf, 3),
                                        round(ds, 4), f"{asd:.6g}",
                                        f"{asa:.6g}", f"{zsd:.6g}",
                                        f"{zsa:.6g}",
                                        "nan" if math.isnan(kf)
                                        else round(kf, 3)])
    return path


def compare(samples_path, report_path=None):
    rows = load(samples_path)
    cells = {}
    for r in rows:
        cells.setdefault((r["env"], r["fc_ghz"], r["h_m"], r["d2d_m"]),
                         []).append(r)
    out = []
    for (env, fc, h, r), grp in sorted(cells.items()):
        n = len(grp)
        los = np.array([g["los"] for g in grp], bool)
        p_emp = float(los.mean())
        p_mod = float(uc.plos_aerial(env, r, h))
        ci = 1.96 * math.sqrt(max(p_mod * (1 - p_mod), 1e-9) / n)
        rec = dict(env=env, fc_ghz=fc, h_m=h, d2d_m=r, n=n,
                   plos_model=round(p_mod, 4), plos_emp=round(p_emp, 4),
                   plos_ok=abs(p_emp - p_mod) <= max(ci, 0.02))
        for st, mask in (("LOS", los), ("NLOS", ~los)):
            if mask.sum() < 8:
                rec[f"plbias_{st}"] = rec[f"sfratio_{st}"] = float("nan")
                continue
            pl_s = np.array([g["pl_db"] for g in grp])[mask]
            sf_s = np.array([g["sf_db"] for g in grp])[mask]
            pl_m = (uc.pl_los_aerial(env, r, h, fc) if st == "LOS"
                    else uc.pl_nlos_aerial(env, r, h, fc))
            sig_m = uc.sf_std_aerial(env, h, st)
            rec[f"plbias_{st}"] = round(float(np.median(pl_s)) - float(pl_m), 3)
            rec[f"sfratio_{st}"] = round(float(np.std(sf_s, ddof=1)) / sig_m, 3)
            if env in ("UMa", "RMa"):
                ds_s = np.array([g["ds_ns"] for g in grp])[mask]
                mu = uc.lsp_alt2(env, h, st)["lgDS"][0]
                rec[f"dsbias_dex_{st}"] = round(
                    float(np.median(np.log10(ds_s * 1e-9))) - mu, 3)
        out.append(rec)
    if report_path:
        keys = sorted({k for r in out for k in r}, key=lambda k: k != "env")
        with open(report_path, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            w.writerows(out)
    return out


if __name__ == "__main__":
    src = sys.argv[1] if len(sys.argv) > 1 else "quadriga_samples.csv"
    dst = sys.argv[2] if len(sys.argv) > 2 else "quadriga_report.csv"
    rep = compare(src, dst)
    bad = [r for r in rep if not r["plos_ok"]]
    print(f"{len(rep)} cells compared; P_LoS outside CI in {len(bad)}")
    print(f"report written to {dst}")
