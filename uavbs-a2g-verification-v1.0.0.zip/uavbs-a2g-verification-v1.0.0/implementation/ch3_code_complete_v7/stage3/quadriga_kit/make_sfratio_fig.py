"""Figure: observed LoS sigma_SF ratio (QuaDRiGa terrestrial / aerial model)
vs altitude, with the predicted curves overlaid. Chapter style: Okabe-Ito,
serif, recessive axes."""
import csv, math, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

import os as _os
_HERE = _os.path.dirname(_os.path.abspath(__file__))
sys.path.insert(0, _os.path.join(_HERE, '../../stage2'))
import uav_channel as uc

plt.rcParams.update({
    'font.family': 'serif', 'font.serif': ['DejaVu Serif'],
    'font.size': 8.5, 'axes.labelsize': 9, 'axes.titlesize': 9,
    'legend.fontsize': 7.5, 'xtick.labelsize': 8, 'ytick.labelsize': 8,
    'axes.linewidth': 0.6, 'xtick.major.width': 0.6, 'ytick.major.width': 0.6,
    'axes.spines.top': False, 'axes.spines.right': False,
    'mathtext.fontset': 'dejavuserif',
})

C = {'UMa': '#0072B2', 'UMi': '#D55E00', 'RMa': '#009E73'}   # Okabe-Ito, fixed order
MK = {'UMa': 'o', 'UMi': 's', 'RMa': '^'}                    # shape = secondary encoding
DODGE = {'UMa': -5.0, 'UMi': 0.0, 'RMa': 5.0}

_report = sys.argv[1] if len(sys.argv) > 1 else _os.path.join(_HERE, 'report_executed_2026-08.csv')
rows = list(csv.DictReader(open(_report)))
obs = {e: {} for e in C}
for r in rows:
    v = r['sfratio_LOS']
    if v in ('', 'nan'):
        continue
    obs[r['env']].setdefault(float(r['h_m']), []).append(float(v))

fig, ax = plt.subplots(figsize=(5.1, 3.25))

# reference: agreement line
ax.axhline(1.0, color='0.45', lw=0.8, ls=(0, (4, 3)), zorder=1)
ax.text(311, 1.0, 'ratio = 1\n(agreement)', fontsize=7, color='0.35',
        va='center', ha='left')

hgrid = np.linspace(25, 305, 400)

# predicted curves: terrestrial sigma (38.901) / aerial sigma(h)
for e, terr in (('UMa', 4.0), ('UMi', 4.0)):
    pred = [terr / uc.sf_std_aerial(e, h, 'LOS') for h in hgrid]
    ax.plot(hgrid, pred, color=C[e], lw=1.6, zorder=3)
# RMa: dual-slope terrestrial sigma 4-6 dB -> band
lo = [4.0 / uc.sf_std_aerial('RMa', h, 'LOS') for h in hgrid]
hi = [6.0 / uc.sf_std_aerial('RMa', h, 'LOS') for h in hgrid]
ax.fill_between(hgrid, lo, hi, color=C['RMa'], alpha=0.16, lw=0, zorder=2)
ax.plot(hgrid, lo, color=C['RMa'], lw=1.0, zorder=3)
ax.plot(hgrid, hi, color=C['RMa'], lw=1.0, ls=(0, (5, 2)), zorder=3)

# observed scatter (every populated cell: all ranges, both carriers)
for e in ('UMa', 'UMi', 'RMa'):
    xs, ys = [], []
    for h, vals in obs[e].items():
        xs += [h + DODGE[e]] * len(vals)
        ys += vals
    ax.scatter(xs, ys, s=13, marker=MK[e], facecolor=C[e], edgecolor='white',
               linewidth=0.4, alpha=0.85, zorder=4)

# direct labels at right edge
ax.text(268, 6.05, 'UMa', color=C['UMa'], fontsize=8, fontweight='bold')
ax.text(255, 4.35, 'RMa', color=C['RMa'], fontsize=8, fontweight='bold')
ax.text(268, 2.22, 'UMi', color=C['UMi'], fontsize=8, fontweight='bold')

# annotation: UMi floor plateau
ax.annotate('UMi plateau at 2.0: aerial $\\sigma$ floors at 2 dB',
            xy=(175, 1.92), xytext=(97, 0.38), fontsize=7, color='0.25',
            arrowprops=dict(arrowstyle='-', color='0.45', lw=0.6))

legend_items = [
    plt.Line2D([], [], color=C[e], marker=MK[e], lw=1.6, markersize=4.5,
               markerfacecolor=C[e], markeredgecolor='white', markeredgewidth=0.4,
               label={'UMa': 'UMa  obs. / predicted 4 dB/$\\sigma(h)$',
                      'UMi': 'UMi  obs. / predicted 4 dB/$\\sigma(h)$',
                      'RMa': 'RMa  obs. / predicted 4–6 dB/$\\sigma(h)$'}[e])
    for e in ('UMa', 'UMi', 'RMa')]
ax.legend(handles=legend_items, loc='upper left', frameon=False,
          handlelength=1.9, borderaxespad=0.1)

ax.set_xlabel('UAV altitude $h$ [m]')
ax.set_ylabel('LoS shadow-fading ratio  $\\hat{\\sigma}_{\\mathrm{QuaDRiGa}}/\\sigma_{\\mathrm{model}}(h)$')
ax.set_xlim(15, 352)
ax.set_ylim(0, 7.05)
ax.set_xticks([30, 50, 100, 150, 200, 300])
ax.grid(axis='y', color='0.9', lw=0.5, zorder=0)
ax.set_axisbelow(True)

fig.tight_layout(pad=0.4)
for out in (_os.path.join(_HERE, 'fig_quadriga_sfratio.png'),):
    fig.savefig(out, dpi=300)
print('saved')
