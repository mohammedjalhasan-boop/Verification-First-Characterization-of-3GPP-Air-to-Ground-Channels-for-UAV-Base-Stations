"""Quantitative literature comparison for Chapter 3, Part II.

Three computed analyses (all under the verified Stage-2 model as ground truth):

 A. Elevation-angle sufficiency test. Al-Hourani-type models assume
    P_LoS = f(elevation angle) only. TR 36.777 is (d2D, h)-dependent; we
    quantify how far the standardised model departs from any pure-elevation
    law, and fit/overlay the classical sigmoid.
 B. P_LoS discrepancy statistics 3GPP vs sigmoid (RMSD, max, where).
 C. Model-induced ALTITUDE-POLICY REGRET: the altitude each simplified model
    recommends, evaluated under the standardised channel. This turns "model
    fidelity matters" (research question RQ1 of the dissertation) into
    numbers.

Sigmoid parameters (a, b) per Al-Hourani, Kandeepan, Lardner, "Optimal LAP
Altitude for Maximum Coverage," IEEE WCL 2014, as commonly reproduced:
urban (9.61, 0.16); suburban (4.88, 0.43); dense urban (12.08, 0.11);
mean excess losses (eta_LoS, eta_NLoS) urban = (1, 20) dB.
[VERIFY: cross-check these four constants against the original paper before
journal submission -- transcribed from the secondary literature.]
"""
import csv
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "stage2"))
import uav_channel as uc

OUT = os.path.dirname(os.path.abspath(__file__))

AH = {"urban": (9.61, 0.16), "suburban": (4.88, 0.43),
      "dense_urban": (12.08, 0.11)}
ETA_URBAN = (1.0, 20.0)          # (eta_LoS, eta_NLoS) [dB]
H_G = 1.5


def elev_deg(r, h):
    return np.degrees(np.arctan2(np.asarray(h, float) - H_G, r))


def plos_ah(theta_deg, kind="urban"):
    a, b = AH[kind]
    return 1.0 / (1.0 + a * np.exp(-b * (np.asarray(theta_deg, float) - a)))


# ---------- A. elevation-sufficiency violation -------------------------------
print("== A. elevation-angle sufficiency (UMa-AV) ==")
rows_a = []
for theta in (15.0, 30.0, 45.0, 60.0):
    vals = []
    for r in (50.0, 100.0, 200.0, 500.0, 1000.0):
        h = H_G + r * np.tan(np.radians(theta))
        if 22.5 < h <= 300.0:
            vals.append((r, float(uc.plos_aerial("UMa", r, h))))
    if len(vals) >= 2:
        spread = max(v for _, v in vals) - min(v for _, v in vals)
        rows_a.append(dict(theta_deg=theta,
                           n_ranges=len(vals),
                           plos_min=round(min(v for _, v in vals), 3),
                           plos_max=round(max(v for _, v in vals), 3),
                           spread=round(spread, 3),
                           sigmoid_urban=round(float(plos_ah(theta)), 3)))
        print(f"  theta={theta:4.0f} deg: 3GPP P_LoS in "
              f"[{rows_a[-1]['plos_min']:.3f},{rows_a[-1]['plos_max']:.3f}] "
              f"across ranges (spread {spread:.3f}); sigmoid(urban) = "
              f"{rows_a[-1]['sigmoid_urban']:.3f}")

# ---------- B. discrepancy statistics ---------------------------------------
print("== B. P_LoS discrepancy 3GPP UMa-AV vs sigmoid(urban) ==")
r = np.linspace(50, 1000, 96)
h = np.linspace(23, 300, 112)
R, H = np.meshgrid(r, h)
p3 = uc.plos_aerial("UMa", R, H)
pa = plos_ah(elev_deg(R, H))
d = p3 - pa
i = np.unravel_index(np.argmax(np.abs(d)), d.shape)
stats_b = dict(rmsd=round(float(np.sqrt(np.mean(d ** 2))), 4),
               bias=round(float(np.mean(d)), 4),
               max_abs=round(float(np.abs(d).max()), 4),
               at_h=round(float(H[i]), 1), at_r=round(float(R[i]), 1),
               at_theta=round(float(elev_deg(R[i], H[i])), 1))
print(f"  RMSD={stats_b['rmsd']}, bias={stats_b['bias']}, "
      f"max|diff|={stats_b['max_abs']} at h={stats_b['at_h']} m, "
      f"r={stats_b['at_r']} m (theta={stats_b['at_theta']} deg)")

# ---------- C. altitude-policy regret ---------------------------------------
print("== C. model-induced altitude-policy regret (evaluated under 3GPP) ==")


def h_ah_opt(r_cell, fc, lo=23.0, hi=300.0):
    """Altitude minimising the Al-Hourani mean path loss at range r_cell."""
    hh = np.arange(lo, hi, 0.25)
    d3 = np.hypot(r_cell, hh - H_G)
    p = plos_ah(elev_deg(r_cell, hh))
    pl = uc.fspl(d3, fc) + ETA_URBAN[0] * p + ETA_URBAN[1] * (1 - p)
    return float(hh[int(np.argmin(pl))])


rows_c = []
for fc, lmax_list in ((3.5, (102.0, 105.0, 108.0)), (28.0, (115.0, 120.0))):
    for r_cell in (200.0, 500.0):
        for lm in lmax_list:
            res = uc.h_star("UMa", r_cell, fc, lm)
            h3 = res["h_plateau_lo"] if res["regime"] in ("plateau",) \
                else res["h_star"]
            h_fs = 23.0                       # FSPL logic: minimise d3D
            h_ah = h_ah_opt(r_cell, fc)
            pc = {name: float(uc.p_cov("UMa", r_cell, hh, fc, lm))
                  for name, hh in (("3gpp", h3), ("ah", h_ah),
                                   ("fspl", h_fs))}
            rows_c.append(dict(fc_ghz=fc, d2d_m=r_cell, l_max_db=lm,
                               h_3gpp=round(h3, 1), h_ah=round(h_ah, 1),
                               h_fspl=h_fs,
                               pcov_at_h3gpp=round(pc["3gpp"], 4),
                               pcov_at_hah=round(pc["ah"], 4),
                               pcov_at_hfspl=round(pc["fspl"], 4),
                               regret_ah=round(pc["3gpp"] - pc["ah"], 4),
                               regret_fspl=round(pc["3gpp"] - pc["fspl"], 4)))
            print(f"  fc={fc:4.1f} r={r_cell:5.0f} Lmax={lm:5.1f}: "
                  f"h*(3GPP)={h3:6.1f}  h*(AH)={h_ah:6.1f}  "
                  f"regret AH={rows_c[-1]['regret_ah']:+.4f}  "
                  f"FSPL={rows_c[-1]['regret_fspl']:+.4f}")

with open(os.path.join(OUT, "lit_comparison.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows_c[0].keys()))
    w.writeheader()
    w.writerows(rows_c)
with open(os.path.join(OUT, "elev_sufficiency.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows_a[0].keys()))
    w.writeheader()
    w.writerows(rows_a)
print("csv written; B-stats:", stats_b)

# ---------- figure f7 --------------------------------------------------------
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

S1, S2, S3 = "#2a78d6", "#eb6834", "#1baf7a"
SURFACE, INK, INK2, MUTED = "#fcfcfb", "#0b0b0b", "#52514e", "#898781"
GRID, BASE = "#e1e0d9", "#c3c2b7"
plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE,
    "savefig.facecolor": SURFACE, "font.family": "DejaVu Sans",
    "axes.edgecolor": BASE, "axes.labelcolor": INK2, "axes.linewidth": 1.0,
    "xtick.color": MUTED, "ytick.color": MUTED, "xtick.labelsize": 9,
    "ytick.labelsize": 9, "axes.titlesize": 10.5, "axes.titlecolor": INK,
    "axes.labelsize": 9.5, "grid.color": GRID, "grid.linewidth": 0.8,
    "legend.frameon": False, "legend.fontsize": 9, "lines.linewidth": 2.0})
fig, ax = plt.subplots(figsize=(7.0, 4.0))
th = np.linspace(2, 80, 300)
for r_c, c in ((100.0, S1), (500.0, S2)):
    hh = H_G + r_c * np.tan(np.radians(th))
    m = (hh > 22.5) & (hh <= 300)
    ax.plot(th[m], uc.plos_aerial("UMa", r_c, hh[m]), color=c,
            label=f"TR 36.777 UMa-AV, $d_{{2D}}$={r_c:.0f} m")
ax.plot(th, plos_ah(th), color=S3, ls="--",
        label="Al-Hourani sigmoid (urban)")
ax.spines[["top", "right"]].set_visible(False)
ax.grid(True, alpha=0.9)
ax.set_axisbelow(True)
ax.set_xlabel("elevation angle $\\theta$ [deg]")
ax.set_ylabel("$P_{LoS}$")
ax.set_title("Elevation-angle sufficiency fails for the standardised model:\n"
             "one sigmoid cannot represent both ranges")
ax.legend(loc="lower right")
fig.tight_layout()
fig.savefig(os.path.join(OUT, "f7_ah_comparison.png"), dpi=150,
            bbox_inches="tight")
print("figure f7 written")
