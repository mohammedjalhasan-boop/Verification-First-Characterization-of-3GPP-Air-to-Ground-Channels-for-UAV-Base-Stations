#!/usr/bin/env bash
# Build the two TikZ figures of the article (Fig. 1 system model, Fig. 2
# pipeline) and the ORCID icon with pdflatex (TeX Live 2023 or later with
# tikz, preview, times/helvet). Each source is a standalone document that
# crops itself to the drawing; the outputs are copied to ../figs with the
# file names the article source uses.
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
for f in fig_sysmodel fig_pipeline orcid_icon; do
  pdflatex -interaction=nonstopmode "$f.tex" > /dev/null
done
mkdir -p ../figs
cp fig_sysmodel.pdf ../figs/channel_model_cropped.pdf
cp fig_pipeline.pdf ../figs/fig_pipeline.pdf
cp orcid_icon.pdf   ../figs/orcid.pdf
rm -f fig_sysmodel.{aux,log} fig_pipeline.{aux,log} orcid_icon.{aux,log}
echo "built channel_model_cropped.pdf, fig_pipeline.pdf, orcid.pdf"
