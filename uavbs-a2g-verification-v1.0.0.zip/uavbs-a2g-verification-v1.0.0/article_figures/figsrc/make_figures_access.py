"""Journal-quality figure regeneration for the IEEE Access article.

Every data figure is regenerated from the FROZEN, 48-check-verified
`uav_channel` package (ch3_code_complete_v7) -- single source of truth.
Data recipes mirror the pack's own figure scripts exactly:
  stage2/scripts/make_figures.py      (plos, map, bimodal)
  stage3/scripts/make_figures3.py     (cdf, bracket, robust)
  stage3/quadriga_kit/make_sfratio_fig.py (sfratio)
  discussion/lit_comparison.py        (ah)
Oct 2026: altitude symbol renamed h_UT -> h_ABS and h_G -> h_GU in all
labels (supervisor's notation); the shipped PDFs carry the new labels
via figsrc/relabel_hABS.py until the pack is re-run with this script.
Changes are PRESENTATION ONLY: vector PDF output (fonttype 42, no
Type-3), exact journal sizing (3.45 in column / 7.05 in text width),
8-9 pt serif fonts, no in-figure titles (captions identify), Okabe-Ito
palette with fixed entity->color mapping (UMa blue, UMi vermillion,
RMa green; slot order reused for non-environment series), marker shape
as secondary encoding, recessive grid.

Run the 48-check suite before this script (environment certificate).
Usage: python3 make_figures_access.py   (writes ../figs/*.pdf)
"""
import csv
import os
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ARCHIVE PATH (Oct. 2026): the pack is resolved relative to this file, or
# from the CH3_PACK environment variable.
_HERE = os.path.dirname(os.path.abspath(__file__))
PACK = os.environ.get("CH3_PACK", os.path.normpath(os.path.join(
    _HERE, "..", "..", "implementation", "ch3_code_complete_v7")))
sys.path.insert(0, os.path.join(PACK, "stage2"))
sys.path.insert(0, os.path.join(PACK, "stage3"))
import uav_channel as uc                      # noqa: E402
from uav_channel import params as P           # noqa: E402
from analysis import validation as V          # noqa: E402
from analysis import fr2_sensitivity as F     # noqa: E402

OUT = os.environ.get("FIG_OUT", os.path.join(_HERE, "..", "figs"))
os.makedirs(OUT, exist_ok=True)

# ---- palette: Okabe-Ito, validated (dataviz six checks, light mode) ----
BLUE, VERM, GREEN, SKY = "#0072B2", "#D55E00", "#009E73", "#56B4E9"
ENVC = {"UMa": BLUE, "UMi": VERM, "RMa": GREEN}      # fixed entity map
ENVM = {"UMa": "o", "UMi": "s", "RMa": "^"}          # shape = 2nd encoding
SLOT = [BLUE, VERM, GREEN]                            # fixed slot order
INK, INK2, MUTED, GRID = "#111111", "#444444", "#777777", "#e2e2e2"

COL_W, TEXT_W = 3.45, 7.05                            # inches (Access)

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["DejaVu Serif"],
    "mathtext.fontset": "dejavuserif",
    "font.size": 8, "axes.labelsize": 8.5, "legend.fontsize": 7.5,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5,
    "axes.linewidth": 0.6, "xtick.major.width": 0.6,
    "ytick.major.width": 0.6, "axes.edgecolor": "#999999",
    "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
    "axes.spines.top": False, "axes.spines.right": False,
    "grid.color": GRID, "grid.linewidth": 0.5,
    "legend.frameon": False, "lines.linewidth": 1.4,
    "pdf.fonttype": 42, "savefig.dpi": 600,
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.facecolor": "white"})


def style(ax):
    ax.grid(True, alpha=0.85)
    ax.set_axisbelow(True)


def tag(ax, s, x=0.03, y=0.94, ha="left"):
    ax.text(x, y, s, transform=ax.transAxes, fontsize=8, color=INK,
            ha=ha, va="top", fontweight="bold")


def save(fig, name):
    fig.savefig(os.path.join(OUT, name), bbox_inches="tight",
                pad_inches=0.02)
    plt.close(fig)
    print("wrote", name)


# ============================================================ fig_plos
# recipe: stage2 make_figures.py F1 (verbatim data calls)
fig, axes = plt.subplots(1, 3, figsize=(TEXT_W, 2.05), sharey=True)
for k, (ax, env) in enumerate(zip(axes, P.ENVS)):
    lo, hi = P.AERIAL_PLOS[env]["band"]
    h = np.linspace(lo + 0.01, 300, 1200)
    for (r, c) in ((100, SLOT[0]), (200, SLOT[1]), (500, SLOT[2])):
        ax.plot(h, uc.plos_aerial(env, float(r), h), color=c,
                label=f"$d_\\mathrm{{2D}}$ = {r} m")
    style(ax)
    tag(ax, f"({'abc'[k]}) {env}-AV", x=0.5, y=0.13, ha="center")
    ax.set_xlabel("UAV altitude $h_\\mathrm{ABS}$ [m]")
    ax.set_xlim(0, 305)
axes[0].set_ylim(0.18, 1.04)
axes[0].set_ylabel("$P_\\mathrm{LoS}$")
axes[0].legend(loc="center left", handlelength=1.6,
               bbox_to_anchor=(0.02, 0.42))
fig.subplots_adjust(wspace=0.08)
save(fig, "fig_plos.pdf")

# ============================================================ fig_map
# recipe: stage2 make_figures.py F3 (verbatim data calls)
fig, ax = plt.subplots(figsize=(COL_W, 2.75))
r = np.linspace(18, 1000, 800)
rr = np.arange(50, 1001, 50)
for env in ("UMa", "UMi", "RMa"):
    c = ENVC[env]
    ax.plot(r, uc.h_wall(env, r), color=c, lw=1.5)
    hs = [uc.h_star_refined(env, float(x), 3.5, 120.0)["h_plateau_lo"]
          for x in rr]
    ax.plot(rr, hs, ENVM[env], ms=3.6, mfc="none", mec=c, mew=1.0)
# direct labels (entity), neutral legend (geometry vs. solver)
ax.text(660, 315, "UMi-AV", color=ENVC["UMi"], fontsize=8,
        fontweight="bold")
ax.text(660, 122, "UMa-AV", color=ENVC["UMa"], fontsize=8,
        fontweight="bold")
ax.text(660, 55, "RMa-AV", color=ENVC["RMa"], fontsize=8,
        fontweight="bold")
from matplotlib.lines import Line2D
ax.legend(handles=[
    Line2D([], [], color=INK2, lw=1.5, label="closed-form wall $h_1(r)$"),
    Line2D([], [], color=INK2, marker="o", ls="none", mfc="none",
           ms=4, label="solver optimum (energy-pref.)")],
    loc="lower left", bbox_to_anchor=(-0.02, 1.0), ncols=2,
    columnspacing=1.1, handletextpad=0.5, borderaxespad=0.0)
style(ax)
ax.set_xlabel("horizontal range $d_\\mathrm{2D}$ [m]")
ax.set_ylabel("altitude [m]")
ax.set_ylim(0, 340)
save(fig, "fig_map.pdf")

# ============================================================ fig_bimodal
# recipe: stage2 make_figures.py F4 (verbatim data calls)
fig, ax = plt.subplots(figsize=(COL_W, 2.45))
h = np.arange(22.6, 300, 0.1)
for lm, c in ((115.0, SLOT[0]), (120.0, SLOT[1]), (125.0, SLOT[2])):
    ax.plot(h, uc.p_cov("UMa", 500.0, h, 28.0, lm), color=c,
            label=f"$L_\\mathrm{{max}}$ = {lm:.0f} dB")
ax.axvline(100.0, color=MUTED, lw=0.8, ls=":")
ax.annotate("$P_\\mathrm{LoS}$ jump\nat $h_\\mathrm{sat}$ = 100 m",
            xy=(100, 0.58), xytext=(150, 0.60), color=INK2, fontsize=7.5,
            arrowprops=dict(arrowstyle="->", color=MUTED, lw=0.8))
style(ax)
ax.set_xlabel("UAV altitude $h_\\mathrm{ABS}$ [m]")
ax.set_ylabel("$P_\\mathrm{cov}$")
ax.legend(loc="center right", bbox_to_anchor=(1.0, 0.30),
          handlelength=1.6)
save(fig, "fig_bimodal.pdf")

# ============================================================ fig_bracket
# recipe: stage3 make_figures3.py g5 (verbatim data calls)
fig, axes = plt.subplots(1, 2, figsize=(TEXT_W, 2.3), sharey=True)
r = np.linspace(50, 1000, 400)
for k, (ax, hh) in enumerate(zip(axes, (30.0, 100.0))):
    m0 = uc.pl_nlos_aerial("UMa", r, hh, 28.0)
    rf = F.ref_nlos("UMa", r, hh, 28.0)
    ax.fill_between(r, m0, rf, color=SKY, alpha=0.22, lw=0)
    ax.plot(r, m0, color=BLUE,
            label="M0: TR 36.777 aerial NLoS (extrapolated)")
    ax.plot(r, rf, color=VERM,
            label="REF: TR 38.901 FR2-valid NLoS")
    ax.plot(r, uc.fspl(uc.d3d(r, hh), 28.0), color=MUTED, lw=0.9,
            ls=":", label="free space")
    style(ax)
    tag(ax, f"({'ab'[k]}) $h_\\mathrm{{ABS}}$ = {hh:.0f} m", x=0.04,
        y=0.94)
    ax.set_xlabel("$d_\\mathrm{2D}$ [m]")
axes[0].set_ylabel("path loss [dB]")
axes[0].legend(loc="lower right", handlelength=1.6)
fig.subplots_adjust(wspace=0.06)
save(fig, "fig_bracket.pdf")

# ============================================================ fig_robust
# recipe: stage3 make_figures3.py g6 (verbatim data + jitter seed)
rows = [x for x in csv.DictReader(
        open(os.path.join(PACK, "stage3", "out3", "fr2_hstar_shift.csv")))
        if x["meaningful"] == "True"]
fig, ax = plt.subplots(figsize=(COL_W, 2.35))
rng = np.random.default_rng(1)
for env in ("UMa", "UMi", "RMa"):
    xs = [float(x["l_max_db"]) + rng.uniform(-0.9, 0.9) for x in rows
          if x["env"] == env]
    ys = [float(x["shift_policy_m"]) for x in rows if x["env"] == env]
    ax.plot(xs, ys, ENVM[env], ms=4, mfc="none", mec=ENVC[env], mew=1.1,
            label=f"{env}-AV")
ax.axhline(0, color="#bbbbbb", lw=0.8)
style(ax)
ax.set_xlabel("link budget $L_\\mathrm{max}$ [dB]")
ax.set_ylabel("altitude shift [m] (REF $-$ M0)")
ax.legend(loc="upper left", handlelength=1.2, ncols=1)
save(fig, "fig_robust.pdf")

# ============================================================ fig_ah
# recipe: discussion/lit_comparison.py part D (verbatim data calls)
H_GU = 1.5
AH_URBAN = (9.61, 0.16)


def plos_ah(theta_deg):
    a, b = AH_URBAN
    return 1.0 / (1.0 + a * np.exp(-b * (np.asarray(theta_deg, float) - a)))


fig, ax = plt.subplots(figsize=(COL_W, 2.45))
th = np.linspace(2, 80, 300)
for r_c, c in ((100.0, SLOT[0]), (500.0, SLOT[1])):
    hh = H_GU + r_c * np.tan(np.radians(th))
    m = (hh > 22.5) & (hh <= 300)
    ax.plot(th[m], uc.plos_aerial("UMa", r_c, hh[m]), color=c,
            label=f"TR 36.777 UMa-AV, $d_\\mathrm{{2D}}$ = {r_c:.0f} m")
ax.plot(th, plos_ah(th), color=SLOT[2], ls="--",
        label="Al-Hourani sigmoid (urban)")
style(ax)
ax.set_xlabel("elevation angle $\\theta$ [deg]")
ax.set_ylabel("$P_\\mathrm{LoS}$")
ax.legend(loc="lower right", handlelength=1.7)
save(fig, "fig_ah.pdf")

# ============================================================ fig_cdf
# recipe: stage3 make_figures3.py g2 (verbatim data calls, rng=23)
cases = (("UMa", 100.0, 300.0), ("UMi", 150.0, 300.0),
         ("RMa", 30.0, 500.0))
fig, axes = plt.subplots(1, 3, figsize=(TEXT_W, 2.0), sharey=True)
for k, (ax, (env, h, r)) in enumerate(zip(axes, cases)):
    x = V.sample_effective_pl(env, r, h, 3.5, 120_000, rng=23)
    xs = np.sort(x)
    ax.plot(xs, np.arange(1, xs.size + 1) / xs.size, color=VERM, lw=2.2,
            label="Monte-Carlo")
    xg = np.linspace(xs[0] - 2, xs[-1] + 2, 500)
    ax.plot(xg, V.mixture_cdf(env, r, h, 3.5, xg), color=BLUE, lw=1.0,
            label="analytic mixture")
    ks = V.ks_effective_pl(env, r, h, 3.5, n=120_000, rng=23)
    ax.text(0.035, 0.86, f"KS $D$ = {ks['ks_D']:.4f}\n$p$ = "
            f"{ks['ks_p']:.2f}", transform=ax.transAxes, color=INK2,
            fontsize=7, va="top")
    style(ax)
    tag(ax, f"({'abc'[k]}) {env}-AV", x=0.96, y=0.50, ha="right")
    ax.set_xlabel("effective PL = PL + $X_\\sigma$ [dB]")
axes[0].set_ylabel("CDF")
axes[2].legend(loc="lower right", handlelength=1.6)
fig.subplots_adjust(wspace=0.07)
save(fig, "fig_cdf.pdf")

# ============================================================ fig_sfratio
# recipe: stage3/quadriga_kit/make_sfratio_fig.py (verbatim data)
C = ENVC
MK = ENVM
DODGE = {"UMa": -5.0, "UMi": 0.0, "RMa": 5.0}
# ARCHIVE PATH (Oct. 2026): Fig. 4 now plots the 270-cell report (FR1 +
# FR2 blocks), produced by the pack comparator from the raw campaign files.
report = os.environ.get("CAMPAIGN_REPORT", os.path.normpath(os.path.join(
    _HERE, "..", "..", "campaign", "pack_comparator",
    "report_executed_all_2026-10.csv")))
rows = list(csv.DictReader(open(report)))
obs = {e: {} for e in C}
for x in rows:
    v = x["sfratio_LOS"]
    if v in ("", "nan"):
        continue
    obs[x["env"]].setdefault(float(x["h_m"]), []).append(float(v))

fig, ax = plt.subplots(figsize=(COL_W, 2.8))
ax.axhline(1.0, color="0.45", lw=0.7, ls=(0, (4, 3)), zorder=1)
ax.text(108, 1.12, "ratio = 1 (agreement)", fontsize=6.8,
        color="0.35", ha="left")
hgrid = np.linspace(25, 305, 400)
for e, terr in (("UMa", 4.0), ("UMi", 4.0)):
    pred = [terr / uc.sf_std_aerial(e, h, "LOS") for h in hgrid]
    ax.plot(hgrid, pred, color=C[e], lw=1.3, zorder=3)
lo = [4.0 / uc.sf_std_aerial("RMa", h, "LOS") for h in hgrid]
hi = [6.0 / uc.sf_std_aerial("RMa", h, "LOS") for h in hgrid]
ax.fill_between(hgrid, lo, hi, color=C["RMa"], alpha=0.16, lw=0, zorder=2)
ax.plot(hgrid, lo, color=C["RMa"], lw=0.9, zorder=3)
ax.plot(hgrid, hi, color=C["RMa"], lw=0.9, ls=(0, (5, 2)), zorder=3)
for e in ("UMa", "UMi", "RMa"):
    xs, ys = [], []
    for h, vals in obs[e].items():
        xs += [h + DODGE[e]] * len(vals)
        ys += vals
    ax.scatter(xs, ys, s=11, marker=MK[e], facecolor=C[e],
               edgecolor="white", linewidth=0.4, alpha=0.85, zorder=4)
ax.annotate("UMa", xy=(213, 3.52), xytext=(148, 4.35),
            color=C["UMa"], fontsize=8, fontweight="bold",
            arrowprops=dict(arrowstyle="-", color=C["UMa"], lw=0.7))
ax.text(258, 4.42, "RMa", color=C["RMa"], fontsize=8, fontweight="bold")
ax.text(258, 2.28, "UMi", color=C["UMi"], fontsize=8, fontweight="bold")
style(ax)
ax.set_xlim(15, 315)
ax.set_xlabel("UAV altitude $h_\\mathrm{ABS}$ [m]")
ax.set_ylabel("$\\hat{\\sigma}_\\mathrm{QuaDRiGa}/\\sigma(h_\\mathrm{ABS})$"
              " (LoS)")
save(fig, "fig_sfratio.pdf")

print("all figures regenerated from the verified pack")
