"""IEEE Access graphical abstract: geometry -> landscape -> verification.
All quantitative content from the frozen verified package (via explorer JSON)."""
import json, math, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch, FancyBboxPatch, Circle, Wedge

import os as _os
_HERE = _os.path.dirname(_os.path.abspath(__file__))
# ARCHIVE PATH (Oct. 2026): pack resolved relative to this file or CH3_PACK.
_PACK = _os.environ.get('CH3_PACK', _os.path.normpath(_os.path.join(
    _HERE, '..', '..', 'implementation', 'ch3_code_complete_v7')))
sys.path.insert(0, _os.path.join(_PACK, 'stage2'))
import uav_channel as uc

D = json.load(open(_os.path.join(_HERE, 'data.json')))
H, R = D['h'], D['r']
key = 'UMa|2.6|120'
PC = np.array(D['data'][key]['pcov'])          # [r][h]
stats = D['data'][key]['stats']
wall = D['wall']['UMa']

plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans'],
                     'axes.linewidth':0.7})
INK, INK2, MUT = '#1a1f26', '#39424c', '#8a939e'
BLUE, VERM, GREEN = '#0072B2', '#D55E00', '#009E73'

fig = plt.figure(figsize=(12.4, 5.9), dpi=150)
fig.patch.set_facecolor('white')

# ---------------- title band ----------------
fig.text(0.012, 0.965, 'Verification-First Characterization of 3GPP Air-to-Ground Channels '
         'for UAV Base Stations', fontsize=15.5, fontweight='bold', color=INK, va='top')
fig.text(0.012, 0.905, '48 automated checks  ·  executed QuaDRiGa cross-validation (13,500 links)  ·  '
         'decision-aware coverage results', fontsize=11, color=INK2, va='top')

# ---------------- Panel A: geometry ----------------
axA = fig.add_axes([0.012, 0.055, 0.29, 0.66]); axA.set_xlim(0, 10); axA.set_ylim(0, 10); axA.axis('off')
axA.set_title('Standardized aerial channel\nTR 36.777 over TR 38.901', fontsize=11.5,
              color=INK, pad=6, loc='left', fontweight='bold')
# ground + clutter
axA.add_patch(Rectangle((0, 0.8), 10, 0.18, color='#b9c1c9'))
for (x, w, h) in [(0.6,0.9,2.4),(1.8,0.8,3.4),(2.9,1.0,2.0),(4.2,0.85,2.9),(5.4,0.9,2.2)]:
    axA.add_patch(Rectangle((x, 0.98), w, h, color='#d5dbe1'))
# user
ux, uy = 7.9, 1.25
axA.add_patch(Circle((ux, uy+0.32), 0.16, color=INK2))
axA.plot([ux, ux], [uy-0.25, uy+0.18], color=INK2, lw=2.2)
axA.text(ux+0.32, uy-0.05, 'ground user\n$h_\mathrm{GU}$ = 1.5 m', fontsize=9, color=INK2, va='center')
# UAV
vx, vy = 1.55, 8.6
axA.plot([vx-0.42, vx+0.42], [vy, vy], color=INK, lw=2.6)
axA.plot([vx-0.42, vx-0.42], [vy-0.16, vy+0.16], color=INK, lw=2.0)
axA.plot([vx+0.42, vx+0.42], [vy-0.16, vy+0.16], color=INK, lw=2.0)
axA.add_patch(Circle((vx, vy), 0.14, color=BLUE))
axA.text(vx-0.05, vy+0.55, 'UAV-BS at altitude $h$', fontsize=10, color=INK, fontweight='bold')
# slant path
axA.plot([vx, ux], [vy, uy+0.3], color=BLUE, lw=2.0)
axA.plot([vx, ux], [vy, uy+0.3], color=BLUE, lw=6, alpha=0.12)
# elevation angle at user
th = math.degrees(math.atan2(vy-(uy+0.3), ux-vx))
axA.add_patch(Wedge((ux, uy+0.3), 1.05, 180-th, 180, color=BLUE, alpha=0.18))
axA.text(ux-1.9, uy+0.78, r'$\theta$', fontsize=12, color=BLUE)
# LoS/NLoS split note
axA.text(0.25, 3.15, 'LoS / NLoS mixture (Bernoulli,\nper TR 36.777 Table B-1)', fontsize=9, color=INK2, zorder=6)
axA.text(0.25, 4.85, r'$P_{\mathrm{cov}} = P_{\mathrm{LoS}}Q(u_L)$'
                     '\n' r'$\qquad + (1{-}P_{\mathrm{LoS}})\,Q(u_N)$',
         fontsize=11, color=INK,
         bbox=dict(boxstyle='round,pad=0.45', fc='#f3f6f9', ec='#dde3e9'))

# ---------------- Panel B: landscape ----------------
axB = fig.add_axes([0.365, 0.11, 0.275, 0.585])
im = axB.imshow(PC.T, origin='lower', aspect='auto', cmap='Blues',
                extent=[R[0], R[-1], H[0], H[-1]], vmin=0, vmax=1)
axB.plot(R, [min(w, 300) for w in wall], color='white', lw=3, alpha=0.9)
axB.plot(R, [min(w, 300) for w in wall], color=INK, lw=1.3, ls=(0,(5,3)))
hs = [s['hstar'] for s in stats]
axB.plot(R, hs, color=VERM, lw=2.2)
axB.scatter(R, hs, s=14, color=VERM, edgecolor='white', linewidth=0.7, zorder=5)
axB.text(620, 112, 'LoS wall $h_1(r)$', fontsize=9.5, color='white', fontweight='bold')
axB.text(430, 55, 'energy-preferred\noptimum $h^{*}(r)$', fontsize=9.5, color='white', fontweight='bold')
axB.set_xlabel('ground range $r$ [m]', fontsize=10)
axB.set_ylabel('altitude $h$ [m]', fontsize=10)
axB.tick_params(labelsize=8.5)
axB.set_title('Coverage landscape $P_{\\mathrm{cov}}(h,r)$\nwalls, plateaus, regimes — closed form',
              fontsize=11.5, color=INK, pad=6, loc='left', fontweight='bold')
cb = fig.colorbar(im, ax=axB, fraction=0.045, pad=0.02)
cb.ax.tick_params(labelsize=8); cb.set_label('$P_{\\mathrm{cov}}$', fontsize=9)

# ---------------- Panel C: verification stack + audit ----------------
axC = fig.add_axes([0.705, 0.055, 0.285, 0.66]); axC.set_xlim(0, 10); axC.set_ylim(0, 10); axC.axis('off')
axC.set_title('Verified, then externally audited', fontsize=11.5, color=INK,
              pad=6, loc='left', fontweight='bold')
layers = ['5 · Physics invariants', '4 · Statistics (KS, moments)', '3 · Vectorization equivalence',
          '2 · Calculus (analytic vs numeric)', '1 · Transcription vs standard']
for i, name in enumerate(layers):
    y = 8.35 - i*0.92
    axC.add_patch(FancyBboxPatch((0.25, y), 6.05, 0.74, boxstyle='round,pad=0.06',
                                 fc='#eef3f8', ec=BLUE, lw=1.1))
    axC.text(0.55, y+0.37, name, fontsize=9.0, color=INK, va='center')
axC.text(6.95, 6.55, '48\nautomated\nchecks', fontsize=10.5, color=BLUE,
         fontweight='bold', ha='left', va='center')
axC.annotate('', xy=(6.62, 4.35), xytext=(6.62, 8.9),
             arrowprops=dict(arrowstyle='-', color=BLUE, lw=1.2))
# QuaDRiGa audit badge
axC.add_patch(FancyBboxPatch((0.25, 0.35), 9.5, 3.3, boxstyle='round,pad=0.09',
                             fc='#f2faf6', ec=GREEN, lw=1.4))
axC.text(0.62, 3.12, 'External audit — QuaDRiGa 2.8.1 (executed)', fontsize=10.3,
         color='#0b6b4f', fontweight='bold')
axC.text(0.62, 0.72,
         '13,500 links · 270 cells · 3 carriers\n'
         'shared expressions: 0.000 dB UMa LoS identity;\n'
         '435/438 comparisons closed-form to ≤ 0.01 dB\n'
         'divergence = the missing aerial annex, quantified',
         fontsize=9.2, color=INK2, va='bottom', linespacing=1.45)

fig.savefig(_os.path.join(_HERE, 'graphical_abstract_access.png'), dpi=150,
            facecolor='white', bbox_inches='tight', pad_inches=0.12)
fig.savefig(_os.path.join(_HERE, 'graphical_abstract.pdf'),
            facecolor='white', bbox_inches='tight', pad_inches=0.12)
print('saved abstract')
