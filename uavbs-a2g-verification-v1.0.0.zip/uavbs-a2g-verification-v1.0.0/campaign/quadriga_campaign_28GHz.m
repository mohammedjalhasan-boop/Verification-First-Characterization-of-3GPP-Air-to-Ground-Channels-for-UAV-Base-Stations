% QuaDRiGa external-validation campaign for Chapter 3 (flag V5) -- 28-GHz run.
% =========================================================================
% Derived from the pack's quadriga_campaign.m (delivered-unexecuted template).
% Design, geometry, seed handling and the CSV schema are UNCHANGED, so that
% the 28-GHz block goes through the same comparator path (ingest_quadriga.py,
% analyze_report.py) as the FR1 block.  Every change to the template is marked
% "ADAPTATION (QuaDRiGa 2.8.1)" and listed at the end of this header:
%
%   A1  LOS state: qd_builder has no 'los' property in v2.8.1. set_scenario()
%       writes the drawn state into the scenario NAME ('..._LOS' / '..._NLOS'),
%       which is read here from b(1,1).scenario (anchored regexp).
%   A2  Ricean K-factor property is 'kf' (lower case), not 'KF'.
%   A3  Small-scale coefficients are generated from the SAME builder
%       (c = b.get_channels) instead of l.get_channels, which would create a
%       second, independent builder and double the runtime.  No exported
%       column depends on this call (all columns come from b, generated
%       before it); it is kept only so the run exercises the full chain.
%   A4  Output file opened in append mode with a header written once, and a
%       progress line per cell, so an interrupted run can be resumed.
%   A5  Carrier set explicitly to 28.0 GHz; the printed frequency is checked.
%
% Requires: QuaDRiGa 2.8.1-0 (MATLAB).  Record MATLAB version, QuaDRiGa
% version, date, wall time and the SHA-256 of the CSV in the campaign log.
%
% Per-link CSV row (unchanged schema):
%   env,fc_ghz,h_m,d2d_m,seed,los,pl_db,sf_db,ds_ns,asd_deg,asa_deg,
%   zsd_deg,zsa_deg,kf_db
% =========================================================================

clear all; close all;

OUT_CSV   = 'quadriga_samples_28GHz.csv';
N_SEED    = 50;                          % links per (env,fc,h,r) cell
FC_LIST   = 28.0e9;                      % ADAPTATION A5: exactly 28 GHz (n257)
H_LIST    = [30 50 100 150 200 300];     % UAV altitudes [m]      (as FR1)
R_LIST    = [50 100 200 500 1000];       % ground ranges [m]      (as FR1)
H_GROUND  = 1.5;

% ---- scenario configs (38.901 terrestrial configs; no aerial set exists) --
SCEN = struct('UMa','3GPP_38.901_UMa', ...
              'UMi','3GPP_38.901_UMi', ...
              'RMa','3GPP_38.901_RMa');

% ---- ADAPTATION A4: append mode, header once --------------------------------
write_header = ~exist(OUT_CSV,'file');
fid = fopen(OUT_CSV,'a');
if write_header
  fprintf(fid, ['env,fc_ghz,h_m,d2d_m,seed,los,pl_db,sf_db,ds_ns,' ...
                'asd_deg,asa_deg,zsd_deg,zsa_deg,kf_db\n']);
end

t_start = tic;
envs = fieldnames(SCEN);
for ie = 1:numel(envs)
  env = envs{ie};
  for fc = FC_LIST
    for h = H_LIST
      for r = R_LIST
        for seed = 1:N_SEED
          s = qd_simulation_parameters;
          s.center_frequency = fc;
          s.use_random_initial_phase = true;
          s.show_progress_bars = false;                  % quieter log
          rng(seed);                                      % reproducibility (as FR1)

          l = qd_layout(s);
          l.no_tx = 1;
          % Role swap (Stage-1 Assumption T1): aerial node is the "UT" side
          % of the 3GPP model; ground node is the BS/anchor side at 1.5 m.
          l.tx_position = [0; 0; H_GROUND];   % ground node
          l.no_rx = 1;
          l.rx_position = [r; 0; h];          % UAV
          l.set_scenario(SCEN.(env));         % QuaDRiGa draws LOS/NLOS itself

          b = l.init_builder;                 % 1x1 qd_builder (one rx)
          b.gen_parameters;                   % LSPs (sf, ds, kf, spreads) + SSPs
          c = b.get_channels;                 % ADAPTATION A3 (see header)

          % ---- extract quantities --------------------------------------
          scn   = b(1,1).scenario;                          % ADAPTATION A1
          los   = ~isempty(regexp(scn, '_LOS$', 'once'));   % 1 = LOS, 0 = NLOS
          pl_db = b.get_pl;                   % path loss without SF [dB]
          sf_db = 10*log10(b.sf);             % shadow fading [dB], linear->dB
          ds_ns = b.ds * 1e9;                 % RMS delay spread [ns]
          asd   = b.asD; asa = b.asA;         % azimuth spreads [deg]
          zsd   = b.esD; zsa = b.esA;         % elevation spreads [deg]
          kf_db = 10*log10(b.kf);             % ADAPTATION A2: 'kf'

          fprintf(fid, '%s,%.3g,%g,%g,%d,%d,%.3f,%.3f,%.3f,%.4g,%.4g,%.4g,%.4g,%.3f\n', ...
                  env, fc/1e9, h, r, seed, los, pl_db, sf_db, ds_ns, ...
                  asd, asa, zsd, zsa, kf_db);
        end
        fflush_if_possible(fid);
        fprintf('cell done: %s fc=%.1f GHz h=%g m r=%g m  (%.1f min elapsed)\n', ...
                env, fc/1e9, h, r, toc(t_start)/60);
      end
    end
  end
  fprintf('done %s\n', env);
end
fclose(fid);
fprintf('wrote %s in %.1f min\n', OUT_CSV, toc(t_start)/60);

function fflush_if_possible(fid)
  % MATLAB flushes on fclose; this keeps partial output readable on disk.
  try, fflush(fid); catch, end %#ok<CTCH>
end
