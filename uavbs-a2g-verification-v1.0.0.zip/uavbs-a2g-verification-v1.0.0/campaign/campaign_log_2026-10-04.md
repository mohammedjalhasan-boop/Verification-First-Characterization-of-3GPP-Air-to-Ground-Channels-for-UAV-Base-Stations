# External cross-validation campaign — log

## FR1 block (August 2026)
- File: `quadriga_samples_FR1_2026-08.csv` (9,000 rows; 2.6 and 3.5 GHz; UMa/UMi/RMa;
  h = 30, 50, 100, 150, 200, 300 m; r = 50, 100, 200, 500, 1000 m; seeds 1–50).
- Generator: QuaDRiGa v2.8.1-0 under MATLAB R2026a (authors' machine); the pack's
  campaign script (`stage3/quadriga_kit/quadriga_campaign.m`, flag V5) with the
  authors' QuaDRiGa API adaptations.
- Analysis: the pack's `ingest_quadriga.py` / `analyze_report.py` / `mechanism_check.py`
  produced `report_executed_2026-08.csv` (Table 4, FR1 blocks). The independent
  re-analysis `audit_campaign.py` (this folder) reproduces every published FR1
  entry from the raw file (`cell_report_FR1.csv`, `summary_FR1.json`).

## FR2 block (October 4, 2026)
- File: `quadriga_samples_28GHz_2026-10.csv` (4,500 rows; 28.0 GHz; same grid and seeds).
  The authors' upload contained the complete campaign twice (the append-mode script was
  run twice: 48.1 min and 33.2 min wall time); the two blocks are bit-identical and the
  file here is the de-duplicated single block.
- Generator: QuaDRiGa v2.8.1-0 under MATLAB R2026a, student license (authors' machine);
  script `quadriga_campaign_28GHz.m` (this folder) = the pack template with five
  adaptations to QuaDRiGa 2.8.1 listed in its header (LOS state from the scenario
  name; `kf` property; channels from the same builder; append-mode output; carrier
  pinned at 28.0 GHz). Console log reported "fc=28.0 GHz" for every cell.
- Provenance check: the `los`, `sf_db`, `kf_db`, and `zsd_deg` columns of the FR2 rows
  are identical, seed by seed, to the FR1 rows at both FR1 carriers (these quantities do
  not depend on the carrier in TR 38.901), so the adapted script reproduces the August
  pipeline's random-number path exactly; `pl_db`, `ds_ns`, `asd_deg`, `asa_deg`, `zsa_deg`
  differ as the carrier-dependent expressions require.
- Analysis: `audit_campaign.py quadriga_samples_28GHz_2026-10.csv 28GHz` →
  `cell_report_28GHz.csv`, `summary_28GHz.json` (Table 4, FR2 block). The pack's own
  comparator was run on the same file on October 9, 2026 (next section).

## Pack comparator executed on both raw files (October 9, 2026)
- The authors' verified pack (`ch3_code_complete_v7`, zip SHA-256
  `00e013370d4477662a480e330c00f63cd6f025f08f028fcdf222892a108de3be`) was received and its
  three test suites were run (26 + 10 + 12 = 48 checks, all pass; Python 3.11.15, numpy 2.4.4,
  scipy 1.17.1, matplotlib 3.10.9; logs in the public archive under `logs/`).
- `stage3/quadriga_kit/ingest_quadriga.py` was run on `quadriga_samples_FR1_2026-08.csv`
  (-> `pack_comparator/report_regen_FR1.csv`, every value identical to the authors' August
  `report_executed_2026-08.csv`) and on `quadriga_samples_28GHz_2026-10.csv`
  (-> `pack_comparator/report_executed_2026-10.csv`, 90 cells, P_LoS outside the interval in 89).
  The pack's `analyze_report.py` (guarded archive copy) and `mechanism_check.py` were run on both
  reports (`pack_comparator/*.txt`): UMa LoS bias exactly 0.000 dB in all 24 FR2 cells, UMi LoS
  bias equal to the closed form, NLoS gap medians -8.9 / -11.3 / +32.3 dB, delay-spread gaps
  +0.74 dex (UMa NLoS) and +2.42 dex (RMa NLoS), NLoS floor active in 24/30 UMa and 18/30 UMi
  cells with max |predicted - observed| = 0.001 dB. These equal the independent
  `audit_campaign.py` results and the Table 4 FR2 block, which closes the action noted above.
- `pack_comparator/report_executed_all_2026-10.csv` (270 cells = FR1 + FR2) is the source of Fig. 4.
- Hash-manifested pack artifacts (`stage2/out/*`, `stage3/out3/*.csv`, `discussion/lit_comparison.csv`)
  regenerate byte-identically in the same environment.

## SHA-256
9784d07bbbae117c9349c249e2610396b1ff5992c321ad36323b700e3bf60d26  quadriga_samples_FR1_2026-08.csv
6392f2a77b4e4a2f7a31db44e546aae82f9ec7303ec1b071c57b55f0dfb8dc2a  quadriga_samples_28GHz_2026-10.csv
90cd02217d0ccab8dca5ace929eff8162b4e34dd9a3fd91dfc835ef2950b574f  quadriga_campaign_28GHz.m
9e1f11875e959fc3916f7c4a767b043aad386ced028816428cadffd236c0ba09  audit_campaign.py
9c7d04b4853e5323038393999329f23126f0f539392e2eee6efad4d898a41501  cell_report_FR1.csv
c63083cf4e0199bd6b6353fbbdb6216ad7e37d0e850b9e94dbca66bbe2e719e4  cell_report_28GHz.csv
006ceb8cdd19e60b9b4f15683b706e3d6c4944ea36e04e0914c41e62a2d67564  summary_FR1.json
41d50fefd68d635e8bf16b83b2b8124d9562433779303027347b8498d30693a6  summary_28GHz.json
3e5ec54445af098f49fbf69bc652a847994a76d6378ea0e2e06f0250b98cb33e  pack_comparator/analyze_report_FR1.txt
67064583fc6397bc3f4e138fac675ba6aa873df1ac3b6174382b7b7708d978f5  pack_comparator/analyze_report_FR2.txt
270a4045a3abc8ab75a14164cc29f94c0863c0dae8d73444f0da248e7f75a53f  pack_comparator/analyze_report_guarded.py
82e76e5d306ceeb4c75b1bb7ed6367cf1cc39a2f4e9411f70b98a8dc8324123f  pack_comparator/combine_reports.py
f351422a1ecd43b6f00dab5bad904959859990ecd8f6ab250867b3869813267b  pack_comparator/mechanism_check_FR1.txt
83393a8b5299279dd7abace3b1daed9db80138bdd03c4dc6d787695c2d9772f4  pack_comparator/mechanism_check_FR2.txt
3e333c509df83b2a8bac9d8b0c8456a2ff99165d2b50df85a2a0d4d78521ae86  pack_comparator/report_executed_2026-10.csv
5413781772ed1333cf5e2c80074daecca7e1886e228cd9b32b9c1cdcfecdcba6  pack_comparator/report_executed_all_2026-10.csv
ac9ba91fb4559f9c33a2b58096e6460b6a8cd6ec7dd973017cf40366017d5aef  pack_comparator/report_regen_FR1.csv
