"""Concatenate the FR1 and FR2 cell reports produced by the pack comparator
(ingest_quadriga.py) into the 270-cell report behind Table 4."""
import csv, sys
fr1, fr2, out = sys.argv[1:4]
rows1 = list(csv.DictReader(open(fr1)))
rows2 = list(csv.DictReader(open(fr2)))
assert rows1[0].keys() == rows2[0].keys()
with open(out, 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(rows1[0].keys()))
    w.writeheader()
    for r in rows1 + rows2:
        w.writerow(r)
print(f"{len(rows1)} + {len(rows2)} = {len(rows1)+len(rows2)} rows -> {out}")
