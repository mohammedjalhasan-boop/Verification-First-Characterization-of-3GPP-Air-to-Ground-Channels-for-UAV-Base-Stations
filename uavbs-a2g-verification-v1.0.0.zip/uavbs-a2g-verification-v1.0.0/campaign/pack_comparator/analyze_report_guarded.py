# ARCHIVE COPY of ch3_code_complete_v7/stage3/quadriga_kit/analyze_report.py.
# The pack file is unchanged. This copy differs ONLY by three guards marked
# "GUARD (archive copy)" so that the script also completes on a single-carrier
# report (the 28-GHz block): sections 8-9 of the original assume the two FR1
# carriers and raise NameError/IndexError otherwise. Numerical content is
# identical. The only other change is the import path (marked ARCHIVE PATH).
# Added by the manuscript editor (Oct. 2026); flagged for the authors.
"""Forensic analysis of the user's executed QuaDRiGa campaign report.

Every claim destined for dissertation text is recomputed here against the
archive's verified Stage-2 package (single source of truth).
"""
import csv, math, sys, os
import numpy as np

import os as _os
_HERE = _os.path.dirname(_os.path.abspath(__file__))
# ARCHIVE PATH: this copy lives in campaign/pack_comparator/, so the frozen
# package is resolved from the archive root (or from CH3_PACK).
sys.path.insert(0, _os.path.join(_os.environ.get('CH3_PACK', _os.path.join(
    _HERE, '..', '..', 'implementation', 'ch3_code_complete_v7')), 'stage2'))
import uav_channel as uc

rows = []
_report = sys.argv[1] if len(sys.argv) > 1 else _os.path.join(_HERE, 'report_executed_2026-08.csv')
with open(_report) as f:
    for r in csv.DictReader(f):
        d = {}
        for k, v in r.items():
            if k == 'env':
                d[k] = v
            elif k == 'plos_ok':
                d[k] = (v == 'True')
            else:
                d[k] = float(v) if v not in ('', 'nan') else float('nan')
        rows.append(d)
print(f"rows: {len(rows)}")

# QuaDRiGa 2.8.1 terrestrial 38.901 SF sigmas (from the standard's tables)
TERR_SF = {('UMa','LOS'): 4.0, ('UMa','NLOS'): 6.0,
           ('UMi','LOS'): 4.0, ('UMi','NLOS'): 7.82,
           ('RMa','LOS'): (4.0, 6.0),   # PL1 / PL2 dual-slope
           ('RMa','NLOS'): 8.0}

envs = ['UMa','UMi','RMa']
H = sorted({r['h_m'] for r in rows})

def med(vals):
    v = [x for x in vals if not math.isnan(x)]
    return float(np.median(v)) if v else float('nan')

print("\n=== 1. P_LoS agreement cells (plos_ok=True) ===")
ok = [r for r in rows if r['plos_ok']]
for r in ok:
    print(f"  {r['env']} h={r['h_m']:.0f} r={r['d2d_m']:.0f} fc={r['fc_ghz']} "
          f"emp={r['plos_emp']} model={r['plos_model']}")
near = [r for r in rows if abs(r['plos_emp']-r['plos_model']) <= 0.0201 and not r['plos_ok']]
print(f"  additional cells within 2pp but flagged False (float edge): {len(near)}")
for r in near[:8]:
    print(f"    {r['env']} h={r['h_m']:.0f} r={r['d2d_m']:.0f} fc={r['fc_ghz']} emp={r['plos_emp']} model={r['plos_model']}")

print("\n=== 2. P_LoS divergence magnitude by env/h (median |emp-model| across r,fc) ===")
for e in envs:
    line = f"  {e}: "
    for h in H:
        d = [abs(r['plos_emp']-r['plos_model']) for r in rows if r['env']==e and r['h_m']==h]
        line += f"h{h:.0f}:{med(d):.2f}  "
    print(line)

print("\n=== 3. LoS PL bias ===")
print("UMa plbias_LOS distinct values:",
      sorted({r['plbias_LOS'] for r in rows if r['env']=='UMa' and not math.isnan(r['plbias_LOS'])}))
for e in ('UMi','RMa'):
    vals = [r['plbias_LOS'] for r in rows if r['env']==e and not math.isnan(r['plbias_LOS'])]
    print(f"{e} plbias_LOS: min={min(vals):.3f} max={max(vals):.3f} median={med(vals):.3f} (n cells={len(vals)})")
# at-anchor rows (h=30)
for e in envs:
    vals = [r['plbias_LOS'] for r in rows if r['env']==e and r['h_m']==30 and not math.isnan(r['plbias_LOS'])]
    if vals:
        print(f"  {e} @h=30: LoS bias range [{min(vals):.3f}, {max(vals):.3f}]")

print("\n=== 3b. UMi LoS analytic reproduction (36.777 UMi-AV LoS vs 38.901 UMi PL1) ===")
def umi_gap(h, r):
    d3 = math.sqrt(r*r + (h-1.5)**2)
    # both PLs share +20log10(fc); frequency cancels in the gap
    aerial = 30.9 + (22.25 - 0.5*math.log10(h))*math.log10(d3)
    terr   = 32.4 + 21.0*math.log10(d3)
    return terr - aerial          # sampled - model
for (h, r_, obs) in [(30,50,0.600),(30,100,0.469),(50,50,0.762),(100,50,0.989),
                     (150,50,1.144),(200,50,1.270),(300,50,1.471),(300,100,1.471)]:
    print(f"  h={h:>3} r={r_:>3}: analytic {umi_gap(h,r_):+.3f}  observed {obs:+.3f}")

print("\n=== 3c. UMa LoS: why exactly zero (formula identity check) ===")
# 36.777 UMa-AV LoS (22.5<h<=300): 28.0+22log10(d3D)+20log10(fc) == 38.901 UMa PL1
d3 = math.sqrt(200*200+98.5**2)
print(f"  36.777 UMa-AV LoS == 38.901 UMa PL1 = 28+22log10(d3D)+20log10(fc): identical -> bias 0 exactly")
print(f"  model check pl_los_aerial('UMa',200,100,3.5) = {uc.pl_los_aerial('UMa',200.0,100.0,3.5):.3f}"
      f"  vs direct 28+22log10({d3:.1f})+20log10(3.5) = {28+22*math.log10(d3)+20*math.log10(3.5):.3f}")

print("\n=== 4. NLoS PL gap (sampled terrestrial-extrapolated minus aerial model) ===")
for e in envs:
    vals = [r['plbias_NLOS'] for r in rows if r['env']==e and not math.isnan(r['plbias_NLOS'])]
    print(f"{e}: min={min(vals):+.1f} max={max(vals):+.1f} median={med(vals):+.1f} dB (n={len(vals)})")

print("\n=== 5. sigma_SF LoS: observed ratio vs predicted (terrestrial const / aerial sigma(h)) ===")
print(f"{'env':4} {'h':>4} {'obs med':>8} {'pred(4dB)':>9} {'pred(6dB)':>9} {'implied terr sigma':>18}")
for e in envs:
    for h in H:
        obs = med([r['sfratio_LOS'] for r in rows if r['env']==e and r['h_m']==h])
        sig_m = uc.sf_std_aerial(e, h, 'LOS')
        p4, p6 = 4.0/sig_m, 6.0/sig_m
        if not math.isnan(obs):
            print(f"{e:4} {h:4.0f} {obs:8.2f} {p4:9.2f} {p6:9.2f} {obs*sig_m:14.2f} dB  (model sigma={sig_m:.2f})")

print("\n=== 6. sigma_SF NLoS: observed vs predicted table ratio ===")
for e in envs:
    vals = [r['sfratio_NLOS'] for r in rows if r['env']==e and not math.isnan(r['sfratio_NLOS'])]
    t = TERR_SF[(e,'NLOS')]
    m30 = uc.sf_std_aerial(e, 30.0, 'NLOS'); m300 = uc.sf_std_aerial(e, 300.0, 'NLOS')
    print(f"{e}: observed median={med(vals):.2f}  range [{min(vals):.2f},{max(vals):.2f}] n={len(vals)}; "
          f"model sigma 30m={m30:.2f}, 300m={m300:.2f}; terrestrial={t}; predicted={t/m30:.2f}")
    inband = sum(1 for v in vals if 0.8 <= v <= 1.2)
    print(f"     within [0.8,1.2]: {inband}/{len(vals)}")

print("\n=== 7. Delay-spread bias (dex) vs Alt-2 medians ===")
for e in ('UMa','RMa'):
    for st in ('LOS','NLOS'):
        key = f'dsbias_dex_{st}'
        vals = [r[key] for r in rows if r['env']==e and not math.isnan(r.get(key, float('nan')))]
        if vals:
            by_h = {h: med([r[key] for r in rows if r['env']==e and r['h_m']==h]) for h in H}
            trail = "  ".join(f"h{h:.0f}:{v:.2f}" for h, v in by_h.items() if not math.isnan(v))
            print(f"{e} {st}: median={med(vals):+.2f} dex  ({trail})")
# Alt-2 medians at anchor for context
for e in ('UMa','RMa'):
    for st in ('LOS','NLOS'):
        try:
            mu30 = uc.lsp_alt2(e, 30.0, st)['lgDS'][0]
            mu300 = uc.lsp_alt2(e, 300.0, st)['lgDS'][0]
            print(f"  Alt-2 {e} {st}: lgDS mu(30m)={mu30:.2f} -> DS={10**mu30*1e9:.0f} ns; "
                  f"mu(300m)={mu300:.2f} -> {10**mu300*1e9:.1f} ns")
        except Exception as ex:
            print(f"  Alt-2 {e} {st}: {ex}")

print("\n=== 8. Common-random-number check: 2.6 vs 3.5 GHz pairing ===")
pairs_same = pairs_diff = 0
bykey = {}
for r in rows:
    bykey.setdefault((r['env'], r['h_m'], r['d2d_m']), {})[r['fc_ghz']] = r
maxd = 0.0
argd = None   # GUARD (archive copy): defined even when the report holds a single carrier
for k, d in bykey.items():
    if 2.6 in d and 3.5 in d:
        if d[2.6]['plos_emp'] == d[3.5]['plos_emp']:
            pairs_same += 1
        else:
            pairs_diff += 1
        a, b = d[2.6]['plbias_LOS'], d[3.5]['plbias_LOS']
        if not (math.isnan(a) or math.isnan(b)):
            if abs(a-b) > maxd:
                maxd, argd = abs(a-b), k
print(f"  P_LoS identical across the fc pair in {pairs_same}/{pairs_same+pairs_diff} cells (CRN design)")
if argd is not None:   # GUARD (archive copy): the 2.6/3.5-GHz pairing exists only in the FR1 report
    print(f"  largest LoS-bias frequency effect: {maxd:.2f} dB at {argd} (RMa breakpoint shift expected)")
else:
    print("  (single-carrier report: no 2.6/3.5-GHz pairs; sections 8-9 apply to the FR1 report only)")

print("\n=== 9. RMa r=1000 breakpoint fingerprint ===")
for h in (30, 50):
    for fc in (2.6, 3.5):
        v = [r['plbias_LOS'] for r in rows if r['env']=='RMa' and r['h_m']==h and r['d2d_m']==1000 and r['fc_ghz']==fc]
        if v:   # GUARD (archive copy)
            print(f"  h={h} fc={fc}: plbias_LOS={v[0]:+.2f}")
# RMa breakpoint d_BP = 2*pi*hBS*hUT*fc/c (38.901 RMa), hBS=35
for fc in (2.6e9, 3.5e9):
    for h in (30, 50):
        dbp = 2*math.pi*35*h*fc/3e8
        print(f"  d_BP(hUT={h}, fc={fc/1e9:.1f}) = {dbp/1000:.1f} km  (r=1 km {'<' if 1000<dbp else '>'} d_BP)")

print("\n=== 10. plos model vs emp extremes for narrative ===")
for e in envs:
    worst = max((r for r in rows if r['env']==e), key=lambda r: abs(r['plos_emp']-r['plos_model']))
    print(f"  {e}: worst gap {abs(worst['plos_emp']-worst['plos_model']):.2f} at h={worst['h_m']:.0f} r={worst['d2d_m']:.0f} "
          f"(emp={worst['plos_emp']:.2f}, model={worst['plos_model']:.4f})")
