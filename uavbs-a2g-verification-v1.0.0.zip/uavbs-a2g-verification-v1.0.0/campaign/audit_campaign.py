#!/usr/bin/env python3
"""Independent audit of the 28-GHz QuaDRiGa campaign raw file.

Everything below is recomputed from the raw per-link rows. The TR 36.777
aerial expressions are the ones stated in Section III of the manuscript
(verified against Annex B); the TR 38.901 terrestrial expressions are the
ones QuaDRiGa implements for the swapped geometry (tx = ground node at
1.5 m, rx = UAV at h_ABS). Alternative-2 lgDS regressions (UMa-AV, RMa-AV)
from TR 36.777 Table B.1.2-1/-2.
"""
import numpy as np, pandas as pd, json, sys
from scipy.stats import beta

C_LIGHT = 299792458.0
import sys
FC = None            # per-row carrier (fc_ghz column)
HGU = 1.5            # ground node height [m]

IN = sys.argv[1]; TAG = sys.argv[2]
raw = pd.read_csv(IN)
n_raw = len(raw)
df = raw.drop_duplicates().reset_index(drop=True)
print('rows after de-dup:', len(df))
assert df.duplicated(subset=['env','fc_ghz','h_m','d2d_m','seed']).sum() == 0
df['d3d'] = np.sqrt(df.d2d_m**2 + (df.h_m - HGU)**2)
lg = np.log10

# ---------------------------------------------------------------- TR 36.777 (aerial annex), fc in GHz
def annex_plos(env, h, r):
    if env == 'UMa':
        if h > 100: return 1.0
        p1 = 4300*lg(h) - 3800; d1 = max(460*lg(h) - 700, 18)
    elif env == 'UMi':
        p1 = 233.98*lg(h) - 0.95; d1 = max(294.05*lg(h) - 432.94, 18)
    else:
        if h > 40: return 1.0
        p1 = max(15021*lg(h) - 16053, 1000); d1 = max(1350.8*lg(h) - 1602, 18)
    if r <= d1: return 1.0
    return d1/r + np.exp(-r/p1)*(1 - d1/r)

def annex_pl(env, state, h, d3d, fc):
    k40 = 20*lg(40*np.pi*fc/3)
    fs  = 20*lg(d3d) + 20*lg(fc) + 32.45                      # free space, d in m, fc in GHz
    if env == 'UMa':
        los = 28.0 + 22*lg(d3d) + 20*lg(fc)
        nlos = -17.5 + (46 - 7*lg(h))*lg(d3d) + k40
    elif env == 'UMi':
        los = max(fs, 30.9 + (22.25 - 0.5*lg(h))*lg(d3d) + 20*lg(fc))
        nlos = max(los, 32.4 + (43.2 - 7.6*lg(h))*lg(d3d) + 20*lg(fc))
    else:
        los = max(23.9 - 1.8*lg(h), 20)*lg(d3d) + k40
        nlos = max(los, -12 + (35 - 5.3*lg(h))*lg(d3d) + k40)
    return los if state == 1 else nlos

def annex_sigma(env, state, h):
    if state == 1:
        return {'UMa': 4.64*np.exp(-0.0066*h), 'UMi': max(5*np.exp(-0.01*h), 2.0), 'RMa': 4.2*np.exp(-0.0046*h)}[env]
    return {'UMa': 6.0, 'UMi': 8.0, 'RMa': 6.0}[env]

def alt2_lgds(env, state, h):          # TR 36.777 Table B.1.2 (mu of lgDS), UMi-AV not provided
    if env == 'UMa':
        return -0.31*lg(h) - 6.845 if state == 1 else 0.0965*lg(h) - 7.503
    if env == 'RMa':
        return 0.0549*lg(h) - 8.0945 if state == 1 else -1.3465*lg(h) - 7.0805
    return np.nan

# ---------------------------------------------------------------- TR 38.901 as implemented for the swapped geometry
def t901_pl(env, state, h, r, d3d, fc, hbs=HGU):
    fc_hz = fc*1e9
    if env == 'UMa':
        hE = 1.0; dbp = 4*(hbs-hE)*(h-hE)*fc_hz/C_LIGHT
        pl1 = 28 + 22*lg(d3d) + 20*lg(fc)
        pl2 = 28 + 40*lg(d3d) + 20*lg(fc) - 9*lg(dbp**2 + (hbs-h)**2)
        los = pl1 if r <= dbp else pl2
        nlos = max(los, 13.54 + 39.08*lg(d3d) + 20*lg(fc) - 0.6*(h-1.5))
        sig = (4.0 if state == 1 else 6.0)
    elif env == 'UMi':
        hE = 1.0; dbp = 4*(hbs-hE)*(h-hE)*fc_hz/C_LIGHT
        pl1 = 32.4 + 21*lg(d3d) + 20*lg(fc)
        pl2 = 32.4 + 40*lg(d3d) + 20*lg(fc) - 9.5*lg(dbp**2 + (hbs-h)**2)
        los = pl1 if r <= dbp else pl2
        nlos = max(los, 22.4 + 35.3*lg(d3d) + 21.3*lg(fc) - 0.3*(h-1.5))
        sig = (4.0 if state == 1 else 7.82)
    else:
        hb = 5.0; W = 20.0
        dbp = 2*np.pi*hbs*h*fc_hz/C_LIGHT
        def pl1f(d):
            return 20*lg(40*np.pi*d*fc/3) + min(0.03*hb**1.72, 10)*lg(d) - min(0.044*hb**1.72, 14.77) + 0.002*lg(hb)*d
        if r <= dbp:
            los = pl1f(d3d); sig_los = 4.0
        else:
            los = pl1f(dbp) + 40*lg(d3d/dbp); sig_los = 6.0
        nlos_p = (161.04 - 7.1*lg(W) + 7.5*lg(hb) - (24.37 - 3.7*(hb/hbs)**2)*lg(hbs)
                  + (43.42 - 3.1*lg(hbs))*(lg(d3d) - 3) + 20*lg(fc) - (3.2*(lg(11.75*h))**2 - 4.97))
        nlos = max(los, nlos_p)
        sig = (sig_los if state == 1 else 8.0)
    return (los if state == 1 else nlos), sig, (nlos if env != 'RMa' else nlos) , los

def t901_lgds(env, state, fc):
    if env == 'UMa': return -6.955 - 0.0963*lg(fc) if state == 1 else -6.28 - 0.204*lg(fc)
    if env == 'UMi': return -0.24*lg(1+fc) - 7.14 if state == 1 else -0.24*lg(1+fc) - 6.83
    return -7.49 if state == 1 else -7.43

# ---------------------------------------------------------------- per-row closed-form check of QuaDRiGa's path loss
res = []
for i, row in df.iterrows():
    pl_t, sig_t, _, los_t = t901_pl(row.env, row.los, row.h_m, row.d2d_m, row.d3d, row.fc_ghz)
    res.append(row.pl_db - pl_t)
df['pl_t901'] = df.pl_db - np.array(res)
df['resid_t901'] = np.array(res)
print("QuaDRiGa pl_db vs TR 38.901 closed form (swapped geometry): max |resid| = %.4f dB" % np.abs(df.resid_t901).max())
for env in ['UMa','UMi','RMa']:
    for st in [1,0]:
        sub = df[(df.env==env)&(df.los==st)]
        print(f"   {env} {'LOS ' if st else 'NLOS'}: n={len(sub):4d}  max|resid|={np.abs(sub.resid_t901).max():.4f} dB")

# ---------------------------------------------------------------- per-cell report
rows = []
for (env, fc, h, r), g in df.groupby(['env','fc_ghz','h_m','d2d_m']):
    n = len(g); nl = int(g.los.sum()); nn = n - nl
    d3d = g.d3d.iloc[0]
    p_hat = nl/n
    lo = beta.ppf(0.025, nl, n-nl+1) if nl > 0 else 0.0
    hi = beta.ppf(0.975, nl+1, n-nl) if nl < n else 1.0
    p_ann = annex_plos(env, h, r)
    rec = dict(env=env, fc_ghz=fc, h_m=h, d2d_m=r, d3d_m=round(d3d,2), n=n, n_los=nl, n_nlos=nn, p_hat=p_hat,
               ci_lo=lo, ci_hi=hi, p_annex=p_ann, annex_outside_ci=int(not (lo <= p_ann <= hi)),
               dP=p_hat - p_ann)
    for st, name in [(1,'los'),(0,'nlos')]:
        gs = g[g.los==st]
        populated = len(gs) >= 8
        rec[f'populated_{name}'] = int(populated)
        if len(gs):
            pl_q = gs.pl_db.median()
            pl_a = annex_pl(env, st, h, d3d, fc)
            pl_t, sig_t, _, _ = t901_pl(env, st, h, r, d3d, fc)
            rec[f'pl_quadriga_{name}'] = pl_q
            rec[f'pl_annex_{name}'] = pl_a
            rec[f'bias_{name}'] = pl_q - pl_a                 # sampled minus model
            rec[f'pred_gap_{name}'] = pl_t - pl_a             # closed-form (38.901 - annex)
            rec[f'resid_{name}'] = (pl_q - pl_a) - (pl_t - pl_a)
            sf_std = gs.sf_db.std(ddof=1) if len(gs) > 1 else np.nan
            rec[f'sf_std_{name}'] = sf_std
            rec[f'sigma_annex_{name}'] = annex_sigma(env, st, h)
            rec[f'sigma_t901_{name}'] = sig_t
            rec[f'sf_ratio_obs_{name}'] = sf_std/annex_sigma(env, st, h)
            rec[f'sf_ratio_pred_{name}'] = sig_t/annex_sigma(env, st, h)
            rec[f'ds_med_ns_{name}'] = gs.ds_ns.median()
            a2 = alt2_lgds(env, st, h)
            rec[f'ds_alt2_ns_{name}'] = 10**(a2+9) if not np.isnan(a2) else np.nan
            rec[f'ds_gap_dex_{name}'] = lg(gs.ds_ns.median()) - (a2+9) if not np.isnan(a2) else np.nan
            rec[f'ds_t901_ns_{name}'] = 10**(t901_lgds(env, st, fc)+9)
        else:
            for k in ['pl_quadriga','pl_annex','bias','pred_gap','resid','sf_std','sigma_annex','sigma_t901',
                      'sf_ratio_obs','sf_ratio_pred','ds_med_ns','ds_alt2_ns','ds_gap_dex','ds_t901_ns']:
                rec[f'{k}_{name}'] = np.nan
    # clipping of the terrestrial NLoS law onto its LoS floor (mechanism check)
    gn = g[g.los==0]
    if len(gn):
        pl_los_t = t901_pl(env, 1, h, r, d3d, fc)[0]
        rec['nlos_clipped_to_los'] = int(np.all(np.abs(gn.pl_db - pl_los_t) < 1e-3))
    else:
        rec['nlos_clipped_to_los'] = -1
    rows.append(rec)
rep = pd.DataFrame(rows)
rep.to_csv(f'cell_report_{TAG}.csv', index=False)

# ---------------------------------------------------------------- summary in the Table-4 layout
S = {}
S['links'] = int(len(df)); S['cells'] = int(len(rep)); S['raw_rows_in_upload'] = int(n_raw)
S['exact_duplicate_blocks'] = int(n_raw/len(df))
pairs = int(rep.populated_los.sum() + rep.populated_nlos.sum())
resids = np.concatenate([rep.resid_los[rep.populated_los==1].values, rep.resid_nlos[rep.populated_nlos==1].values])
S['populated_state_pairs'] = pairs
S['pairs_resid_le_0p01dB'] = int(np.sum(np.abs(resids) <= 0.01))
S['max_abs_resid_dB'] = float(np.nanmax(np.abs(resids)))
for env in ['UMa','UMi','RMa']:
    e = rep[rep.env==env]
    d = {}
    d['los_identity_cells'] = int(np.sum(np.abs(e.bias_los[e.populated_los==1]) < 5e-4))
    d['los_populated'] = int(e.populated_los.sum()); d['nlos_populated'] = int(e.populated_nlos.sum())
    d['los_resid_max_dB'] = float(np.nanmax(np.abs(e.resid_los[e.populated_los==1]))) if e.populated_los.sum() else None
    d['nlos_resid_max_dB'] = float(np.nanmax(np.abs(e.resid_nlos[e.populated_nlos==1]))) if e.populated_nlos.sum() else None
    d['los_bias_median_dB'] = float(np.nanmedian(e.bias_los[e.populated_los==1])) if e.populated_los.sum() else None
    d['nlos_gap_median_dB'] = float(np.nanmedian(e.bias_nlos[e.populated_nlos==1])) if e.populated_nlos.sum() else None
    d['nlos_gap_min_max_dB'] = [float(np.nanmin(e.bias_nlos[e.populated_nlos==1])), float(np.nanmax(e.bias_nlos[e.populated_nlos==1]))] if e.populated_nlos.sum() else None
    d['plos_cells_outside_ci'] = f"{int(e.annex_outside_ci.sum())}/{len(e)}"
    d['max_abs_dP'] = float(np.abs(e.dP).max())
    d['median_abs_dP_at_300m'] = float(np.abs(e[e.h_m==300].dP).median())
    d['worst_dP_cell'] = e.loc[np.abs(e.dP).idxmax(), ['h_m','d2d_m','p_hat','p_annex']].to_dict()
    def ratio_at(hh, name):
        s = e[(e.h_m==hh)&(e[f'populated_{name}']==1)]
        return (float(s[f'sf_ratio_obs_{name}'].median()), float(s[f'sf_ratio_pred_{name}'].min()), float(s[f'sf_ratio_pred_{name}'].max())) if len(s) else None
    d['sf_nlos_ratio_median_obs_pred'] = (float(e.sf_ratio_obs_nlos[e.populated_nlos==1].median()), float(e.sf_ratio_pred_nlos[e.populated_nlos==1].median())) if e.populated_nlos.sum() else None
    d['sf_los_ratio_30m_obs_predrange'] = ratio_at(30,'los')
    d['sf_los_ratio_300m_obs_predrange'] = ratio_at(300,'los')
    d['ds_gap_nlos_median_dex'] = float(np.nanmedian(e.ds_gap_dex_nlos[e.populated_nlos==1])) if e.populated_nlos.sum() and env!='UMi' else None
    d['ds_gap_nlos_min_max_dex'] = [float(np.nanmin(e.ds_gap_dex_nlos[e.populated_nlos==1])), float(np.nanmax(e.ds_gap_dex_nlos[e.populated_nlos==1]))] if e.populated_nlos.sum() and env!='UMi' else None
    d['ds_gap_los_median_dex'] = float(np.nanmedian(e.ds_gap_dex_los[e.populated_los==1])) if env!='UMi' else None
    d['nlos_clipping_active_cells'] = f"{int((e.nlos_clipped_to_los==1).sum())}/{int((e.nlos_clipped_to_los>=0).sum())} (cells with NLoS draws)"
    S[env] = d
json.dump(S, open(f'summary_{TAG}.json','w'), indent=1, default=str)
print(json.dumps(S, indent=1, default=str))
